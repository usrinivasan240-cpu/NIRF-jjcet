"use client";

interface Activity {
  id: string;
  user: { name: string };
  action: string;
  entity: string;
  timestamp: string;
}

interface RecentActivityProps {
  activities: Activity[];
}

export function RecentActivity({ activities }: RecentActivityProps) {
  return (
    <div className="rounded-lg border bg-card p-4 shadow-sm">
      <h3 className="text-sm font-medium mb-4">Recent Activity</h3>
      <div className="space-y-4">
        {activities.map((a) => (
          <div key={a.id} className="flex gap-3">
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-xs font-medium text-primary">
              {a.user.name.split(" ").map(n => n[0]).join("")}
            </div>
            <div className="flex-1">
              <p className="text-sm"><span className="font-medium">{a.user.name}</span> {a.action} <span className="font-medium">{a.entity}</span></p>
              <p className="text-xs text-muted-foreground">{new Date(a.timestamp).toLocaleDateString()}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
