"use client";

import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  change?: number;
  changeLabel?: string;
  className?: string;
}

export function StatsCard({ title, value, icon: Icon, change, changeLabel, className }: StatsCardProps) {
  return (
    <div className={cn("rounded-lg border bg-card p-4 shadow-sm", className)}>
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium text-muted-foreground">{title}</p>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </div>
      <div className="mt-2">
        <p className="text-2xl font-bold">{value}</p>
        {change !== undefined && (
          <p className={cn("text-xs mt-1", change >= 0 ? "text-green-600" : "text-red-600")}>
            {change >= 0 ? "+" : ""}{change}% {changeLabel}
          </p>
        )}
      </div>
    </div>
  );
}
