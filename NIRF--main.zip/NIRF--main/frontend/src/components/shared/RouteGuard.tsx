"use client";

import { useAuthStore } from "@/store";
import { useRouter, usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Role } from "@/types";
import { hasAccess, ModuleAccess } from "@/lib/access";

const PATH_TO_MODULE: Record<string, keyof ModuleAccess> = {
  "/dashboard": "dashboard",
  "/departments": "departments",
  "/faculty": "faculty",
  "/publications": "publications",
  "/patents": "patents",
  "/research": "research",
  "/phd": "phd",
  "/students": "students",
  "/events": "events",
  "/reviews": "reviews",
  "/targets": "targets",
  "/vp-targets": "vpTargets",
  "/department-analysis": "deptAnalysis",
  "/documents": "documents",
  "/reports": "reports",
  "/analytics": "analytics",
  "/ai": "ai",
  "/notifications": "notifications",
  "/settings": "settings",
  "/users": "userManagement",
  "/branding": "branding",
  "/page-control": "pageControl",
};

function matchModule(pathname: string): keyof ModuleAccess | null {
  if (PATH_TO_MODULE[pathname]) return PATH_TO_MODULE[pathname];
  const segments = pathname.split("/").filter(Boolean);
  if (segments.length > 1) {
    const prefix = "/" + segments[0];
    if (PATH_TO_MODULE[prefix]) return PATH_TO_MODULE[prefix];
  }
  return null;
}

export function RouteGuard({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const { user, isAuthenticated } = useAuthStore();
  const [allowed, setAllowed] = useState(false);

  useEffect(() => {
    if (!isAuthenticated || !user) {
      router.push("/login");
      setAllowed(false);
      return;
    }

    const module = matchModule(pathname);
    if (module && !hasAccess(user.role as Role, module)) {
      router.push("/dashboard");
      setAllowed(false);
      return;
    }

    setAllowed(true);
  }, [user, isAuthenticated, router, pathname]);

  if (!isAuthenticated || !user || !allowed) return null;

  return <>{children}</>;
}
