"use client";

import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { X, FileText, FileSpreadsheet, Download, Printer } from "lucide-react";
import type { ReportData, BrandingData } from "@/lib/reportGenerator";
import { fetchBranding } from "@/lib/reportGenerator";

interface ReportPreviewProps {
  data: ReportData;
  onClose: () => void;
  onExportPDF: () => void;
  onExportExcel: () => void;
  onExportCSV: () => void;
  onPrint: () => void;
}

export function ReportPreview({ data, onClose, onExportPDF, onExportExcel, onExportCSV, onPrint }: ReportPreviewProps) {
  const di = data.departmentInfo;
  const targets = data.targetVsAchievement;
  const ds = data.detailedSummary;
  const mw = data.monthWise;
  const months = ["Jun","Jul","Aug","Sep","Oct","Nov","Dec","Jan","Feb","Mar","Apr","May"];

  const totalTarget = targets.reduce((a, r) => a + r.targetTillMonth, 0);
  const totalAchieved = targets.reduce((a, r) => a + r.achieved, 0);
  const totalPending = targets.reduce((a, r) => a + r.pending, 0);
  const totalPct = totalTarget > 0 ? ((totalAchieved / totalTarget) * 100).toFixed(2) + "%" : "0%";

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-3" onClick={onClose}>
      <div className="bg-background rounded-xl shadow-2xl w-full max-w-6xl max-h-[92vh] overflow-hidden flex flex-col border border-[#0B2E6B]/20" onClick={e => e.stopPropagation()}>
        <div className="bg-[#0B2E6B] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/logo.png" alt="Logo" className="w-10 h-10 rounded-full object-contain bg-white/10 p-0.5" onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
            <div>
              <h2 className="text-sm font-bold tracking-wide">DEPARTMENT MONTHLY PERFORMANCE REPORT</h2>
              <p className="text-[10px] opacity-70">{di.deptName} | {di.month} | {data.header.academicYear}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-[10px] border-white/30 text-white">{data.header.reportId}</Badge>
            <button onClick={onClose} className="text-white/70 hover:text-white"><X className="h-5 w-5" /></button>
          </div>
        </div>

        <div className="flex gap-2 p-3 border-b bg-[#f8f9fc]">
          <Button size="sm" onClick={onExportPDF} className="bg-red-600 hover:bg-red-700 text-white text-xs"><FileText className="h-3 w-3 mr-1" />PDF</Button>
          <Button size="sm" onClick={onExportExcel} className="bg-green-600 hover:bg-green-700 text-white text-xs"><FileSpreadsheet className="h-3 w-3 mr-1" />Excel</Button>
          <Button size="sm" onClick={onExportCSV} variant="outline" className="text-xs"><Download className="h-3 w-3 mr-1" />CSV</Button>
          <Button size="sm" onClick={onPrint} variant="outline" className="text-xs"><Printer className="h-3 w-3 mr-1" />Print</Button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs">
          {/* Info */}
          <div>
            <h3 className="text-[10px] font-bold text-[#0B2E6B] mb-2 tracking-wide">DEPARTMENT INFORMATION</h3>
            <div className="grid grid-cols-2 gap-x-6 gap-y-1 bg-[#f8f9fc] border border-[#c8d7eb] rounded p-3 border-l-3 border-l-[#0B2E6B]">
              <div><span className="font-bold text-[#0B2E6B]">Department Name</span>: {di.deptName}</div>
              <div><span className="font-bold text-[#0B2E6B]">HOD Name</span>: {di.hodName}</div>
              <div><span className="font-bold text-[#0B2E6B]">Month</span>: {di.month}</div>
              <div><span className="font-bold text-[#0B2E6B]">Contact</span>: {di.contact}</div>
              <div><span className="font-bold text-[#0B2E6B]">Total Faculty</span>: {di.totalFaculty}</div>
              <div><span className="font-bold text-[#0B2E6B]">Report Status</span>: {di.reportStatus}</div>
              <div><span className="font-bold text-[#0B2E6B]">Total Students</span>: {di.totalStudents}</div>
              <div><span className="font-bold text-[#0B2E6B]">Submitted Date</span>: {di.submittedDate}</div>
            </div>
          </div>

          {/* Targets Table */}
          <div>
            <h3 className="text-[10px] font-bold text-[#0B2E6B] mb-2 tracking-wide">1. TARGET vs ACHIEVEMENT SUMMARY</h3>
            <div className="rounded-md border overflow-x-auto">
              <table className="w-full text-[10px]">
                <thead>
                  <tr className="bg-[#0B2E6B] text-white">
                    <th className="px-2 py-1.5 text-center w-8">S.No</th>
                    <th className="px-2 py-1.5 text-left">Performance Metric</th>
                    <th className="px-2 py-1.5 text-center w-16">Yearly Target</th>
                    <th className="px-2 py-1.5 text-center w-20">Target (Till Month)</th>
                    <th className="px-2 py-1.5 text-center w-20">Achieved</th>
                    <th className="px-2 py-1.5 text-center w-16">Pending</th>
                    <th className="px-2 py-1.5 text-center w-20">Achievement %</th>
                    <th className="px-2 py-1.5 text-center w-16">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {targets.map((r, i) => (
                    <tr key={i} className={`border-b ${i % 2 === 0 ? "bg-white" : "bg-[#f8f9fc]"}`}>
                      <td className="px-2 py-1 text-center font-semibold text-[#0B2E6B]">{r.sno}</td>
                      <td className="px-2 py-1 text-left font-medium">{r.metric}</td>
                      <td className="px-2 py-1 text-center">{r.yearlyTarget}</td>
                      <td className="px-2 py-1 text-center">{r.targetTillMonth}</td>
                      <td className="px-2 py-1 text-center font-semibold text-green-600">{r.achieved}</td>
                      <td className="px-2 py-1 text-center text-red-600">{r.pending}</td>
                      <td className="px-2 py-1 text-center font-semibold">{r.achievementPct}</td>
                      <td className={`px-2 py-1 text-center font-bold ${r.status === "ON TRACK" ? "text-green-600" : "text-red-600"}`}>{r.status}</td>
                    </tr>
                  ))}
                  <tr className="bg-[#e6f0fc] font-bold border-t-2 border-[#0B2E6B]">
                    <td></td><td className="px-2 py-1.5 text-left">TOTAL</td>
                    <td className="text-center">{targets.reduce((a,r) => a + r.yearlyTarget, 0)}</td>
                    <td className="text-center">{totalTarget}</td>
                    <td className="text-center text-green-600">{totalAchieved}</td>
                    <td className="text-center text-red-600">{totalPending}</td>
                    <td className="text-center">{totalPct}</td><td></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Detailed Summary */}
          <div>
            <h3 className="text-[10px] font-bold text-[#0B2E6B] mb-2 tracking-wide">2. DETAILED SUMMARY</h3>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {([
                ["PUBLICATIONS", ds.publications, "Total Publications"],
                ["PATENTS", ds.patents, "Total Patents"],
                ["RESEARCH & PROJECTS", ds.research, "Total Projects"],
                ["STUDENT ACTIVITIES", ds.studentActivities, ""],
              ] as const).map(([title, items, totalLabel]) => (
                <Card key={title} className="border-[#c8d7eb] overflow-hidden">
                  <div className="bg-[#0B2E6B] text-white py-1.5 px-3 text-center text-[10px] font-bold">{title}</div>
                  <CardContent className="p-3 space-y-1">
                    {items.map((it, i) => (
                      <div key={i} className="flex justify-between text-[10px] border-b border-gray-100 pb-1">
                        <span>{it.label}</span><span className="font-semibold">{it.value}</span>
                      </div>
                    ))}
                    {totalLabel && <div className="flex justify-between text-[10px] font-bold text-[#0B2E6B] border-t border-[#c8d7eb] pt-1 mt-1"><span>{totalLabel}</span><span>{items.reduce((a,it) => a + it.value, 0)}</span></div>}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Month-wise */}
          <div>
            <h3 className="text-[10px] font-bold text-[#0B2E6B] mb-2 tracking-wide">3. MONTH-WISE PROGRESS OVERVIEW</h3>
            <div className="rounded-md border overflow-x-auto">
              <table className="w-full text-[10px]">
                <thead>
                  <tr className="bg-[#0B2E6B] text-white">
                    <th className="px-2 py-1.5 text-left w-28">Metric</th>
                    {months.map(m => <th key={m} className="px-1.5 py-1.5 text-center w-12">{m}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {mw.map((r, i) => (
                    <tr key={i} className={`border-b ${i % 2 === 0 ? "bg-white" : "bg-[#f8f9fc]"}`}>
                      <td className="px-2 py-1 text-left font-medium">{r.metric}</td>
                      {r.months.map((v, mi) => <td key={mi} className="px-1.5 py-1 text-center">{v}</td>)}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-[9px] text-gray-500 italic mt-1">Note: April & May are non-working months (Examinations / Vacation).</p>
          </div>

          {/* Remarks */}
          <div>
            <h3 className="text-[10px] font-bold text-[#0B2E6B] mb-2 tracking-wide">4. REMARKS BY HOD</h3>
            <div className="border border-[#c8d7eb] border-l-3 border-l-[#0B2E6B] rounded p-3 bg-[#f8f9fc] min-h-[50px]">{data.remarks || ""}</div>
          </div>

          {/* Signatures */}
          <div>
            <h3 className="text-[10px] font-bold text-[#0B2E6B] mb-2 tracking-wide">SIGNATURES</h3>
            <div className="grid grid-cols-3 gap-4">
              {([
                ["HOD REMARKS", data.signatures.hod.name || "Dr. R. Krishnan", "Head of the Department", data.signatures.hod.date],
                ["VICE PRINCIPAL SIGNATURE", data.signatures.vp.name || "Dr. S. Velmurgan", "Vice Principal", data.signatures.vp.date],
                ["HEAD MASTER SIGNATURE", data.signatures.principal.name || "Dr. P. Selvakumar", "Principal", data.signatures.principal.date],
              ] as const).map(([title, name, role, date]) => (
                <div key={title} className="border border-[#c8d7eb] rounded text-center p-3">
                  <div className="text-[10px] font-bold text-[#0B2E6B] mb-8">{title}</div>
                  <div className="border-b border-gray-400 mx-4 mb-2" />
                  <div className="text-[10px] font-bold">{name}</div>
                  <div className="text-[9px] text-gray-500">{role}</div>
                  <div className="text-[9px] text-gray-500 mt-1">Date: {date}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t p-3 bg-[#f8f9fc] text-[9px] text-gray-500 flex justify-between">
          <span>Report ID: {data.header.reportId}</span>
          <span>JJ College of Engineering & Technology | Confidential</span>
          <span>Generated: {data.header.generatedOn}</span>
        </div>
      </div>
    </div>
  );
}
