"use client";

import { Badge } from "@/components/ui/badge";

interface Notification {
  id: string;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  createdAt: string;
}

interface NotificationListProps {
  notifications: Notification[];
}

export function NotificationList({ notifications }: NotificationListProps) {
  return (
    <div className="rounded-lg border bg-card p-4 shadow-sm">
      <h3 className="text-sm font-medium mb-4">Notifications</h3>
      <div className="space-y-3">
        {notifications.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">No notifications</p>
        ) : (
          notifications.map((n) => (
            <div key={n.id} className={`flex items-start gap-3 rounded-md border p-3 ${!n.isRead ? "bg-primary/5" : ""}`}>
              <div className="flex-1">
                <p className="text-sm font-medium">{n.title}</p>
                <p className="text-xs text-muted-foreground">{n.message}</p>
                <p className="text-xs text-muted-foreground mt-1">{n.createdAt}</p>
              </div>
              <Badge variant={n.type === "success" ? "default" : n.type === "reminder" ? "secondary" : "destructive"}>
                {n.type}
              </Badge>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
