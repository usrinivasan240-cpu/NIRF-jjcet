"use client";

import { Button } from "@/components/ui/button";

interface Approval {
  id: string;
  type: string;
  title: string;
  submittedBy: string;
  submittedAt: string;
  status: string;
  currentLevel: string;
}

interface PendingApprovalsProps {
  approvals: Approval[];
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

export function PendingApprovals({ approvals, onApprove, onReject }: PendingApprovalsProps) {
  return (
    <div className="rounded-lg border bg-card p-4 shadow-sm">
      <h3 className="text-sm font-medium mb-4">Pending Approvals</h3>
      <div className="space-y-3">
        {approvals.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">No pending approvals</p>
        ) : (
          approvals.map((a) => (
            <div key={a.id} className="flex items-center justify-between rounded-md border p-3">
              <div>
                <p className="text-sm font-medium">{a.title}</p>
                <p className="text-xs text-muted-foreground">{a.submittedBy} — {a.currentLevel}</p>
              </div>
              <div className="flex gap-1">
                <Button size="sm" variant="outline" onClick={() => onReject(a.id)}>Reject</Button>
                <Button size="sm" onClick={() => onApprove(a.id)}>Approve</Button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
