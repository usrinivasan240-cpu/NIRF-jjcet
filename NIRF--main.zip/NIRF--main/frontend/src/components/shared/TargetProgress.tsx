"use client";

interface Target {
  category: string;
  target: number;
  achieved: number;
  percentage: number;
}

interface TargetProgressProps {
  targets: Target[];
}

export function TargetProgress({ targets }: TargetProgressProps) {
  return (
    <div className="rounded-lg border bg-card p-4 shadow-sm">
      <h3 className="text-sm font-medium mb-4">Target Progress</h3>
      <div className="space-y-4">
        {targets.map((t, i) => (
          <div key={`${t.category}-${i}`}>
            <div className="flex justify-between text-sm mb-1">
              <span className="capitalize">{t.category}</span>
              <span className="text-muted-foreground">{t.achieved}/{t.target} ({t.percentage}%)</span>
            </div>
            <div className="h-2 rounded-full bg-muted overflow-hidden">
              <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${Math.min(t.percentage, 100)}%` }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
