"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { X, Save, FileText } from "lucide-react";
import type { ReportData, TargetRow } from "@/lib/reportGenerator";
import { generatePDF, generateExcel, generateCSV, printReport, fetchBranding } from "@/lib/reportGenerator";

interface MonthlyReportFormProps {
  data: ReportData;
  onClose: () => void;
  onSave: (data: ReportData) => void;
}

type Tab = "targets" | "detailed" | "monthwise" | "remarks";

export function MonthlyReportForm({ data, onClose, onSave }: MonthlyReportFormProps) {
  const [rd, setRd] = useState<ReportData>({ ...data });
  const [tab, setTab] = useState<Tab>("targets");
  const [includeDetailedSummary, setIncludeDetailedSummary] = useState(true);

  const tabs: { id: Tab; label: string }[] = [
    { id: "targets", label: "Target vs Achievement" },
    { id: "detailed", label: "Detailed Summary" },
    { id: "monthwise", label: "Month-wise Progress" },
    { id: "remarks", label: "Remarks" },
  ];

  const updateTarget = (i: number, field: keyof TargetRow, value: string | number) => {
    setRd(prev => {
      const t = [...prev.targetVsAchievement];
      t[i] = { ...t[i], [field]: value };
      if (field === "achieved" || field === "targetTillMonth") {
        const tgt = field === "targetTillMonth" ? Number(value) : t[i].targetTillMonth;
        const ach = field === "achieved" ? Number(value) : t[i].achieved;
        t[i].pending = tgt - ach;
        t[i].achievementPct = tgt > 0 ? ((ach / tgt) * 100).toFixed(2) + "%" : "0.00%";
        t[i].status = Number(t[i].achievementPct) >= 60 ? "ON TRACK" : "BEHIND";
      }
      return { ...prev, targetVsAchievement: t };
    });
  };

  const updateDetail = (section: "publications" | "patents" | "research" | "studentActivities", i: number, field: "label" | "value", value: string | number) => {
    setRd(prev => {
      const ds = { ...prev.detailedSummary };
      const arr = [...ds[section]];
      arr[i] = { ...arr[i], [field]: field === "value" ? Number(value) : value };
      return { ...prev, detailedSummary: { ...ds, [section]: arr } };
    });
  };

  const addDetail = (section: "publications" | "patents" | "research" | "studentActivities") => {
    setRd(prev => {
      const ds = { ...prev.detailedSummary };
      return { ...prev, detailedSummary: { ...ds, [section]: [...ds[section], { label: "", value: 0 }] } };
    });
  };

  const removeDetail = (section: "publications" | "patents" | "research" | "studentActivities", i: number) => {
    setRd(prev => {
      const ds = { ...prev.detailedSummary };
      return { ...prev, detailedSummary: { ...ds, [section]: ds[section].filter((_, idx) => idx !== i) } };
    });
  };

  const updateMonthWise = (i: number, monthIdx: number, value: number | "-") => {
    setRd(prev => {
      const mw = [...prev.monthWise];
      const months = [...mw[i].months];
      months[monthIdx] = value;
      mw[i] = { ...mw[i], months };
      return { ...prev, monthWise: mw };
    });
  };

  const addMonthWise = () => {
    setRd(prev => ({
      ...prev,
      monthWise: [...prev.monthWise, { metric: "", months: ["-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"] }],
    }));
  };

  const removeMonthWise = (i: number) => {
    setRd(prev => ({ ...prev, monthWise: prev.monthWise.filter((_, idx) => idx !== i) }));
  };

  const handlePDF = async () => { const b = await fetchBranding(); await generatePDF(rd, undefined, b, undefined, { includeDetailedSummary }); };
  const handleExcel = async () => { const b = await fetchBranding(); generateExcel(rd, undefined, b); };
  const handleCSV = async () => { generateCSV(rd); };
  const handlePrint = async () => { const b = await fetchBranding(); printReport(rd, b); };

  const lbl = "text-xs font-semibold text-[#0B2E6B]";
  const inp = "h-8 text-xs";

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-3" onClick={onClose}>
      <div className="bg-background rounded-xl shadow-2xl w-full max-w-7xl max-h-[92vh] overflow-hidden flex flex-col border border-[#0B2E6B]/20" onClick={e => e.stopPropagation()}>
        <div className="bg-[#0B2E6B] text-white p-4 flex items-center justify-between shrink-0">
          <div>
            <h2 className="text-lg font-bold tracking-wide">Edit Monthly Report</h2>
            <p className="text-xs opacity-70">Modify data, then export as PDF, Excel, CSV, or Print</p>
          </div>
          <button onClick={onClose} className="text-white/70 hover:text-white"><X className="h-5 w-5" /></button>
        </div>

        <div className="flex border-b bg-[#f8f9fc] overflow-x-auto shrink-0">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`px-4 py-2.5 text-xs font-semibold whitespace-nowrap ${tab === t.id ? "border-b-2 border-[#E67E22] text-[#0B2E6B] bg-white" : "text-gray-500 hover:text-[#0B2E6B]"}`}>
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-5">
          {tab === "targets" && (
            <div className="rounded-md border overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="bg-[#0B2E6B] text-white">
                    <th className="px-2 py-2 text-center w-8">S.No</th>
                    <th className="px-2 py-2 text-left">Performance Metric</th>
                    <th className="px-2 py-2 text-center w-16">Yearly Target</th>
                    <th className="px-2 py-2 text-center w-20">Target (Till Month)</th>
                    <th className="px-2 py-2 text-center w-20">Achieved</th>
                    <th className="px-2 py-2 text-center w-16">Pending</th>
                    <th className="px-2 py-2 text-center w-20">Achievement %</th>
                    <th className="px-2 py-2 text-center w-8"></th>
                  </tr>
                </thead>
                <tbody>
                  {rd.targetVsAchievement.map((r, i) => (
                    <tr key={i} className={`border-b ${i % 2 === 0 ? "bg-white" : "bg-[#f8f9fc]"}`}>
                      <td className="px-2 py-1 text-center font-semibold text-[#0B2E6B]">{r.sno}</td>
                      <td className="px-2 py-1 font-medium">{r.metric}</td>
                      <td className="px-2 py-1"><Input type="number" value={r.yearlyTarget} onChange={e => updateTarget(i, "yearlyTarget", Number(e.target.value))} className="h-7 text-center text-xs" /></td>
                      <td className="px-2 py-1"><Input type="number" value={r.targetTillMonth} onChange={e => updateTarget(i, "targetTillMonth", Number(e.target.value))} className="h-7 text-center text-xs" /></td>
                      <td className="px-2 py-1"><Input type="number" value={r.achieved} onChange={e => updateTarget(i, "achieved", Number(e.target.value))} className="h-7 text-center text-xs" /></td>
                      <td className="px-2 py-1 text-center font-medium">{r.pending}</td>
                      <td className="px-2 py-1 text-center font-semibold">{r.achievementPct}</td>
                      <td className="px-2 py-1 text-center">
                        <button onClick={() => setRd(prev => ({ ...prev, targetVsAchievement: prev.targetVsAchievement.filter((_, idx) => idx !== i).map((t, idx) => ({ ...t, sno: idx + 1 })) }))} className="text-red-500 hover:text-red-700 font-bold text-xs">X</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {tab === "detailed" && (
            <div className="space-y-4">
              {(["publications", "patents", "research", "studentActivities"] as const).map(section => {
                const titles = { publications: "PUBLICATIONS", patents: "PATENTS", research: "RESEARCH & PROJECTS", studentActivities: "STUDENT ACTIVITIES" };
                return (
                  <Card key={section} className="border-[#0B2E6B]/20">
                    <CardHeader className="pb-2 bg-[#f8f9fc] flex flex-row items-center justify-between">
                      <CardTitle className="text-xs font-bold text-[#0B2E6B]">{titles[section]}</CardTitle>
                      <Button size="sm" onClick={() => addDetail(section)} className="bg-[#E67E22] hover:bg-[#d35400] text-white text-[10px] h-6">+ Add</Button>
                    </CardHeader>
                    <CardContent className="pt-3 space-y-2">
                      {rd.detailedSummary[section].map((item, i) => (
                        <div key={i} className="flex items-center gap-2">
                          <Input value={item.label} onChange={e => updateDetail(section, i, "label", e.target.value)} className="h-7 text-xs flex-1" placeholder="Label" />
                          <Input type="number" value={item.value} onChange={e => updateDetail(section, i, "value", Number(e.target.value))} className="h-7 text-xs w-20 text-center" />
                          <button onClick={() => removeDetail(section, i)} className="text-red-500 hover:text-red-700 text-xs font-bold">X</button>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}

          {tab === "monthwise" && (
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-bold text-[#0B2E6B]">Month-wise Progress Overview</h3>
                <Button size="sm" onClick={addMonthWise} className="bg-[#E67E22] hover:bg-[#d35400] text-white text-xs">+ Add Row</Button>
              </div>
              <div className="rounded-md border overflow-x-auto">
                <table className="w-full text-[10px]">
                  <thead>
                    <tr className="bg-[#0B2E6B] text-white">
                      <th className="px-2 py-1.5 text-left w-24">Metric</th>
                      {["Jun","Jul","Aug","Sep","Oct","Nov","Dec","Jan","Feb","Mar","Apr","May"].map(m => (
                        <th key={m} className="px-1.5 py-1.5 text-center w-12">{m}</th>
                      ))}
                      <th className="px-2 py-1.5 text-center w-8"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {rd.monthWise.map((r, i) => (
                      <tr key={i} className={`border-b ${i % 2 === 0 ? "bg-white" : "bg-[#f8f9fc]"}`}>
                        <td className="px-2 py-1"><Input value={r.metric} onChange={e => setRd(prev => { const mw = [...prev.monthWise]; mw[i] = { ...mw[i], metric: e.target.value }; return { ...prev, monthWise: mw }; })} className="h-6 text-[10px]" placeholder="Metric name" /></td>
                        {r.months.map((v, mi) => (
                          <td key={mi} className="px-1 py-1"><Input type="number" value={v === "-" ? "" : v} onChange={e => updateMonthWise(i, mi, e.target.value ? Number(e.target.value) : "-")} className="h-6 text-[10px] text-center" placeholder="-" /></td>
                        ))}
                        <td className="px-1 py-1 text-center"><button onClick={() => removeMonthWise(i)} className="text-red-500 hover:text-red-700 font-bold">X</button></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {tab === "remarks" && (
            <div>
              <label className={lbl}>Remarks by HOD</label>
              <textarea value={rd.remarks} onChange={e => setRd(prev => ({ ...prev, remarks: e.target.value }))}
                className="w-full mt-2 rounded-md border bg-transparent px-3 py-2 text-sm min-h-[150px] focus:outline-none focus:ring-2 focus:ring-[#0B2E6B]/30"
                placeholder="Enter remarks..." />
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 p-4 border-t bg-[#f8f9fc] shrink-0">
          <Button onClick={() => onSave(rd)} className="bg-[#0B2E6B] hover:bg-[#1D4E89] text-white"><Save className="h-4 w-4 mr-1" />Save & Export PDF</Button>
          <label className="flex items-center gap-1.5 ml-2 cursor-pointer">
            <span className="text-[10px] text-muted-foreground">Detailed Summary</span>
            <button type="button" onClick={() => setIncludeDetailedSummary(!includeDetailedSummary)}
              className={`relative inline-flex h-4 w-7 items-center rounded-full transition-colors ${includeDetailedSummary ? "bg-[#0B2E6B]" : "bg-gray-300"}`}>
              <span className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform ${includeDetailedSummary ? "translate-x-3.5" : "translate-x-0.5"}`} />
            </button>
          </label>
          <div className="flex-1" />
          <Button size="sm" onClick={handlePDF} className="bg-red-600 hover:bg-red-700 text-white"><FileText className="h-4 w-4 mr-1" />PDF</Button>
          <Button size="sm" onClick={handleExcel} className="bg-green-600 hover:bg-green-700 text-white">Excel</Button>
          <Button size="sm" onClick={handleCSV} variant="outline">CSV</Button>
          <Button size="sm" onClick={handlePrint} variant="outline">Print</Button>
        </div>
      </div>
    </div>
  );
}
