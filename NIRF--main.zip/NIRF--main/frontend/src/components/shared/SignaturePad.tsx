"use client";

export function SignaturePad() {
  return null;
}
