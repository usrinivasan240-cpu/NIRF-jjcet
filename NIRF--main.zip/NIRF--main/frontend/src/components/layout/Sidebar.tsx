"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { useAppStore, useAuthStore } from "@/store";
import { canView, ModuleAccess } from "@/lib/access";
import { Role } from "@/types";
import { firestoreService } from "@/lib/firestore";
import { useState, useEffect } from "react";
import {
  LayoutDashboard, Building2, Users, BookOpen, Lightbulb, FlaskConical,
  GraduationCap, Calendar, ClipboardCheck, Target, FolderOpen,
  BarChart3, Brain, Bell, Settings, FileText, ChevronLeft, ChevronRight,
  UserCog, Palette, Crosshair, PieChart,
} from "lucide-react";

interface NavItem {
  name: string;
  href: string;
  icon: any;
  module: keyof ModuleAccess;
}

const iconMap: Record<string, any> = {
  LayoutDashboard, Building2, Users, BookOpen, Lightbulb, FlaskConical,
  GraduationCap, Calendar, ClipboardCheck, Target, FolderOpen,
  BarChart3, Brain, Bell, Settings, FileText, UserCog, Palette, Crosshair, PieChart,
};

const allNavigation: NavItem[] = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard, module: "dashboard" },
  { name: "Departments", href: "/departments", icon: Building2, module: "departments" },
  { name: "Faculty", href: "/faculty", icon: Users, module: "faculty" },
  { name: "Publications", href: "/publications", icon: BookOpen, module: "publications" },
  { name: "Patents", href: "/patents", icon: Lightbulb, module: "patents" },
  { name: "Research", href: "/research", icon: FlaskConical, module: "research" },
  { name: "PhD Scholars", href: "/phd", icon: GraduationCap, module: "phd" },
  { name: "Students", href: "/students", icon: GraduationCap, module: "students" },
  { name: "Events", href: "/events", icon: Calendar, module: "events" },
  { name: "Monthly Reviews", href: "/reviews", icon: ClipboardCheck, module: "reviews" },
  { name: "Targets", href: "/targets", icon: Target, module: "targets" },
  { name: "VP Targets", href: "/vp-targets", icon: Crosshair, module: "vpTargets" },
  { name: "Dept Analysis", href: "/department-analysis", icon: PieChart, module: "deptAnalysis" },
  { name: "Documents", href: "/documents", icon: FolderOpen, module: "documents" },
  { name: "Reports", href: "/reports", icon: FileText, module: "reports" },
  { name: "Analytics", href: "/analytics", icon: BarChart3, module: "analytics" },
  { name: "AI Insights", href: "/ai", icon: Brain, module: "ai" },
  { name: "Notifications", href: "/notifications", icon: Bell, module: "notifications" },
  { name: "User Management", href: "/users", icon: UserCog, module: "userManagement" },
  { name: "College Branding", href: "/branding", icon: Palette, module: "branding" },
  { name: "Page Controller", href: "/page-control", icon: Settings, module: "pageControl" },
  { name: "Settings", href: "/settings", icon: Settings, module: "settings" },
];

export function Sidebar() {
  const pathname = usePathname();
  const { sidebarOpen, toggleSidebar } = useAppStore();
  const { user } = useAuthStore();
  const role = user?.role as Role | undefined;
  const [pageConfig, setPageConfig] = useState<any[]>([]);

  useEffect(() => {
    firestoreService.pageControl.getAll().then(setPageConfig).catch(() => {});
  }, []);

  const navigation = (() => {
    if (!role) return allNavigation;
    if (pageConfig.length > 0) {
      return allNavigation.filter(item => {
        const cfg = pageConfig.find((p: any) => p.path === item.href);
        if (cfg) return cfg.roles?.includes(role);
        return canView(role, item.module);
      });
    }
    return allNavigation.filter(item => canView(role, item.module));
  })();

  return (
    <aside className={cn("fixed left-0 top-0 z-40 h-screen border-r bg-card transition-all duration-300", sidebarOpen ? "w-64" : "w-16")}>
      <div className="flex h-full flex-col">
        <div className="flex h-16 items-center justify-between border-b px-4">
          {sidebarOpen && (
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold text-sm">N</div>
              <span className="text-lg font-bold">NIRF ERP Pro</span>
            </div>
          )}
          <button onClick={toggleSidebar} className="rounded-md p-1.5 hover:bg-muted">
            {sidebarOpen ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-1 px-2">
            {navigation.map((item) => {
              const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
              return (
                <li key={item.name}>
                  <Link href={item.href} className={cn("flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors", isActive ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground")}>
                    <item.icon className="h-5 w-5 flex-shrink-0" />
                    {sidebarOpen && <span>{item.name}</span>}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
        {sidebarOpen && role && (
          <div className="border-t p-4">
            <div className="text-xs text-muted-foreground">Logged in as</div>
            <div className="text-sm font-medium truncate">{user?.name}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{role.replace(/_/g, " ")}</div>
            {user?.department && <div className="text-xs text-primary mt-0.5">{user.department}</div>}
          </div>
        )}
      </div>
    </aside>
  );
}
