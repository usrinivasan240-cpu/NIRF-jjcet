"use client";

import { Sidebar } from "./Sidebar";
import { Header } from "./Header";
import { RouteGuard } from "@/components/shared/RouteGuard";
import { useAppStore } from "@/store";
import { cn } from "@/lib/utils";

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { sidebarOpen } = useAppStore();

  return (
    <RouteGuard>
      <div className="min-h-screen bg-background">
        <Sidebar />
        <div className={cn("transition-all duration-300", sidebarOpen ? "ml-64" : "ml-16")}>
          <Header />
          <main className="p-6">{children}</main>
        </div>
      </div>
    </RouteGuard>
  );
}
