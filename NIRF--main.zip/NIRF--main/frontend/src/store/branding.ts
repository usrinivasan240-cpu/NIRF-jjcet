import { create } from "zustand";

export interface CollegeBranding {
  id: string;
  collegeName: string;
  shortName: string;
  logo: string | null;
  headerBanner: string | null;
  logoBase64?: string | null;
  bannerBase64?: string | null;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  website: string;
  email: string;
  phone: string;
  motto: string;
  principalName: string;
  established: string;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
}

interface BrandingState {
  branding: CollegeBranding | null;
  loading: boolean;
  error: string | null;
  fetchBranding: () => Promise<void>;
  updateBranding: (id: string, data: Partial<CollegeBranding>) => Promise<void>;
  uploadLogo: (id: string, file: File) => Promise<void>;
  uploadBanner: (id: string, file: File) => Promise<void>;
}

const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000";

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("token");
}

export const useBrandingStore = create<BrandingState>((set, get) => ({
  branding: null,
  loading: false,
  error: null,

  fetchBranding: async () => {
    set({ loading: true, error: null });
    try {
      const token = getToken();
      const headers: Record<string, string> = {};
      if (token) headers.Authorization = `Bearer ${token}`;

      const res = await fetch(`${API}/api/branding/active-with-images`, { headers });
      const json = await res.json();
      if (json.success && json.data) {
        set({ branding: json.data, loading: false });
      } else {
        set({ branding: get().branding, loading: false });
      }
    } catch (err) {
      set({ error: "Failed to load branding", loading: false });
    }
  },

  updateBranding: async (id, data) => {
    set({ loading: true, error: null });
    try {
      const token = getToken();
      const res = await fetch(`${API}/api/branding/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify(data),
      });
      const json = await res.json();
      if (json.success && json.data) {
        set({ branding: json.data, loading: false });
      } else {
        set({ error: json.message || "Update failed", loading: false });
      }
    } catch (err) {
      set({ error: "Failed to update branding", loading: false });
    }
  },

  uploadLogo: async (id, file) => {
    set({ loading: true, error: null });
    try {
      const token = getToken();
      const formData = new FormData();
      formData.append("logo", file);
      const res = await fetch(`${API}/api/branding/${id}/logo`, {
        method: "POST",
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: formData,
      });
      const json = await res.json();
      if (json.success && json.data) {
        set({ branding: json.data, loading: false });
      } else {
        set({ error: json.message || "Upload failed", loading: false });
      }
    } catch (err) {
      set({ error: "Failed to upload logo", loading: false });
    }
  },

  uploadBanner: async (id, file) => {
    set({ loading: true, error: null });
    try {
      const token = getToken();
      const formData = new FormData();
      formData.append("banner", file);
      const res = await fetch(`${API}/api/branding/${id}/banner`, {
        method: "POST",
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: formData,
      });
      const json = await res.json();
      if (json.success && json.data) {
        set({ branding: json.data, loading: false });
      } else {
        set({ error: json.message || "Upload failed", loading: false });
      }
    } catch (err) {
      set({ error: "Failed to upload banner", loading: false });
    }
  },
}));
