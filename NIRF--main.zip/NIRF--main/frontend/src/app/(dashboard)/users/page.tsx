"use client";

import { useState, useEffect } from "react";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Plus, Search, Edit, Trash2, Shield, UserCheck, UserX, X, Building2, Eye, EyeOff, Lock } from "lucide-react";
import { useAuthStore } from "@/store";
import { canEdit } from "@/lib/access";
import { Role } from "@/types";

const DEPARTMENTS = ["IT", "CSE", "ECE", "EEE", "MECH", "CIVIL"];

const getRoleBadge = (role: string) => {
  const c: Record<string, string> = {
    SUPER_ADMIN: "bg-red-100 text-red-800",
    PRINCIPAL: "bg-purple-100 text-purple-800",
    VICE_PRINCIPAL: "bg-blue-100 text-blue-800",
    HOD: "bg-green-100 text-green-800",
    DEPARTMENT_STAFF: "bg-gray-100 text-gray-800",
  };
  return c[role] || "bg-gray-100 text-gray-800";
};

const emptyForm = { name: "", email: "", role: "DEPARTMENT_STAFF", department: "", status: "active", password: "" };

export default function UsersPage() {
  const { user } = useAuthStore();
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [users, setUsers] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  const canManageUsers = user && canEdit(user.role as Role, "userManagement");

  useEffect(() => {
    if (canManageUsers) {
      firestoreService.users.getAll().then(setUsers);
    }
  }, [canManageUsers]);

  const filtered = users.filter((u) => {
    const matchS = u.name?.toLowerCase().includes(search.toLowerCase()) || u.email?.toLowerCase().includes(search.toLowerCase());
    const matchR = roleFilter === "all" || u.role === roleFilter;
    return matchS && matchR;
  });

  const openAdd = () => { setEditItem(null); setForm(emptyForm); setShowForm(true); };
  const openEdit = (u: any) => { setEditItem(u); setForm({ name: u.name || "", email: u.email || "", role: u.role || "DEPARTMENT_STAFF", department: u.department || "", status: u.status || "active", password: "" }); setShowForm(true); };

  const handleSave = async () => {
    if (!form.name || !form.email) return;
    setSaving(true);
    try {
      if (editItem) {
        const updateData: any = { name: form.name, email: form.email, role: form.role, department: form.department, status: form.status };
        if (form.password) updateData.password = form.password;
        await firestoreService.users.update(editItem.id, updateData);
        setUsers(users.map(u => u.id === editItem.id ? { ...u, ...updateData } : u));
      } else {
        const data = { ...form, createdAt: new Date().toISOString() };
        const id = await firestoreService.users.create(data);
        setUsers([...users, { id, ...data }]);
      }
      setShowForm(false);
      setForm(emptyForm);
      setEditItem(null);
    } catch (err) {
      console.error("Save failed:", err);
    }
    setSaving(false);
  };

  const handleDelete = async (id: string) => {
    try {
      await firestoreService.users.delete(id);
      setUsers(users.filter(u => u.id !== id));
      setDeleteConfirm(null);
    } catch (err) {
      console.error("Delete failed:", err);
    }
  };

  const lbl = "text-xs font-semibold text-[#0B2E6B]";
  const inp = "h-8 text-xs";

  const AVAILABLE_ROLES = user?.role === "SUPER_ADMIN"
    ? ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"]
    : ["VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"];

  if (!canManageUsers) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center h-[60vh] gap-4">
          <Lock className="h-16 w-16 text-muted-foreground" />
          <h2 className="text-xl font-bold text-[#0B2E6B]">Access Denied</h2>
          <p className="text-muted-foreground text-center max-w-md">
            You do not have permission to manage users. Only Super Admin and Vice Principal can access this page.
          </p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">User Management</h1>
            <p className="text-muted-foreground">Create, edit, and manage all user accounts</p>
          </div>
          <Button onClick={openAdd} className="bg-[#0B2E6B] hover:bg-[#1D4E89] text-white">
            <Plus className="mr-2 h-4 w-4" />Add User
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Total</CardTitle><Shield className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{users.length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Active</CardTitle><UserCheck className="h-4 w-4 text-green-500" /></CardHeader><CardContent><div className="text-2xl font-bold">{users.filter(u => u.status === "active").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Suspended</CardTitle><UserX className="h-4 w-4 text-red-500" /></CardHeader><CardContent><div className="text-2xl font-bold">{users.filter(u => u.status === "suspended").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Departments</CardTitle><Building2 className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{new Set(users.map(u => u.department).filter(Boolean)).size}</div></CardContent></Card>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search users..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8" />
          </div>
          <select value={roleFilter} onChange={e => setRoleFilter(e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm">
            <option value="all">All Roles</option>
            {AVAILABLE_ROLES.map(r => <option key={r} value={r}>{r.replace(/_/g, " ")}</option>)}
          </select>
        </div>

        <div className="rounded-md border">
          <table className="w-full text-sm">
            <thead><tr className="border-b bg-[#f8f9fc]">
              <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Name</th>
              <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Email</th>
              <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Role</th>
              <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Department</th>
              <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Status</th>
              <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Actions</th>
            </tr></thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="p-8 text-center text-muted-foreground">No users found</td></tr>
              )}
              {filtered.map(u => (
                <tr key={u.id} className="border-b hover:bg-muted/50">
                  <td className="p-3 font-medium">{u.name}</td>
                  <td className="p-3 text-muted-foreground">{u.email}</td>
                  <td className="p-3"><Badge className={getRoleBadge(u.role)}>{u.role?.replace(/_/g, " ")}</Badge></td>
                  <td className="p-3">{u.department || "—"}</td>
                  <td className="p-3"><Badge variant={u.status === "active" ? "default" : "destructive"}>{u.status}</Badge></td>
                  <td className="p-3">
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => openEdit(u)}><Edit className="h-4 w-4" /></Button>
                      {deleteConfirm === u.id ? (
                        <div className="flex items-center gap-1">
                          <Button size="sm" variant="destructive" className="h-7 text-[10px]" onClick={() => handleDelete(u.id)}>Confirm</Button>
                          <Button size="sm" variant="outline" className="h-7 text-[10px]" onClick={() => setDeleteConfirm(null)}>Cancel</Button>
                        </div>
                      ) : (
                        <Button size="sm" variant="ghost" onClick={() => setDeleteConfirm(u.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-3" onClick={() => setShowForm(false)}>
          <div className="bg-background rounded-xl shadow-2xl w-full max-w-md border border-[#0B2E6B]/20" onClick={e => e.stopPropagation()}>
            <div className="bg-[#0B2E6B] text-white p-4 flex items-center justify-between rounded-t-xl">
              <h2 className="text-sm font-bold">{editItem ? "Edit User" : "Create New User"}</h2>
              <button onClick={() => setShowForm(false)} className="text-white/70 hover:text-white"><X className="h-4 w-4" /></button>
            </div>
            <div className="p-5 space-y-4">
              <div><Label className={lbl}>Full Name *</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className={inp} placeholder="Enter full name" /></div>
              <div><Label className={lbl}>Email *</Label><Input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} className={inp} placeholder="user@jjcet.edu" /></div>
              <div><Label className={lbl}>Role</Label>
                <select value={form.role} onChange={e => setForm({ ...form, role: e.target.value })} className="w-full h-8 rounded-md border bg-transparent px-3 text-xs">
                  {AVAILABLE_ROLES.map(r => <option key={r} value={r}>{r.replace(/_/g, " ")}</option>)}
                </select>
              </div>
              <div><Label className={lbl}>Department</Label>
                <select value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} className="w-full h-8 rounded-md border bg-transparent px-3 text-xs">
                  <option value="">None</option>
                  {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div><Label className={lbl}>Status</Label>
                <select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })} className="w-full h-8 rounded-md border bg-transparent px-3 text-xs">
                  <option value="active">Active</option>
                  <option value="suspended">Suspended</option>
                </select>
              </div>
              {!editItem && <div><Label className={lbl}>Password *</Label><div className="relative"><Input type={showPassword ? "text" : "password"} value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} className={inp + " pr-8"} placeholder="Min 6 characters" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground">{showPassword ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}</button></div></div>}
              {editItem && <div><Label className={lbl}>New Password (leave blank to keep)</Label><div className="relative"><Input type={showPassword ? "text" : "password"} value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} className={inp + " pr-8"} placeholder="Leave blank to keep current" /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground">{showPassword ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}</button></div></div>}
            </div>
            <div className="flex justify-end gap-2 p-4 border-t bg-[#f8f9fc] rounded-b-xl">
              <Button variant="outline" size="sm" onClick={() => setShowForm(false)}>Cancel</Button>
              <Button size="sm" onClick={handleSave} disabled={!form.name || !form.email || saving} className="bg-[#0B2E6B] hover:bg-[#1D4E89] text-white">
                {saving ? "Saving..." : editItem ? "Update User" : "Create User"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
