"use client";

import React from "react";
import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { Role } from "@/types";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Settings, Shield, Save, RotateCcw, CheckCircle, XCircle, Lock, Unlock } from "lucide-react";

interface PageConfig {
  id: string;
  path: string;
  label: string;
  icon: string;
  roles: string[];
  category: string;
}

const DEFAULT_PAGES: Omit<PageConfig, "id">[] = [
  { path: "/dashboard", label: "Dashboard", icon: "LayoutDashboard", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Core" },
  { path: "/faculty", label: "Faculty", icon: "Users", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD"], category: "People" },
  { path: "/students", label: "Students", icon: "GraduationCap", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "People" },
  { path: "/departments", label: "Departments", icon: "Building2", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL"], category: "Core" },
  { path: "/publications", label: "Publications", icon: "BookOpen", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Research" },
  { path: "/patents", label: "Patents", icon: "Lightbulb", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Research" },
  { path: "/research", label: "Research", icon: "FlaskConical", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Research" },
  { path: "/phd", label: "PhD Scholars", icon: "GraduationCap", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD"], category: "Research" },
  { path: "/events", label: "Events", icon: "Calendar", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Activities" },
  { path: "/reviews", label: "Monthly Reviews", icon: "ClipboardCheck", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Activities" },
  { path: "/targets", label: "Targets", icon: "Target", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD"], category: "Performance" },
  { path: "/vp-targets", label: "VP Targets", icon: "Target", roles: ["SUPER_ADMIN", "VICE_PRINCIPAL"], category: "Performance" },
  { path: "/department-analysis", label: "Dept Analysis", icon: "BarChart3", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL"], category: "Performance" },
  { path: "/reports", label: "Reports", icon: "FileText", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Reports" },
  { path: "/analytics", label: "Analytics", icon: "PieChart", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL"], category: "Reports" },
  { path: "/documents", label: "Documents", icon: "FolderOpen", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Core" },
  { path: "/users", label: "User Management", icon: "Shield", roles: ["SUPER_ADMIN", "VICE_PRINCIPAL"], category: "Admin" },
  { path: "/branding", label: "College Branding", icon: "Palette", roles: ["SUPER_ADMIN"], category: "Admin" },
  { path: "/page-control", label: "Page Controller", icon: "Settings", roles: ["SUPER_ADMIN"], category: "Admin" },
  { path: "/notifications", label: "Notifications", icon: "Bell", roles: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Core" },
  { path: "/settings", label: "Settings", icon: "Settings", roles: ["SUPER_ADMIN"], category: "Admin" },
];

const ROLES = ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"];
const ROLE_COLORS: Record<string, string> = {
  SUPER_ADMIN: "bg-red-100 text-red-800 border-red-300",
  PRINCIPAL: "bg-purple-100 text-purple-800 border-purple-300",
  VICE_PRINCIPAL: "bg-blue-100 text-blue-800 border-blue-300",
  HOD: "bg-green-100 text-green-800 border-green-300",
  DEPARTMENT_STAFF: "bg-gray-100 text-gray-800 border-gray-300",
};

export default function PageControlPage() {
  const { user } = useAuthStore();
  const [pages, setPages] = useState<PageConfig[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [expandedRole, setExpandedRole] = useState<string | null>(null);

  useEffect(() => {
    loadConfig();
  }, []);

  const loadConfig = async () => {
    try {
      const data = await firestoreService.pageControl.getAll();
      if (data.length > 0) {
        setPages(data as PageConfig[]);
      } else {
        const initialized = DEFAULT_PAGES.map((p, i) => ({ ...p, id: `page_${i}` }));
        setPages(initialized);
      }
    } catch {
      setPages(DEFAULT_PAGES.map((p, i) => ({ ...p, id: `page_${i}` })));
    }
    setLoading(false);
  };

  const toggleRole = (pageId: string, role: string) => {
    setPages(pages.map(p => {
      if (p.id !== pageId) return p;
      const has = p.roles.includes(role);
      return { ...p, roles: has ? p.roles.filter(r => r !== role) : [...p.roles, role] };
    }));
  };

  const toggleAllForRole = (role: string) => {
    const allHave = pages.every(p => p.roles.includes(role));
    setPages(pages.map(p => ({
      ...p,
      roles: allHave ? p.roles.filter(r => r !== role) : [...new Set([...p.roles, role])],
    })));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const existing = await firestoreService.pageControl.getAll();
      for (const e of existing) {
        await firestoreService.pageControl.delete(e.id);
      }
      for (const p of pages) {
        await firestoreService.pageControl.create({ path: p.path, label: p.label, icon: p.icon, roles: p.roles, category: p.category });
      }
    } catch (err) {
      console.error("Save failed:", err);
    }
    setSaving(false);
  };

  const handleReset = () => {
    setPages(DEFAULT_PAGES.map((p, i) => ({ ...p, id: `page_${i}` })));
  };

  const categories = [...new Set(pages.map(p => p.category))];

  const getPageCountForRole = (role: string) => pages.filter(p => p.roles.includes(role)).length;

  if (user?.role !== "SUPER_ADMIN") {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center h-[60vh] gap-4">
          <Lock className="h-16 w-16 text-muted-foreground" />
          <h2 className="text-xl font-bold text-[#0B2E6B]">Access Denied</h2>
          <p className="text-muted-foreground">Only Super Admin can access Page Controller.</p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Page Controller</h1>
            <p className="text-muted-foreground">Control which pages each role can access</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleReset}><RotateCcw className="h-4 w-4 mr-1" />Reset Defaults</Button>
            <Button size="sm" onClick={handleSave} disabled={saving} className="bg-[#0B2E6B] hover:bg-[#1D4E89] text-white">
              <Save className="h-4 w-4 mr-1" />{saving ? "Saving..." : "Save Configuration"}
            </Button>
          </div>
        </div>

        {/* Role Summary Cards */}
        <div className="grid gap-4 md:grid-cols-5">
          {ROLES.map(role => (
            <Card key={role} className={`cursor-pointer hover:shadow-md transition-shadow ${expandedRole === role ? "ring-2 ring-[#0B2E6B]" : ""}`} onClick={() => setExpandedRole(expandedRole === role ? null : role)}>
              <CardHeader className="pb-2">
                <CardTitle className="text-xs font-medium flex items-center justify-between">
                  <span>{role.replace(/_/g, " ")}</span>
                  <Badge className={ROLE_COLORS[role]}>{getPageCountForRole(role)}/{pages.length}</Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-1">
                  {pages.filter(p => p.roles.includes(role)).slice(0, 6).map(p => (
                    <span key={p.id} className="text-[9px] bg-[#0B2E6B]/10 text-[#0B2E6B] px-1 rounded">{p.label}</span>
                  ))}
                  {pages.filter(p => p.roles.includes(role)).length > 6 && (
                    <span className="text-[9px] text-muted-foreground">+{pages.filter(p => p.roles.includes(role)).length - 6}</span>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Page Configuration Table */}
        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading configuration...</div>
        ) : (
          <div className="rounded-md border">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-[#f8f9fc]">
                  <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Page</th>
                  <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Category</th>
                  {ROLES.map(r => (
                    <th key={r} className="h-10 px-3 text-center font-medium text-xs text-[#0B2E6B]">
                      <div className="flex flex-col items-center">
                        <span>{r.replace(/_/g, " ").replace("DEPARTMENT ", "Dept ")}</span>
                        <button className="text-[9px] text-[#0B2E6B]/60 hover:text-[#0B2E6B] mt-0.5" onClick={(e) => { e.stopPropagation(); toggleAllForRole(r); }}>
                          {pages.every(p => p.roles.includes(r)) ? "Uncheck All" : "Check All"}
                        </button>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {categories.map(cat => (
                  <React.Fragment key={cat}>
                    <tr className="border-b bg-[#f8f9fc]/50">
                      <td colSpan={2 + ROLES.length} className="px-4 py-2 text-xs font-bold text-[#0B2E6B] uppercase tracking-wide">{cat}</td>
                    </tr>
                    {pages.filter(p => p.category === cat).map(page => (
                      <tr key={page.id} className="border-b hover:bg-muted/50">
                        <td className="p-3 font-medium">{page.label}</td>
                        <td className="p-3"><Badge variant="outline" className="text-[10px]">{page.category}</Badge></td>
                        {ROLES.map(role => (
                          <td key={role} className="p-3 text-center">
                            <button
                              onClick={() => toggleRole(page.id, role)}
                              className={`w-7 h-7 rounded-md border-2 transition-all flex items-center justify-center ${
                                page.roles.includes(role)
                                  ? "bg-[#0B2E6B] border-[#0B2E6B] text-white"
                                  : "bg-white border-gray-300 text-gray-300 hover:border-[#0B2E6B]/50"
                              }`}
                            >
                              {page.roles.includes(role) ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                            </button>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </React.Fragment>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
