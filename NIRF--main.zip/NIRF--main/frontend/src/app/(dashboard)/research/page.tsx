"use client";

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { Role } from "@/types";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, Edit, Trash2, FlaskConical } from "lucide-react";

export default function ResearchPage() {
  const { user } = useAuthStore();
  const isDeptRestricted = user?.role === Role.HOD || user?.role === Role.DEPARTMENT_STAFF;
  const [search, setSearch] = useState("");
  const [items, setItems] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [form, setForm] = useState({ title: "", pi: "", fundingAgency: "", amount: "", status: "ongoing", department: "", departmentId: "" });
  const [departments, setDepartments] = useState<any[]>([]);

  useEffect(() => {
    const dept = isDeptRestricted ? user?.department : undefined;
    firestoreService.research.getAll(dept).then(setItems);
    firestoreService.departments.getAll().then(setDepartments);
  }, []);

  const filtered = items.filter((i) => {
    if (user?.role === Role.DEPARTMENT_STAFF && i.createdBy !== user?.email) return false;
    if (user?.role === Role.HOD && i.department !== user?.department) return false;
    return i.title.toLowerCase().includes(search.toLowerCase());
  });

  const handleSave = async () => {
    if (editItem) {
      await firestoreService.research.update(editItem.id, form);
      setItems(items.map((i) => i.id === editItem.id ? { ...i, ...form } : i));
      setEditItem(null);
    } else {
      const data = { ...form, startDate: new Date().toISOString().split("T")[0], createdBy: user?.email || "", departmentId: user?.department || "" };
      const id = await firestoreService.research.create(data);
      setItems([...items, { id, ...data }]);
    }
    setForm({ title: "", pi: "", fundingAgency: "", amount: "", status: "ongoing", department: "", departmentId: "" });
    setShowAdd(false);
  };

  const handleDelete = async (id: string) => {
    await firestoreService.research.delete(id);
    setItems(items.filter((i) => i.id !== id));
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold">Research Projects</h1><p className="text-muted-foreground">Manage research projects</p></div>
          <Button onClick={() => setShowAdd(true)}><Plus className="mr-2 h-4 w-4" />Add Project</Button>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Total</CardTitle><FlaskConical className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Ongoing</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((i) => i.status === "ongoing").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Completed</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((i) => i.status === "completed").length}</div></CardContent></Card>
        </div>
        <div className="relative max-w-sm"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search projects..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8" /></div>
        <div className="rounded-md border">
          <table className="w-full text-sm">
            <thead><tr className="border-b"><th className="h-12 px-4 text-left font-medium">Title</th><th className="h-12 px-4 text-left font-medium">PI</th><th className="h-12 px-4 text-left font-medium">Agency</th><th className="h-12 px-4 text-left font-medium">Amount</th><th className="h-12 px-4 text-left font-medium">Status</th><th className="h-12 px-4 text-left font-medium">Actions</th></tr></thead>
            <tbody>{filtered.map((i) => (
              <tr key={i.id} className="border-b hover:bg-muted/50"><td className="p-4 font-medium">{i.title}</td><td className="p-4">{i.pi}</td><td className="p-4">{i.fundingAgency}</td><td className="p-4">{i.amount}</td>
                <td className="p-4"><Badge variant={i.status === "completed" ? "default" : i.status === "ongoing" ? "secondary" : "outline"}>{i.status}</Badge></td>
                <td className="p-4"><div className="flex gap-1"><Button size="sm" variant="ghost" onClick={() => { setEditItem(i); setForm({ title: i.title, pi: i.pi, fundingAgency: i.fundingAgency, amount: i.amount, status: i.status, department: i.department, departmentId: i.departmentId || "" }); setShowAdd(true); }}><Edit className="h-4 w-4" /></Button><Button size="sm" variant="ghost" onClick={() => handleDelete(i.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></div></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
        {showAdd && <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center"><Card className="w-full max-w-md"><CardHeader><CardTitle>{editItem ? "Edit" : "Add"} Project</CardTitle></CardHeader><CardContent className="space-y-4">
          <div><label className="text-sm font-medium">Title</label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
          <div><label className="text-sm font-medium">PI</label><Input value={form.pi} onChange={(e) => setForm({ ...form, pi: e.target.value })} /></div>
          <div><label className="text-sm font-medium">Funding Agency</label><Input value={form.fundingAgency} onChange={(e) => setForm({ ...form, fundingAgency: e.target.value })} /></div>
          <div><label className="text-sm font-medium">Amount</label><Input value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></div>
          <div><label className="text-sm font-medium">Department</label><select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={form.departmentId} onChange={(e) => { const dept = departments.find((d: any) => d.id === e.target.value); setForm({ ...form, department: dept?.name || "", departmentId: e.target.value }); }}><option value="">Select Department</option>{departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
          <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => { setShowAdd(false); setEditItem(null); }}>Cancel</Button><Button onClick={handleSave}>Save</Button></div>
        </CardContent></Card></div>}
      </div>
    </DashboardLayout>
  );
}
