"use client";

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { Role } from "@/types";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  FileText, FileSpreadsheet, Download, Printer, Eye, Search,
  BarChart3, BookOpen, Lightbulb, FlaskConical, GraduationCap,
  Award, Calendar, Briefcase, Building2, Target, ClipboardCheck,
  Users, TrendingUp, PieChart, FileDown, ArrowRight, Send, CheckCircle,
  XCircle, Lock, Clock, MessageSquare
} from "lucide-react";
import { ReportPreview } from "@/components/shared/ReportPreview";
import { MonthlyReportForm } from "@/components/shared/MonthlyReportForm";
import {
  generatePDF, generateExcel, generateCSV, printReport, fetchBranding,
  type ReportData, type TargetRow, type BrandingData
} from "@/lib/reportGenerator";
import { firestoreService } from "@/lib/firestore";

const DEPARTMENTS = ["All", "IT", "CSE", "ECE", "EEE", "MECH", "CIVIL"];
const YEARS = ["2024-2025", "2023-2024", "2022-2023"];
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

// HOD and Department Staff can only see their own department
function getDeptOptions(userRole?: string, userDept?: string): string[] {
  if (userRole === "HOD" || userRole === "DEPARTMENT_STAFF") {
    return userDept ? [userDept] : ["All"];
  }
  return DEPARTMENTS;
}

interface ReportType {
  id: string;
  name: string;
  description: string;
  icon: any;
  color: string;
  access: string[];
  category: string;
}

const REPORT_TYPES: ReportType[] = [
  { id: "dept_monthly", name: "Department Monthly Report", description: "Monthly department performance with all metrics", icon: ClipboardCheck, color: "bg-blue-100 text-blue-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Department" },
  { id: "dept_annual", name: "Department Annual Report", description: "Comprehensive annual department summary", icon: Calendar, color: "bg-green-100 text-green-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Department" },
  { id: "class_wise", name: "Class-wise Report", description: "Class-wise student performance and activities", icon: Users, color: "bg-purple-100 text-purple-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Student" },
  { id: "year_wise", name: "Year-wise Report", description: "Year-wise comparison across all metrics", icon: TrendingUp, color: "bg-orange-100 text-orange-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD"], category: "Student" },
  { id: "publications", name: "Publication Report", description: "All publications with quartile and indexing data", icon: BookOpen, color: "bg-indigo-100 text-indigo-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Research" },
  { id: "patents", name: "Patent Report", description: "Patent filings, grants, and pending status", icon: Lightbulb, color: "bg-yellow-100 text-yellow-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Research" },
  { id: "research", name: "Research Report", description: "Research projects, funding, and consultancy", icon: FlaskConical, color: "bg-teal-100 text-teal-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Research" },
  { id: "student_participation", name: "Student Participation Report", description: "Student events, competitions, and achievements", icon: Award, color: "bg-pink-100 text-pink-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Student" },
  { id: "events", name: "Event Report", description: "Workshops, conferences, FDPs conducted", icon: Calendar, color: "bg-cyan-100 text-cyan-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Events" },
  { id: "placements", name: "Placement Report", description: "Student placements with packages and roles", icon: Briefcase, color: "bg-emerald-100 text-emerald-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Student" },
  { id: "higher_education", name: "Higher Education Report", description: "Students pursuing higher studies abroad", icon: GraduationCap, color: "bg-violet-100 text-violet-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Student" },
  { id: "phd", name: "PhD Report", description: "PhD scholars progress and completion", icon: GraduationCap, color: "bg-amber-100 text-amber-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD"], category: "Research" },
  { id: "target_achievement", name: "Target Achievement Report", description: "Yearly vs achieved targets with monthly breakdown", icon: Target, color: "bg-rose-100 text-rose-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Performance" },
  { id: "nirf", name: "NIRF Report", description: "NIRF-ready comprehensive institutional report", icon: Building2, color: "bg-sky-100 text-sky-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL"], category: "Accreditation" },
  { id: "college_performance", name: "College Performance Report", description: "All departments performance comparison", icon: BarChart3, color: "bg-lime-100 text-lime-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL"], category: "Performance" },
  { id: "dashboard_snapshot", name: "Dashboard Snapshot", description: "Export current dashboard with KPIs and charts", icon: PieChart, color: "bg-fuchsia-100 text-fuchsia-700", access: ["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"], category: "Performance" },
];

async function generateReportData(reportId: string, user: any, filters: { dept: string; year: string; month: string }): Promise<ReportData> {
  const dept = filters.dept === "All" ? (user?.department || "CSE") : filters.dept;
  const deptName = dept === "All Departments" ? "All Departments" : dept;
  const now = new Date();
  const reportName = REPORT_TYPES.find(r => r.id === reportId)?.name || "Report";

  let depts: any[] = [], pubs: any[] = [], pats: any[] = [], fac: any[] = [], stu: any[] = [], p: any[] = [], ev: any[] = [], tgt: any[] = [];
  try {
    [depts, pubs, pats, fac, stu, p, ev, tgt] = await Promise.all([
      firestoreService.departments.getAll(),
      firestoreService.publications.getAll(),
      firestoreService.patents.getAll(),
      firestoreService.faculty.getAll(),
      firestoreService.students.getAll(),
      firestoreService.phd.getAll(),
      firestoreService.events.getAll(),
      firestoreService.targets.getAll(),
    ]);
  } catch (e) { /* use empty arrays */ }

  const filterByDept = (items: any[]) => {
    if (dept === "All Departments") return items;
    return items.filter(i => i.department === dept || i.departmentId === dept || i.dept === dept);
  };

  const myPubs = filterByDept(pubs);
  const myPats = filterByDept(pats);
  const myFac = filterByDept(fac);
  const myStu = filterByDept(stu);
  const myPhd = filterByDept(p);
  const myEv = filterByDept(ev);
  const myTgt = filterByDept(tgt);
  const myDept = depts.find(d => d.code === dept || d.name === dept);

  const monthIdx = ["January","February","March","April","May","June","July","August","September","October","November","December"].indexOf(filters.month);

  function buildTargets(metrics: { name: string; target: number; source: () => number }[]): TargetRow[] {
    return metrics.map((m, i) => {
      const achieved = m.source();
      const pending = Math.max(0, m.target - achieved);
      const pct = m.target > 0 ? ((achieved / m.target) * 100).toFixed(2) : "0.00";
      return { sno: i + 1, metric: m.name, yearlyTarget: m.target, targetTillMonth: m.target, achieved, pending, achievementPct: `${pct}%`, status: achieved >= m.target * 0.8 ? "ON TRACK" : "BEHIND" };
    });
  }

  const reportTargets: Record<string, TargetRow[]> = {
    dept_monthly: buildTargets([
      { name: "Research Paper Publications", target: 12, source: () => myPubs.filter(pb => new Date(pb.date || pb.createdAt).getMonth() === monthIdx).length },
      { name: "Patents Filed", target: myPats.length || 10, source: () => myPats.length },
      { name: "Research Projects", target: myPhd.filter(ph => ph.status !== "Completed").length || 5, source: () => myPhd.filter(ph => ph.status !== "Completed").length },
      { name: "Student Placements", target: 120, source: () => myStu.filter(s => s.status === "placed" || s.placement).length },
      { name: "Events Conducted", target: myEv.length || 10, source: () => myEv.length },
      { name: "Faculty Count", target: myFac.length || 20, source: () => myFac.length },
      { name: "Student Strength", target: myStu.length || 200, source: () => myStu.length },
      { name: "PhD Pursuing", target: myPhd.filter(ph => ph.status !== "Completed").length || 5, source: () => myPhd.filter(ph => ph.status !== "Completed").length },
    ]),
    publications: buildTargets([
      { name: "Total Publications", target: myPubs.length + 10 || 30, source: () => myPubs.length },
      { name: "SCI/SCIE Journals", target: Math.ceil(myPubs.length * 0.4) || 10, source: () => myPubs.filter(pb => pb.type?.toLowerCase().includes("sci")).length },
      { name: "Scopus Indexed", target: Math.ceil(myPubs.length * 0.3) || 8, source: () => myPubs.filter(pb => pb.type?.toLowerCase().includes("scopus")).length },
      { name: "Conference Papers", target: Math.ceil(myPubs.length * 0.2) || 5, source: () => myPubs.filter(pb => pb.type?.toLowerCase().includes("conference")).length },
    ]),
    patents: buildTargets([
      { name: "Patents Filed", target: myPats.length + 5 || 10, source: () => myPats.length },
      { name: "Patents Granted", target: Math.ceil(myPats.length * 0.4) || 3, source: () => myPats.filter(pt => pt.status === "Granted").length },
      { name: "Patents Published", target: Math.ceil(myPats.length * 0.3) || 3, source: () => myPats.filter(pt => pt.status === "Published").length },
    ]),
    research: buildTargets([
      { name: "Ongoing Projects", target: myPhd.filter(ph => ph.status !== "Completed").length + 2 || 5, source: () => myPhd.filter(ph => ph.status !== "Completed").length },
      { name: "Completed Projects", target: myPhd.filter(ph => ph.status === "Completed").length + 2 || 3, source: () => myPhd.filter(ph => ph.status === "Completed").length },
    ]),
    events: buildTargets([
      { name: "Events Conducted", target: myEv.length + 5 || 10, source: () => myEv.length },
      { name: "Workshops", target: Math.ceil(myEv.length * 0.3) || 3, source: () => myEv.filter(e => e.type === "Workshop").length },
      { name: "Conferences", target: Math.ceil(myEv.length * 0.2) || 2, source: () => myEv.filter(e => e.type === "Conference").length },
      { name: "FDP Programs", target: Math.ceil(myEv.length * 0.2) || 2, source: () => myEv.filter(e => e.type === "FDP").length },
    ]),
    students: buildTargets([
      { name: "Total Students", target: myStu.length + 10 || 200, source: () => myStu.length },
      { name: "Achievements", target: Math.ceil(myStu.length * 0.2) || 20, source: () => myStu.filter(s => s.category === "Achievement").length },
    ]),
    dept_annual: buildTargets([
      { name: "Total Publications", target: myPubs.length + 20 || 50, source: () => myPubs.length },
      { name: "Total Patents", target: myPats.length + 5 || 15, source: () => myPats.length },
      { name: "Total Faculty", target: myFac.length + 2 || 25, source: () => myFac.length },
      { name: "Total Students", target: myStu.length + 20 || 300, source: () => myStu.length },
      { name: "Events Conducted", target: myEv.length + 10 || 25, source: () => myEv.length },
    ]),
    nirf: buildTargets([
      { name: "Teaching Learning Resources", target: 100, source: () => myDept?.nirfScore || 70 },
      { name: "Research & Professional Practice", target: 100, source: () => Math.round((myPubs.length / 50) * 100) || 60 },
      { name: "Graduation Outcomes", target: 100, source: () => 80 },
      { name: "Outreach & Inclusivity", target: 100, source: () => 75 },
      { name: "Perception", target: 100, source: () => 65 },
    ]),
    college_performance: buildTargets(depts.map(d => ({ name: d.code || d.name, target: 100, source: () => d.nirfScore || 70 }))),
    dashboard_snapshot: buildTargets([
      { name: "Total Students", target: stu.length + 50 || 600, source: () => stu.length },
      { name: "Total Faculty", target: fac.length + 5 || 30, source: () => fac.length },
      { name: "Departments", target: depts.length || 6, source: () => depts.length },
      { name: "Publications", target: pubs.length + 20 || 100, source: () => pubs.length },
      { name: "Patents", target: pats.length + 5 || 20, source: () => pats.length },
    ]),
  };

  const genericTarget = (cat: string) => buildTargets([{ name: cat, target: 10, source: () => myTgt.filter(t => t.category === cat).length || 5 }]);

  return {
    header: {
      reportId: `JJCE/REP/${now.getFullYear()}-${String(now.getFullYear() + 1).slice(-2)}/${String(Math.floor(Math.random() * 9000) + 1000).padStart(4, "0")}`,
      reportType: reportName,
      academicYear: filters.year,
      generatedOn: `${String(now.getDate()).padStart(2, "0")}-${String(now.getMonth() + 1).padStart(2, "0")}-${now.getFullYear()} ${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")} ${now.getHours() >= 12 ? "PM" : "AM"}`,
      generatedBy: user?.name || "System",
    },
    departmentInfo: {
      deptName,
      month: `${filters.month} ${filters.year.split("-")[0]}`,
      totalFaculty: myFac.length || 0,
      totalStudents: myStu.length || 0,
      hodName: myDept?.hodName || "N/A",
      contact: myDept?.email || "",
      reportStatus: "Draft",
      submittedDate: "-",
    },
    targetVsAchievement: reportTargets[reportId] || genericTarget(reportName),
    detailedSummary: getDetailedSummary(reportId),
    monthWise: getMonthWiseData(reportId),
    remarks: getRemarks(reportId, deptName),
    signatures: {
      hod: { name: "HOD", designation: "Head of the Department", date: `${String(now.getDate()).padStart(2, "0")}-${String(now.getMonth() + 1).padStart(2, "0")}-${now.getFullYear()}`, userId: "", enabled: true },
      vp: { name: "Vice Principal", designation: "Vice Principal", date: `${String(now.getDate()).padStart(2, "0")}-${String(now.getMonth() + 1).padStart(2, "0")}-${now.getFullYear()}`, userId: "", enabled: true },
      principal: { name: "Principal", designation: "Principal", date: `${String(now.getDate()).padStart(2, "0")}-${String(now.getMonth() + 1).padStart(2, "0")}-${now.getFullYear()}`, userId: "", enabled: true },
    },
  };
}

function getDetailedSummary(_reportId: string): ReportData["detailedSummary"] {
  return {
    publications: [{ label: "Total Publications", value: 0 }],
    patents: [{ label: "Total Patents", value: 0 }],
    research: [{ label: "Total Projects", value: 0 }],
    studentActivities: [{ label: "Total Activities", value: 0 }],
  };
}

function getMonthWiseData(_reportId: string): ReportData["monthWise"] {
  return [
    { metric: "Metric 1", months: ["-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"] },
  ];
}

function getRemarks(_reportId: string, _deptName: string): string {
  return "";
}

interface Submission {
  id: string;
  reportId: string;
  reportName: string;
  department: string;
  year: string;
  month: string;
  submittedBy: string;
  submittedByName: string;
  submittedAt: string;
  status: "SUBMITTED" | "HOD_APPROVED" | "HOD_REJECTED" | "VP_VERIFIED" | "VP_REJECTED" | "PRINCIPAL_APPROVED" | "PRINCIPAL_REJECTED" | "LOCKED";
  hodComment?: string;
  hodApprovedBy?: string;
  hodApprovedAt?: string;
  vpComment?: string;
  vpVerifiedBy?: string;
  vpVerifiedAt?: string;
  principalComment?: string;
  principalApprovedBy?: string;
  principalApprovedAt?: string;
}

const STATUS_CONFIG: Record<string, { color: string; icon: any; label: string }> = {
  SUBMITTED: { color: "bg-yellow-100 text-yellow-800", icon: Clock, label: "Submitted" },
  HOD_APPROVED: { color: "bg-blue-100 text-blue-800", icon: CheckCircle, label: "HOD Approved" },
  HOD_REJECTED: { color: "bg-red-100 text-red-800", icon: XCircle, label: "HOD Rejected" },
  VP_VERIFIED: { color: "bg-purple-100 text-purple-800", icon: CheckCircle, label: "VP Verified" },
  VP_REJECTED: { color: "bg-red-100 text-red-800", icon: XCircle, label: "VP Rejected" },
  PRINCIPAL_APPROVED: { color: "bg-green-100 text-green-800", icon: CheckCircle, label: "Principal Approved" },
  PRINCIPAL_REJECTED: { color: "bg-red-100 text-red-800", icon: XCircle, label: "Principal Rejected" },
  LOCKED: { color: "bg-gray-100 text-gray-800", icon: Lock, label: "Locked" },
};

export default function ReportsPage() {
  const { user } = useAuthStore();
  const isHODorStaff = user?.role === "HOD" || user?.role === "DEPARTMENT_STAFF";
  const deptOptions = getDeptOptions(user?.role, user?.department);
  const [search, setSearch] = useState("");
  const [dept, setDept] = useState(isHODorStaff ? (user?.department || "All") : "All");
  const [year, setYear] = useState("2024-2025");
  const [month, setMonth] = useState("January");
  const [previewData, setPreviewData] = useState<ReportData | null>(null);
  const [editData, setEditData] = useState<ReportData | null>(null);
  const [activeCategory, setActiveCategory] = useState("All");
  const [branding, setBranding] = useState<BrandingData | null>(null);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [activeTab, setActiveTab] = useState<"generate" | "submissions">("generate");
  const [rejectComment, setRejectComment] = useState("");
  const [rejectId, setRejectId] = useState<string | null>(null);

  useEffect(() => {
    fetchBranding().then(setBranding);
    loadSubmissions();
  }, []);

  const loadSubmissions = async () => {
    try {
      const data = await firestoreService.submissions.getAll();
      setSubmissions((data as unknown as Submission[]).sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime()));
    } catch (err) {
      console.error("Failed to load submissions:", err);
    }
  };

  const handleSubmit = async (reportId: string) => {
    const reportName = REPORT_TYPES.find(r => r.id === reportId)?.name || reportId;
    const sub: Omit<Submission, "id"> = {
      reportId,
      reportName,
      department: dept === "All" ? "All Departments" : dept,
      year,
      month,
      submittedBy: user?.email || "",
      submittedByName: user?.name || user?.email || "",
      submittedAt: new Date().toISOString(),
      status: "SUBMITTED",
    };
    const id = await firestoreService.submissions.create(sub);
    setSubmissions([{ id, ...sub }, ...submissions]);
  };

  const handleApprove = async (sub: Submission, action: "approve" | "reject", comment?: string) => {
    const now = new Date().toISOString();
    const updates: Partial<Submission> = {};
    if (user?.role === Role.HOD) {
      updates.status = action === "approve" ? "HOD_APPROVED" : "HOD_REJECTED";
      updates.hodApprovedBy = user.name || user.email;
      updates.hodApprovedAt = now;
      if (comment) updates.hodComment = comment;
    } else if (user?.role === Role.VICE_PRINCIPAL) {
      updates.status = action === "approve" ? "VP_VERIFIED" : "VP_REJECTED";
      updates.vpVerifiedBy = user.name || user.email;
      updates.vpVerifiedAt = now;
      if (comment) updates.vpComment = comment;
    } else if (user?.role === Role.PRINCIPAL) {
      updates.status = action === "approve" ? "PRINCIPAL_APPROVED" : "PRINCIPAL_REJECTED";
      updates.principalApprovedBy = user.name || user.email;
      updates.principalApprovedAt = now;
      if (comment) updates.principalComment = comment;
    }
    await firestoreService.submissions.update(sub.id, updates);
    setSubmissions(submissions.map(s => s.id === sub.id ? { ...s, ...updates } : s));
    setRejectId(null);
    setRejectComment("");
  };

  const getVisibleSubmissions = () => {
    if (user?.role === Role.SUPER_ADMIN || user?.role === Role.PRINCIPAL) return submissions;
    if (user?.role === Role.VICE_PRINCIPAL) return submissions.filter(s => s.status === "HOD_APPROVED" || s.status === "VP_VERIFIED" || s.status === "VP_REJECTED");
    if (user?.role === Role.HOD) return submissions.filter(s => s.status === "SUBMITTED" || s.status === "HOD_APPROVED" || s.status === "HOD_REJECTED");
    return submissions.filter(s => s.submittedBy === user?.email);
  };

  const categories = ["All", ...new Set(REPORT_TYPES.map((r) => r.category))];

  const visibleReports = REPORT_TYPES.filter((r) => {
    if (!r.access.includes(user?.role || "")) return false;
    if (activeCategory !== "All" && r.category !== activeCategory) return false;
    if (search && !r.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const handlePreview = async (reportId: string) => {
    const data = await generateReportData(reportId, user, { dept, year, month });
    setEditData(data);
  };

  const handleExport = async (reportId: string, format: "pdf" | "excel" | "csv" | "print") => {
    const data = await generateReportData(reportId, user, { dept, year, month });
    const name = `${REPORT_TYPES.find((r) => r.id === reportId)?.name?.replace(/\s+/g, "_")}_${year}`;
    const b = await fetchBranding();
    switch (format) {
      case "pdf": await generatePDF(data, name, b, undefined, { includeDetailedSummary: true }); break;
      case "excel": generateExcel(data, name, b); break;
      case "csv": generateCSV(data, name, b); break;
      case "print": printReport(data, b, undefined); break;
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Report Generation Engine</h1>
            <p className="text-muted-foreground">Generate professional PDF, Excel, CSV, and Print-ready reports</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b">
          <button
            onClick={() => setActiveTab("generate")}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "generate" ? "border-[#0B2E6B] text-[#0B2E6B]" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <FileText className="inline h-4 w-4 mr-1" />Generate Reports
          </button>
          <button
            onClick={() => setActiveTab("submissions")}
            className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
              activeTab === "submissions" ? "border-[#0B2E6B] text-[#0B2E6B]" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <Send className="inline h-4 w-4 mr-1" />Submissions
            {submissions.filter(s => s.status === "SUBMITTED").length > 0 && (
              <span className="ml-1 px-1.5 py-0.5 text-[10px] bg-yellow-500 text-white rounded-full">{submissions.filter(s => s.status === "SUBMITTED").length}</span>
            )}
          </button>
        </div>

        {activeTab === "generate" && (
          <>
            {/* Filters */}
        <Card>
          <CardContent className="p-4">
            <div className="flex flex-wrap items-center gap-3">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search reports..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8" />
              </div>
              <select value={dept} onChange={(e) => setDept(e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm" disabled={isHODorStaff}>
                {deptOptions.map((d) => <option key={d} value={d}>{d === "All" ? "All Departments" : d}</option>)}
              </select>
              <select value={year} onChange={(e) => setYear(e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm">
                {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
              </select>
              <select value={month} onChange={(e) => setMonth(e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm">
                {MONTHS.map((m) => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>
          </CardContent>
        </Card>

        {/* Category tabs */}
        <div className="flex gap-2 flex-wrap">
          {categories.map((cat) => (
            <Button key={cat} size="sm" variant={activeCategory === cat ? "default" : "outline"} onClick={() => setActiveCategory(cat)}>
              {cat}
            </Button>
          ))}
        </div>

        {/* Report cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {visibleReports.map((report) => {
            const Icon = report.icon;
            return (
              <Card key={report.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg ${report.color}`}><Icon className="h-5 w-5" /></div>
                    <div className="flex-1">
                      <CardTitle className="text-sm">{report.name}</CardTitle>
                      <p className="text-xs text-muted-foreground mt-1">{report.description}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => handlePreview(report.id)}>
                      <Eye className="h-3 w-3 mr-1" />Preview
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 text-xs bg-red-50 hover:bg-red-100 text-red-700" onClick={() => handleExport(report.id, "pdf")}>
                      <FileText className="h-3 w-3 mr-1" />PDF
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 text-xs bg-green-50 hover:bg-green-100 text-green-700" onClick={() => handleExport(report.id, "excel")}>
                      <FileSpreadsheet className="h-3 w-3 mr-1" />Excel
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => handleExport(report.id, "csv")}>
                      <Download className="h-3 w-3 mr-1" />CSV
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => handleExport(report.id, "print")}>
                      <Printer className="h-3 w-3 mr-1" />Print
                    </Button>
                    {(user?.role === "DEPARTMENT_STAFF" || user?.role === "HOD") && (
                      <Button size="sm" className="h-7 text-xs bg-[#0B2E6B] hover:bg-[#1D4E89] text-white" onClick={() => handleSubmit(report.id)}>
                        <Send className="h-3 w-3 mr-1" />Submit
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {visibleReports.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>No reports found matching your filters</p>
          </div>
        )}
          </>
        )}

        {activeTab === "submissions" && (
          <div className="space-y-4">
            <h2 className="text-lg font-bold">Report Submissions & Approvals</h2>
            {getVisibleSubmissions().length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <Send className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No submissions found</p>
              </div>
            ) : (
              <div className="rounded-md border">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-[#f8f9fc]">
                      <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Report</th>
                      <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Department</th>
                      <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Period</th>
                      <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Submitted By</th>
                      <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Status</th>
                      <th className="h-10 px-4 text-left font-medium text-xs text-[#0B2E6B]">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {getVisibleSubmissions().map((sub) => {
                      const cfg = STATUS_CONFIG[sub.status] || STATUS_CONFIG.SUBMITTED;
                      const Icon = cfg.icon;
                      const canApprove = (user?.role === Role.HOD && sub.status === "SUBMITTED") ||
                        (user?.role === Role.VICE_PRINCIPAL && sub.status === "HOD_APPROVED") ||
                        (user?.role === Role.PRINCIPAL && sub.status === "VP_VERIFIED");
                      return (
                        <tr key={sub.id} className="border-b hover:bg-muted/50">
                          <td className="p-3 font-medium">{sub.reportName}</td>
                          <td className="p-3">{sub.department}</td>
                          <td className="p-3">{sub.month} {sub.year}</td>
                          <td className="p-3 text-muted-foreground">{sub.submittedByName}</td>
                          <td className="p-3">
                            <Badge className={cfg.color}><Icon className="h-3 w-3 mr-1" />{cfg.label}</Badge>
                          </td>
                          <td className="p-3">
                            {canApprove && (
                              <div className="flex gap-1">
                                {rejectId === sub.id ? (
                                  <div className="flex items-center gap-1">
                                    <Input
                                      placeholder="Comment..."
                                      value={rejectComment}
                                      onChange={(e) => setRejectComment(e.target.value)}
                                      className="h-7 text-xs w-32"
                                    />
                                    <Button size="sm" variant="destructive" className="h-7 text-[10px]" onClick={() => handleApprove(sub, "reject", rejectComment)}>
                                      Confirm
                                    </Button>
                                    <Button size="sm" variant="outline" className="h-7 text-[10px]" onClick={() => { setRejectId(null); setRejectComment(""); }}>
                                      Cancel
                                    </Button>
                                  </div>
                                ) : (
                                  <>
                                    <Button size="sm" className="h-7 text-[10px] bg-green-600 hover:bg-green-700 text-white" onClick={() => handleApprove(sub, "approve")}>
                                      <CheckCircle className="h-3 w-3 mr-1" />Approve
                                    </Button>
                                    <Button size="sm" variant="destructive" className="h-7 text-[10px]" onClick={() => setRejectId(sub.id)}>
                                      <XCircle className="h-3 w-3 mr-1" />Reject
                                    </Button>
                                  </>
                                )}
                              </div>
                            )}
                            {!canApprove && sub.status.includes("REJECTED") && (
                              <span className="text-xs text-red-600 flex items-center gap-1">
                                <MessageSquare className="h-3 w-3" />
                                {sub.hodComment || sub.vpComment || sub.principalComment || "Rejected"}
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>

      {previewData && (
        <ReportPreview
          data={previewData}
          onClose={() => setPreviewData(null)}
          onExportPDF={async () => { const b = await fetchBranding(); await generatePDF(previewData, undefined, b, undefined); }}
          onExportExcel={async () => { const b = await fetchBranding(); generateExcel(previewData, undefined, b); }}
          onExportCSV={async () => { const b = await fetchBranding(); generateCSV(previewData, undefined, b); }}
          onPrint={async () => { const b = await fetchBranding(); printReport(previewData, b, undefined); }}
        />
      )}

      {editData && (
        <MonthlyReportForm
          data={editData}
          onClose={() => setEditData(null)}
          onSave={async (updated) => { setEditData(null); const b = await fetchBranding(); await generatePDF(updated, undefined, b, undefined); }}
        />
      )}
    </DashboardLayout>
  );
}
