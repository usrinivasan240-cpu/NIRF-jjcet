"use client";

import { useState, useEffect } from "react";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, Check, CheckCheck } from "lucide-react";

export default function NotificationsPage() {
  const [items, setItems] = useState<any[]>([]);

  useEffect(() => {
    firestoreService.notifications.getAll().then(setItems);
  }, []);

  const markRead = async (id: string) => {
    await firestoreService.notifications.markRead(id);
    setItems(items.map((n) => n.id === id ? { ...n, isRead: true } : n));
  };

  const markAllRead = async () => {
    const unread = items.filter(n => !n.isRead);
    await Promise.all(unread.map(n => firestoreService.notifications.markRead(n.id)));
    setItems(items.map((n) => ({ ...n, isRead: true })));
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold">Notifications</h1><p className="text-muted-foreground">{items.filter((n) => !n.isRead).length} unread notifications</p></div>
          <Button variant="outline" onClick={markAllRead}><CheckCheck className="mr-2 h-4 w-4" />Mark all read</Button>
        </div>
        <div className="space-y-3">
          {items.map((n) => (
            <div key={n.id} className={`flex items-start gap-4 rounded-lg border p-4 ${!n.isRead ? "bg-primary/5 border-primary/20" : ""}`}>
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0"><Bell className="h-5 w-5 text-primary" /></div>
              <div className="flex-1">
                <div className="flex items-center gap-2"><p className="text-sm font-medium">{n.title}</p><Badge variant={n.type === "success" ? "default" : n.type === "warning" ? "destructive" : "secondary"}>{n.type}</Badge></div>
                <p className="text-sm text-muted-foreground mt-1">{n.message}</p>
                <p className="text-xs text-muted-foreground mt-2">{n.createdAt}</p>
              </div>
              {!n.isRead && <Button size="sm" variant="ghost" onClick={() => markRead(n.id)}><Check className="h-4 w-4" /></Button>}
            </div>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
