"use client";

import { useState, useEffect } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Chart } from "@/components/shared/Chart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { firestoreService } from "@/lib/firestore";
import { BarChart3, BookOpen, Lightbulb, Target, TrendingUp } from "lucide-react";

export default function AnalyticsPage() {
  const [departments, setDepartments] = useState<any[]>([]);
  const [publications, setPublications] = useState<any[]>([]);
  const [patents, setPatents] = useState<any[]>([]);
  const [targets, setTargets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      firestoreService.departments.getAll(),
      firestoreService.publications.getAll(),
      firestoreService.patents.getAll(),
      firestoreService.targets.getAll(),
    ]).then(([depts, pubs, pats, tgt]) => {
      setDepartments(depts);
      setPublications(pubs);
      setPatents(pats);
      setTargets(tgt);
      setLoading(false);
    });
  }, []);

  const totalPubs = publications.length;
  const totalPats = patents.length;
  const avgNirf = departments.length > 0 ? (departments.reduce((a, d) => a + (d.nirfScore || 0), 0) / departments.length).toFixed(1) : "0.0";
  const targetAchievement = targets.length > 0 ? Math.round(targets.reduce((a, t) => a + (t.yearly > 0 ? (t.achieved / t.yearly) * 100 : 0), 0) / targets.length) : 0;

  const deptPerf = departments.map(d => ({ name: d.code || d.name, value: d.nirfScore || 0 }));

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const monthlyPub = monthNames.map((m, i) => ({
    name: m,
    value: publications.filter(p => new Date(p.date || p.createdAt).getMonth() === i).length,
  }));

  const pubByType = [
    { name: "SCI", value: publications.filter(p => p.type?.toLowerCase().includes("sci") || p.indexing?.toLowerCase().includes("sci")).length || 0 },
    { name: "Scopus", value: publications.filter(p => p.type?.toLowerCase().includes("scopus") || p.indexing?.toLowerCase().includes("scopus")).length || 0 },
    { name: "UGC", value: publications.filter(p => p.type?.toLowerCase().includes("ugc") || p.indexing?.toLowerCase().includes("ugc")).length || 0 },
    { name: "Other", value: publications.filter(p => !p.type?.toLowerCase().includes("sci") && !p.type?.toLowerCase().includes("scopus") && !p.type?.toLowerCase().includes("ugc")).length || 0 },
  ];

  const quarters = [
    { name: "Q1", publications: publications.filter(p => { const m = new Date(p.date || p.createdAt).getMonth(); return m >= 0 && m <= 2; }).length, patents: patents.filter(p => { const m = new Date(p.filingDate || p.createdAt).getMonth(); return m >= 0 && m <= 2; }).length },
    { name: "Q2", publications: publications.filter(p => { const m = new Date(p.date || p.createdAt).getMonth(); return m >= 3 && m <= 5; }).length, patents: patents.filter(p => { const m = new Date(p.filingDate || p.createdAt).getMonth(); return m >= 3 && m <= 5; }).length },
    { name: "Q3", publications: publications.filter(p => { const m = new Date(p.date || p.createdAt).getMonth(); return m >= 6 && m <= 8; }).length, patents: patents.filter(p => { const m = new Date(p.filingDate || p.createdAt).getMonth(); return m >= 6 && m <= 8; }).length },
    { name: "Q4", publications: publications.filter(p => { const m = new Date(p.date || p.createdAt).getMonth(); return m >= 9 && m <= 11; }).length, patents: patents.filter(p => { const m = new Date(p.filingDate || p.createdAt).getMonth(); return m >= 9 && m <= 11; }).length },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Analytics</h1>
          <p className="text-muted-foreground">Institutional performance analytics</p>
        </div>

        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading analytics data...</div>
        ) : (
          <>
            <div className="grid gap-4 md:grid-cols-4">
              <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Total Publications</CardTitle><BookOpen className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{totalPubs}</div></CardContent></Card>
              <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Total Patents</CardTitle><Lightbulb className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{totalPats}</div></CardContent></Card>
              <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Avg NIRF Score</CardTitle><BarChart3 className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{avgNirf}</div></CardContent></Card>
              <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Target Achievement</CardTitle><Target className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{targetAchievement}%</div></CardContent></Card>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <Chart title="Department Performance" data={deptPerf.length > 0 ? deptPerf : [{ name: "No data", value: 0 }]} type="bar" />
              <Chart title="Publication Distribution" data={pubByType.some(p => p.value > 0) ? pubByType : [{ name: "No data", value: 0 }]} type="pie" />
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <Chart title="Monthly Publications" data={monthlyPub} type="bar" />
              <Chart title="Quarterly Trends" data={quarters} type="line" />
            </div>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
