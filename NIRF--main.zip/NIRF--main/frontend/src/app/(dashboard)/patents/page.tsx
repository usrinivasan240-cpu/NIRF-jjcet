"use client";

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { Role } from "@/types";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, Edit, Trash2, Lightbulb } from "lucide-react";

const statusColors: Record<string, string> = { granted: "bg-green-100 text-green-800", published: "bg-blue-100 text-blue-800", filed: "bg-yellow-100 text-yellow-800" };

export default function PatentsPage() {
  const { user } = useAuthStore();
  const isDeptRestricted = user?.role === Role.HOD || user?.role === Role.DEPARTMENT_STAFF;
  const [search, setSearch] = useState("");
  const [patents, setPatents] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [form, setForm] = useState({ title: "", country: "India", filedDate: "", department: "", departmentId: "" });
  const [departments, setDepartments] = useState<any[]>([]);

  useEffect(() => {
    const dept = isDeptRestricted ? user?.department : undefined;
    firestoreService.patents.getAll(dept).then(setPatents);
    firestoreService.departments.getAll().then(setDepartments);
  }, []);

  const filtered = patents.filter((p) => {
    if (user?.role === Role.DEPARTMENT_STAFF && p.createdBy !== user?.email) return false;
    if (user?.role === Role.HOD && p.department !== user?.department) return false;
    return p.title.toLowerCase().includes(search.toLowerCase());
  });

  const handleSave = async () => {
    if (editItem) {
      await firestoreService.patents.update(editItem.id, form);
      setPatents(patents.map((p) => p.id === editItem.id ? { ...p, ...form } : p));
      setEditItem(null);
    } else {
      const data = { ...form, isPublished: false, isGranted: false, status: "filed", createdBy: user?.email || "", departmentId: user?.department || "" };
      const id = await firestoreService.patents.create(data);
      setPatents([...patents, { id, ...data }]);
    }
    setForm({ title: "", country: "India", filedDate: "", department: "", departmentId: "" });
    setShowAdd(false);
  };

  const handleDelete = async (id: string) => {
    await firestoreService.patents.delete(id);
    setPatents(patents.filter((p) => p.id !== id));
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold">Patents</h1><p className="text-muted-foreground">Manage patent filings and grants</p></div>
          <Button onClick={() => setShowAdd(true)}><Plus className="mr-2 h-4 w-4" />Add Patent</Button>
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Total</CardTitle><Lightbulb className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Granted</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((p) => p.status === "granted").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Published</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((p) => p.status === "published").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Filed</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((p) => p.status === "filed").length}</div></CardContent></Card>
        </div>
        <div className="relative max-w-sm"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search patents..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8" /></div>
        <div className="rounded-md border">
          <table className="w-full text-sm">
            <thead><tr className="border-b"><th className="h-12 px-4 text-left font-medium">Title</th><th className="h-12 px-4 text-left font-medium">Patent No</th><th className="h-12 px-4 text-left font-medium">Country</th><th className="h-12 px-4 text-left font-medium">Filed</th><th className="h-12 px-4 text-left font-medium">Status</th><th className="h-12 px-4 text-left font-medium">Actions</th></tr></thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id} className="border-b hover:bg-muted/50">
                  <td className="p-4 font-medium">{p.title}</td><td className="p-4 text-muted-foreground">{p.patentNumber || "—"}</td><td className="p-4">{p.country}</td><td className="p-4">{p.filedDate}</td>
                  <td className="p-4"><Badge className={statusColors[p.status]}>{p.status}</Badge></td>
                  <td className="p-4"><div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={() => { setEditItem(p); setForm({ title: p.title, country: p.country, filedDate: p.filedDate, department: p.department, departmentId: p.departmentId || "" }); setShowAdd(true); }}><Edit className="h-4 w-4" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => handleDelete(p.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {showAdd && (
          <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
            <Card className="w-full max-w-md"><CardHeader><CardTitle>{editItem ? "Edit Patent" : "Add Patent"}</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div><label className="text-sm font-medium">Title</label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
                <div><label className="text-sm font-medium">Country</label><Input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} /></div>
                <div><label className="text-sm font-medium">Filed Date</label><Input type="date" value={form.filedDate} onChange={(e) => setForm({ ...form, filedDate: e.target.value })} /></div>
                <div><label className="text-sm font-medium">Department</label><select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={form.departmentId} onChange={(e) => { const dept = departments.find((d: any) => d.id === e.target.value); setForm({ ...form, department: dept?.name || "", departmentId: e.target.value }); }}><option value="">Select Department</option>{departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
                <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => { setShowAdd(false); setEditItem(null); }}>Cancel</Button><Button onClick={handleSave}>Save</Button></div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
