"use client";

import { useState, useEffect } from "react";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Target, Plus, Edit } from "lucide-react";

const months = ["Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"];

export default function TargetsPage() {
  const [items, setItems] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ category: "", yearly: 0 });

  useEffect(() => {
    firestoreService.targets.getAll().then(setItems);
  }, []);

  const handleSave = async () => {
    if (!form.category || !form.yearly) return;
    const id = await firestoreService.targets.create({
      category: form.category,
      yearly: form.yearly,
      achieved: 0,
      monthly: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    });
    setItems([...items, { id, category: form.category, yearly: form.yearly, achieved: 0, monthly: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0] }]);
    setForm({ category: "", yearly: 0 });
    setShowAdd(false);
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold">Targets</h1><p className="text-muted-foreground">Yearly and monthly department targets</p></div>
          <Button onClick={() => setShowAdd(true)}><Plus className="mr-2 h-4 w-4" />Add Target</Button>
        </div>
        {items.map((t) => (
          <Card key={t.id}>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">{t.category}</CardTitle>
              <div className="flex items-center gap-4">
                <span className="text-sm text-muted-foreground">Achieved: <span className="font-bold text-foreground">{t.achieved}/{t.yearly}</span> ({t.yearly > 0 ? Math.round((t.achieved / t.yearly) * 100) : 0}%)</span>
                <Button size="sm" variant="ghost"><Edit className="h-4 w-4" /></Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-3 h-3 rounded-full bg-muted overflow-hidden">
                <div className="h-full rounded-full bg-primary transition-all" style={{ width: `${t.yearly > 0 ? Math.min((t.achieved / t.yearly) * 100, 100) : 0}%` }} />
              </div>
              <div className="grid grid-cols-10 gap-2">
                {months.map((m, i) => (
                  <div key={m} className="text-center">
                    <div className="text-xs text-muted-foreground">{m}</div>
                    <div className="text-sm font-medium">{t.monthly[i]}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
        {showAdd && <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center"><Card className="w-full max-w-md"><CardHeader><CardTitle>Add Target</CardTitle></CardHeader><CardContent className="space-y-4">
          <div><label className="text-sm font-medium">Category</label><Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="e.g. Publications, Patents" /></div>
          <div><label className="text-sm font-medium">Yearly Target</label><Input type="number" value={form.yearly || ""} onChange={(e) => setForm({ ...form, yearly: Number(e.target.value) })} /></div>
          <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => setShowAdd(false)}>Cancel</Button><Button onClick={handleSave}>Save</Button></div>
        </CardContent></Card></div>}
      </div>
    </DashboardLayout>
  );
}
