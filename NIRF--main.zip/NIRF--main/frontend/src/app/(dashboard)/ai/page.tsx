"use client";

import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, AlertTriangle, TrendingUp, Target, BarChart3, Lightbulb } from "lucide-react";

const insights: { title: string; description: string; type: string; severity: string; icon: any }[] = [];

const severityColors: Record<string, string> = { high: "destructive", medium: "secondary", low: "default", info: "outline" };

export default function AiPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Brain className="h-8 w-8 text-primary" />
          <div><h1 className="text-2xl font-bold">AI Insights</h1><p className="text-muted-foreground">Smart predictions, risk detection, and performance analysis</p></div>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {insights.length === 0 ? (
            <div className="col-span-full text-center py-12 text-muted-foreground">
              <Brain className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No AI insights available yet. Insights will appear once sufficient data is collected.</p>
            </div>
          ) : (
            insights.map((i, idx) => (
              <Card key={idx} className="hover:shadow-md transition-shadow">
                <CardHeader className="flex flex-row items-start gap-3">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center"><i.icon className="h-5 w-5 text-primary" /></div>
                  <div className="flex-1"><CardTitle className="text-base">{i.title}</CardTitle><Badge variant={severityColors[i.severity] as any} className="mt-1">{i.severity}</Badge></div>
                </CardHeader>
                <CardContent><p className="text-sm text-muted-foreground">{i.description}</p></CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
