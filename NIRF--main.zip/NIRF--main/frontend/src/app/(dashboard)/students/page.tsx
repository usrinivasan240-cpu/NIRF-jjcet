"use client";

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { Role } from "@/types";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, Edit, Trash2, Award } from "lucide-react";

export default function StudentsPage() {
  const CATEGORIES = ["Achievement", "Hackathon", "Placement", "Higher Studies", "Participation", "Competition"];
  const { user } = useAuthStore();
  const isDeptRestricted = user?.role === Role.HOD || user?.role === Role.DEPARTMENT_STAFF;
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState("all");
  const [items, setItems] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [form, setForm] = useState({ name: "", category: "Achievement", title: "", year: 2024, department: "", departmentId: "" });
  const [departments, setDepartments] = useState<any[]>([]);

  const deptScope = isDeptRestricted ? user?.department : null;

  useEffect(() => {
    firestoreService.students.getAll(deptScope).then(setItems);
    firestoreService.departments.getAll().then(setDepartments);
  }, []);

  const filtered = items.filter((i) => {
    if (user?.role === Role.DEPARTMENT_STAFF && i.createdBy !== user?.email) return false;
    if (user?.role === Role.HOD && i.department !== user?.department) return false;
    const matchS = i.name.toLowerCase().includes(search.toLowerCase()) || i.title.toLowerCase().includes(search.toLowerCase());
    const matchC = catFilter === "all" || i.category === catFilter;
    return matchS && matchC;
  });

  const handleSave = async () => {
    if (editItem) {
      await firestoreService.students.update(editItem.id, form);
      setItems(items.map((i) => i.id === editItem.id ? { ...i, ...form } : i));
      setEditItem(null);
    } else {
      const id = await firestoreService.students.create({ ...form, createdBy: user?.email || "" });
      setItems([...items, { id, ...form, createdBy: user?.email || "" }]);
    }
    setForm({ name: "", category: "Achievement", title: "", year: 2024, department: "", departmentId: "" });
    setShowAdd(false);
  };

  const handleDelete = async (id: string) => {
    await firestoreService.students.delete(id);
    setItems(items.filter((i) => i.id !== id));
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold">Students</h1><p className="text-muted-foreground">Student achievements, participation & placements</p></div>
          <Button onClick={() => setShowAdd(true)}><Plus className="mr-2 h-4 w-4" />Add Record</Button>
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Total</CardTitle><Award className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Achievements</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((i) => i.category === "Achievement" || i.category === "Hackathon").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Placements</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((i) => i.category === "Placement").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Higher Studies</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((i) => i.category === "Higher Studies").length}</div></CardContent></Card>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-sm"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search students..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8" /></div>
          <select value={catFilter} onChange={(e) => setCatFilter(e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm"><option value="all">All Categories</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select>
        </div>
        <div className="rounded-md border">
          <table className="w-full text-sm">
            <thead><tr className="border-b"><th className="h-12 px-4 text-left font-medium">Name</th><th className="h-12 px-4 text-left font-medium">Category</th><th className="h-12 px-4 text-left font-medium">Title</th><th className="h-12 px-4 text-left font-medium">Year</th><th className="h-12 px-4 text-left font-medium">Actions</th></tr></thead>
            <tbody>{filtered.map((i) => (
              <tr key={i.id} className="border-b hover:bg-muted/50"><td className="p-4 font-medium">{i.name}</td><td className="p-4"><Badge variant="secondary">{i.category}</Badge></td><td className="p-4">{i.title}</td><td className="p-4">{i.year}</td>
                <td className="p-4"><div className="flex gap-1"><Button size="sm" variant="ghost" onClick={() => { setEditItem(i); setForm({ name: i.name, category: i.category, title: i.title, year: i.year, department: i.department, departmentId: i.departmentId || "" }); setShowAdd(true); }}><Edit className="h-4 w-4" /></Button><Button size="sm" variant="ghost" onClick={() => handleDelete(i.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></div></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
        {showAdd && <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center"><Card className="w-full max-w-md"><CardHeader><CardTitle>{editItem ? "Edit" : "Add"} Record</CardTitle></CardHeader><CardContent className="space-y-4">
          <div><label className="text-sm font-medium">Student Name</label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><label className="text-sm font-medium">Category</label><select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></div>
          <div><label className="text-sm font-medium">Title</label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
          <div><label className="text-sm font-medium">Department</label><select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={form.departmentId} onChange={(e) => { const dept = departments.find((d: any) => d.id === e.target.value); setForm({ ...form, department: dept?.name || "", departmentId: e.target.value }); }}><option value="">Select Department</option>{departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
          <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => { setShowAdd(false); setEditItem(null); }}>Cancel</Button><Button onClick={handleSave}>Save</Button></div>
        </CardContent></Card></div>}
      </div>
    </DashboardLayout>
  );
}
