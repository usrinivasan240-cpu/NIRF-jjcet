"use client";

import { useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings, Building2, Users, Database, User } from "lucide-react";

export default function SettingsPage() {
  const [collegeName, setCollegeName] = useState("JJ College of Engineering & Technology");
  const [academicYear, setAcademicYear] = useState("2024-2025");

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div><h1 className="text-2xl font-bold">Settings</h1><p className="text-muted-foreground">System configuration and preferences</p></div>
        <Tabs defaultValue="general" className="space-y-4">
          <TabsList>
            <TabsTrigger value="general"><Settings className="mr-2 h-4 w-4" />General</TabsTrigger>
            <TabsTrigger value="departments"><Building2 className="mr-2 h-4 w-4" />Departments</TabsTrigger>
            <TabsTrigger value="roles"><Users className="mr-2 h-4 w-4" />Roles</TabsTrigger>
            <TabsTrigger value="backup"><Database className="mr-2 h-4 w-4" />Backup</TabsTrigger>
            <TabsTrigger value="profile"><User className="mr-2 h-4 w-4" />Profile</TabsTrigger>
          </TabsList>
          <TabsContent value="general">
            <Card><CardHeader><CardTitle>General Settings</CardTitle></CardHeader><CardContent className="space-y-4">
              <div><label className="text-sm font-medium">College Name</label><Input value={collegeName} onChange={(e) => setCollegeName(e.target.value)} /></div>
              <div><label className="text-sm font-medium">Academic Year</label><Input value={academicYear} onChange={(e) => setAcademicYear(e.target.value)} /></div>
              <Button>Save Changes</Button>
            </CardContent></Card>
          </TabsContent>
          <TabsContent value="departments">
            <Card><CardHeader><CardTitle>Department Management</CardTitle></CardHeader><CardContent>
              <p className="text-sm text-muted-foreground mb-4">Manage department configurations</p>
              <Button>Add Department</Button>
            </CardContent></Card>
          </TabsContent>
          <TabsContent value="roles">
            <Card><CardHeader><CardTitle>Role Permissions</CardTitle></CardHeader><CardContent>
              <div className="space-y-3">
                {["SUPER_ADMIN", "PRINCIPAL", "VICE_PRINCIPAL", "HOD", "DEPARTMENT_STAFF"].map((r) => (
                  <div key={r} className="flex items-center justify-between rounded-md border p-3">
                    <span className="font-medium">{r.replace(/_/g, " ")}</span>
                    <Button size="sm" variant="outline">Configure</Button>
                  </div>
                ))}
              </div>
            </CardContent></Card>
          </TabsContent>
          <TabsContent value="backup">
            <Card><CardHeader><CardTitle>Backup & Restore</CardTitle></CardHeader><CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">Last backup: 2024-01-15 10:30 AM</p>
              <div className="flex gap-2"><Button>Create Backup</Button><Button variant="outline">Restore</Button></div>
            </CardContent></Card>
          </TabsContent>
          <TabsContent value="profile">
            <Card><CardHeader><CardTitle>User Profile</CardTitle></CardHeader><CardContent className="space-y-4">
              <div><label className="text-sm font-medium">Name</label><Input defaultValue="Super Admin" /></div>
              <div><label className="text-sm font-medium">Email</label><Input defaultValue="admin@jjcet.edu" /></div>
              <Button>Update Profile</Button>
            </CardContent></Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
