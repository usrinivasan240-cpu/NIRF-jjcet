"use client";

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Target, Plus, Edit, Trash2, Save, X, ChevronDown } from "lucide-react";

const CATEGORIES = [
  "Publications",
  "Patents Filed",
  "Patents Granted",
  "Research Projects",
  "Research Proposals",
  "Grants Received",
  "Consultancy Projects",
  "Events Conducted",
  "FDP/Workshops",
  "Student Placements",
  "Higher Studies",
  "Student Competitions",
  "Industry Collaborations",
  "MoUs Signed",
  "Conference Papers",
  "Book Chapters",
];

const DEPARTMENTS = [
  { id: "IT", name: "Information Technology" },
  { id: "CSE", name: "Computer Science & Engineering" },
  { id: "ECE", name: "Electronics & Communication" },
  { id: "EEE", name: "Electrical & Electronics" },
  { id: "MECH", name: "Mechanical Engineering" },
  { id: "CIVIL", name: "Civil Engineering" },
];

const YEARS = ["2025-2026", "2024-2025", "2023-2024", "2022-2023"];

interface TargetItem {
  id: string;
  departmentId: string;
  departmentName: string;
  category: string;
  yearlyTarget: number;
  achieved: number;
  year: string;
}

export default function VPTargetsPage() {
  const { user } = useAuthStore();
  const [targets, setTargets] = useState<TargetItem[]>([]);
  const [selectedDept, setSelectedDept] = useState("All");
  const [selectedYear, setSelectedYear] = useState("2024-2025");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ departmentId: "CSE", category: "Publications", yearlyTarget: 0 });

  useEffect(() => {
    firestoreService.vpTargets.getAll().then((data) => setTargets(data as TargetItem[]));
  }, []);

  const filtered = targets.filter(t => {
    if (selectedDept !== "All" && t.departmentId !== selectedDept) return false;
    if (t.year !== selectedYear) return false;
    return true;
  });

  const deptGroups = filtered.reduce<Record<string, TargetItem[]>>((acc, t) => {
    if (!acc[t.departmentId]) acc[t.departmentId] = [];
    acc[t.departmentId].push(t);
    return acc;
  }, {});

  const handleAdd = () => {
    setForm({ departmentId: "CSE", category: "Publications", yearlyTarget: 0 });
    setEditingId(null);
    setShowForm(true);
  };

  const handleEdit = (t: TargetItem) => {
    setForm({ departmentId: t.departmentId, category: t.category, yearlyTarget: t.yearlyTarget });
    setEditingId(t.id);
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.category || !form.yearlyTarget) return;
    const deptName = DEPARTMENTS.find(d => d.id === form.departmentId)?.name || form.departmentId;
    if (editingId) {
      await firestoreService.vpTargets.update(editingId, { ...form, departmentName: deptName });
      setTargets(targets.map(t => t.id === editingId ? { ...t, ...form, departmentName: deptName } : t));
    } else {
      const id = await firestoreService.vpTargets.create({ ...form, departmentName: deptName, achieved: 0, year: selectedYear });
      setTargets([...targets, { id, ...form, departmentName: deptName, achieved: 0, year: selectedYear }]);
    }
    setShowForm(false);
    setEditingId(null);
  };

  const handleDelete = async (id: string) => {
    await firestoreService.vpTargets.delete(id);
    setTargets(targets.filter(t => t.id !== id));
  };

  const totalTarget = filtered.reduce((s, t) => s + t.yearlyTarget, 0);
  const totalAchieved = filtered.reduce((s, t) => s + t.achieved, 0);
  const overallPct = totalTarget > 0 ? Math.round((totalAchieved / totalTarget) * 100) : 0;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Department Target Management</h1>
            <p className="text-muted-foreground">Set and manage yearly targets for each department across all categories</p>
          </div>
          <Button onClick={handleAdd} className="bg-[#0B2E6B] hover:bg-[#1D4E89]">
            <Plus className="mr-2 h-4 w-4" />Add Target
          </Button>
        </div>

        <div className="flex items-center gap-3">
          <select value={selectedDept} onChange={e => setSelectedDept(e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm">
            <option value="All">All Departments</option>
            {DEPARTMENTS.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
          <select value={selectedYear} onChange={e => setSelectedYear(e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm">
            {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card><CardContent className="p-4"><div className="text-sm text-muted-foreground">Total Targets</div><div className="text-2xl font-bold">{filtered.length}</div></CardContent></Card>
          <Card><CardContent className="p-4"><div className="text-sm text-muted-foreground">Total Target Value</div><div className="text-2xl font-bold">{totalTarget}</div></CardContent></Card>
          <Card><CardContent className="p-4"><div className="text-sm text-muted-foreground">Total Achieved</div><div className="text-2xl font-bold text-green-600">{totalAchieved}</div></CardContent></Card>
          <Card><CardContent className="p-4"><div className="text-sm text-muted-foreground">Overall Achievement</div><div className="text-2xl font-bold text-[#0B2E6B]">{overallPct}%</div></CardContent></Card>
        </div>

        {Object.entries(deptGroups).map(([deptId, items]) => {
          const deptTarget = items.reduce((s, t) => s + t.yearlyTarget, 0);
          const deptAchieved = items.reduce((s, t) => s + t.achieved, 0);
          const deptPct = deptTarget > 0 ? Math.round((deptAchieved / deptTarget) * 100) : 0;
          return (
            <Card key={deptId}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">{items[0]?.departmentName || deptId}</CardTitle>
                  <span className="text-sm text-muted-foreground">Achievement: <span className="font-bold text-foreground">{deptAchieved}/{deptTarget}</span> ({deptPct}%)</span>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden mt-2">
                  <div className="h-full rounded-full transition-all" style={{ width: `${Math.min(deptPct, 100)}%`, backgroundColor: deptPct >= 70 ? "#22c55e" : deptPct >= 40 ? "#f59e0b" : "#ef4444" }} />
                </div>
              </CardHeader>
              <CardContent>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b text-left text-muted-foreground">
                      <th className="pb-2 font-medium">Category</th>
                      <th className="pb-2 font-medium text-center">Target</th>
                      <th className="pb-2 font-medium text-center">Achieved</th>
                      <th className="pb-2 font-medium text-center">Pending</th>
                      <th className="pb-2 font-medium text-center">Achievement %</th>
                      <th className="pb-2 font-medium text-center">Status</th>
                      <th className="pb-2 font-medium text-center w-20">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map(t => {
                      const pending = t.yearlyTarget - t.achieved;
                      const pct = t.yearlyTarget > 0 ? Math.round((t.achieved / t.yearlyTarget) * 100) : 0;
                      return (
                        <tr key={t.id} className="border-b last:border-0">
                          <td className="py-2 font-medium">{t.category}</td>
                          <td className="py-2 text-center">{t.yearlyTarget}</td>
                          <td className="py-2 text-center font-semibold text-green-600">{t.achieved}</td>
                          <td className="py-2 text-center text-red-500">{pending > 0 ? pending : 0}</td>
                          <td className="py-2 text-center font-semibold">{pct}%</td>
                          <td className="py-2 text-center">
                            <span className={`text-xs font-bold px-2 py-0.5 rounded ${pct >= 70 ? "bg-green-100 text-green-700" : pct >= 40 ? "bg-yellow-100 text-yellow-700" : "bg-red-100 text-red-700"}`}>
                              {pct >= 70 ? "ON TRACK" : pct >= 40 ? "NEEDS FOCUS" : "BEHIND"}
                            </span>
                          </td>
                          <td className="py-2 text-center">
                            <div className="flex items-center justify-center gap-1">
                              <Button size="sm" variant="ghost" className="h-7 w-7 p-0" onClick={() => handleEdit(t)}><Edit className="h-3.5 w-3.5" /></Button>
                              <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-500 hover:text-red-700" onClick={() => handleDelete(t.id)}><Trash2 className="h-3.5 w-3.5" /></Button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </CardContent>
            </Card>
          );
        })}

        {Object.keys(deptGroups).length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Target className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>No targets set for the selected filters. Click &quot;Add Target&quot; to create one.</p>
          </div>
        )}

        {showForm && (
          <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
            <Card className="w-full max-w-md" onClick={e => e.stopPropagation()}>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>{editingId ? "Edit Target" : "Add Target"}</CardTitle>
                <Button size="sm" variant="ghost" onClick={() => setShowForm(false)}><X className="h-4 w-4" /></Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Department</label>
                  <select value={form.departmentId} onChange={e => setForm({ ...form, departmentId: e.target.value })} className="w-full h-9 rounded-md border bg-transparent px-3 text-sm mt-1" disabled={!!editingId}>
                    {DEPARTMENTS.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium">Category</label>
                  <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="w-full h-9 rounded-md border bg-transparent px-3 text-sm mt-1">
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-sm font-medium">Yearly Target</label>
                  <Input type="number" value={form.yearlyTarget || ""} onChange={e => setForm({ ...form, yearlyTarget: Number(e.target.value) })} placeholder="Enter target number" className="mt-1" />
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
                  <Button onClick={handleSave} className="bg-[#0B2E6B] hover:bg-[#1D4E89]"><Save className="mr-2 h-4 w-4" />{editingId ? "Update" : "Save"}</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
