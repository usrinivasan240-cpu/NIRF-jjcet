"use client";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function ApprovalsRedirect() {
  const router = useRouter();
  useEffect(() => { router.replace("/documents"); }, [router]);
  return null;
}
