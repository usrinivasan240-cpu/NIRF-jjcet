"use client";

import { useEffect, useState, useRef } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useBrandingStore, CollegeBranding } from "@/store/branding";
import { useAuthStore } from "@/store";
import { Role } from "@/types";
import {
  Upload, Save, Building2, Mail, Phone, Globe, MapPin,
  User, Image as ImageIcon, FileImage, Eye, Loader2, CheckCircle2, AlertCircle
} from "lucide-react";

export default function BrandingPage() {
  const { user } = useAuthStore();
  const { branding, loading, error, fetchBranding, updateBranding, uploadLogo, uploadBanner } = useBrandingStore();
  const [form, setForm] = useState<Partial<CollegeBranding>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingBanner, setUploadingBanner] = useState(false);
  const logoRef = useRef<HTMLInputElement>(null);
  const bannerRef = useRef<HTMLInputElement>(null);

  const isSuperAdmin = user?.role === Role.SUPER_ADMIN;

  useEffect(() => {
    fetchBranding();
  }, [fetchBranding]);

  useEffect(() => {
    if (branding) setForm(branding);
  }, [branding]);

  const handleSave = async () => {
    if (!branding?.id) return;
    setSaving(true);
    await updateBranding(branding.id, form);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !branding?.id) return;
    setUploadingLogo(true);
    await uploadLogo(branding.id, file);
    setUploadingLogo(false);
    fetchBranding();
  };

  const handleBannerUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !branding?.id) return;
    setUploadingBanner(true);
    await uploadBanner(branding.id, file);
    setUploadingBanner(false);
    fetchBranding();
  };

  if (!isSuperAdmin) {
    return (
      <DashboardLayout>
        <Card>
          <CardContent className="p-12 text-center">
            <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-red-600">Access Denied</h2>
            <p className="text-muted-foreground mt-2">Only Super Admin can manage college branding.</p>
          </CardContent>
        </Card>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">College Branding</h1>
            <p className="text-muted-foreground">Manage official college identity, logo, and branding across all reports</p>
          </div>
          <div className="flex gap-2">
            {saved && (
              <span className="flex items-center gap-1 text-sm text-green-600">
                <CheckCircle2 className="h-4 w-4" /> Saved
              </span>
            )}
            <Button onClick={handleSave} disabled={saving || loading}>
              {saving ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Save className="h-4 w-4 mr-2" />}
              Save Changes
            </Button>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-700">{error}</div>
        )}

        <Tabs defaultValue="identity" className="space-y-4">
          <TabsList>
            <TabsTrigger value="identity"><Building2 className="mr-2 h-4 w-4" />Identity</TabsTrigger>
            <TabsTrigger value="logo"><ImageIcon className="mr-2 h-4 w-4" />Logo & Banner</TabsTrigger>
            <TabsTrigger value="contact"><Mail className="mr-2 h-4 w-4" />Contact</TabsTrigger>
            <TabsTrigger value="preview"><Eye className="mr-2 h-4 w-4" />Preview</TabsTrigger>
          </TabsList>

          {/* Identity Tab */}
          <TabsContent value="identity">
            <Card>
              <CardHeader><CardTitle>College Identity</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium">College Name (Full)</label>
                    <Input
                      value={form.collegeName || ""}
                      onChange={(e) => setForm({ ...form, collegeName: e.target.value })}
                      placeholder="JJ College of Engineering & Technology"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Short Name / Abbreviation</label>
                    <Input
                      value={form.shortName || ""}
                      onChange={(e) => setForm({ ...form, shortName: e.target.value })}
                      placeholder="JJCET"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Motto</label>
                    <Input
                      value={form.motto || ""}
                      onChange={(e) => setForm({ ...form, motto: e.target.value })}
                      placeholder="INNOVATE • TRANSFORM • INSPIRE"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Principal Name</label>
                    <Input
                      value={form.principalName || ""}
                      onChange={(e) => setForm({ ...form, principalName: e.target.value })}
                      placeholder="Dr. Rajesh Kumar"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Established Year</label>
                    <Input
                      value={form.established || ""}
                      onChange={(e) => setForm({ ...form, established: e.target.value })}
                      placeholder="1994"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Logo & Banner Tab */}
          <TabsContent value="logo">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader><CardTitle>College Logo</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-2 border-dashed rounded-lg p-6 text-center">
                    {branding?.logo ? (
                      <div className="space-y-3">
                        <img
                          src={branding.logo.startsWith("http") ? branding.logo : `http://localhost:5000${branding.logo}`}
                          alt="College Logo"
                          className="max-h-32 mx-auto object-contain"
                          onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                        />
                        <p className="text-xs text-muted-foreground">Current logo</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="w-20 h-20 mx-auto bg-[#193c78] rounded-full flex items-center justify-center text-white font-bold text-xl">
                          {form.shortName || "JJCET"}
                        </div>
                        <p className="text-xs text-muted-foreground">No logo uploaded — showing default</p>
                      </div>
                    )}
                  </div>
                  <input ref={logoRef} type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => logoRef.current?.click()}
                    disabled={uploadingLogo}
                  >
                    {uploadingLogo ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
                    {branding?.logo ? "Replace Logo" : "Upload Logo"}
                  </Button>
                  <p className="text-[10px] text-muted-foreground">Recommended: PNG/SVG, min 512x512px, max 5MB</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader><CardTitle>Header Banner</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-2 border-dashed rounded-lg p-6 text-center">
                    {branding?.headerBanner ? (
                      <div className="space-y-3">
                        <img
                          src={branding.headerBanner.startsWith("http") ? branding.headerBanner : `http://localhost:5000${branding.headerBanner}`}
                          alt="Header Banner"
                          className="max-h-32 mx-auto object-contain"
                          onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                        />
                        <p className="text-xs text-muted-foreground">Current banner</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <div className="w-full h-20 bg-gradient-to-r from-[#193c78] to-[#2563eb] rounded flex items-center justify-center text-white font-bold text-sm">
                          {form.collegeName || "JJ College of Engineering & Technology"}
                        </div>
                        <p className="text-xs text-muted-foreground">No banner uploaded — showing default gradient</p>
                      </div>
                    )}
                  </div>
                  <input ref={bannerRef} type="file" accept="image/*" className="hidden" onChange={handleBannerUpload} />
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => bannerRef.current?.click()}
                    disabled={uploadingBanner}
                  >
                    {uploadingBanner ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <FileImage className="h-4 w-4 mr-2" />}
                    {branding?.headerBanner ? "Replace Banner" : "Upload Banner"}
                  </Button>
                  <p className="text-[10px] text-muted-foreground">Recommended: PNG/JPG, 1200x200px, max 5MB</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Contact Tab */}
          <TabsContent value="contact">
            <Card>
              <CardHeader><CardTitle>Contact & Address Details</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="text-sm font-medium flex items-center gap-2"><MapPin className="h-4 w-4" /> Address</label>
                    <Input
                      value={form.address || ""}
                      onChange={(e) => setForm({ ...form, address: e.target.value })}
                      placeholder="NH-544, Trichy - Thanjavur Road, Pichanur"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">City</label>
                    <Input value={form.city || ""} onChange={(e) => setForm({ ...form, city: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-sm font-medium">State</label>
                    <Input value={form.state || ""} onChange={(e) => setForm({ ...form, state: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Country</label>
                    <Input value={form.country || ""} onChange={(e) => setForm({ ...form, country: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Postal Code</label>
                    <Input value={form.postalCode || ""} onChange={(e) => setForm({ ...form, postalCode: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-sm font-medium flex items-center gap-2"><Globe className="h-4 w-4" /> Website</label>
                    <Input value={form.website || ""} onChange={(e) => setForm({ ...form, website: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-sm font-medium flex items-center gap-2"><Mail className="h-4 w-4" /> Email</label>
                    <Input value={form.email || ""} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-sm font-medium flex items-center gap-2"><Phone className="h-4 w-4" /> Phone</label>
                    <Input value={form.phone || ""} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Preview Tab */}
          <TabsContent value="preview">
            <Card>
              <CardHeader><CardTitle>Report Header Preview</CardTitle></CardHeader>
              <CardContent>
                <div className="border rounded-lg overflow-hidden">
                  {/* Simulated PDF header */}
                  <div className="bg-[#0f234b] text-white p-5 flex items-center gap-4">
                    {branding?.logo ? (
                      <img
                        src={branding.logo.startsWith("http") ? branding.logo : `http://localhost:5000${branding.logo}`}
                        alt="Logo"
                        className="w-16 h-16 rounded-full object-contain bg-white/10 p-1"
                        onError={(e) => {
                          (e.target as HTMLImageElement).style.display = "none";
                          (e.target as HTMLImageElement).nextElementSibling?.classList.remove("hidden");
                        }}
                      />
                    ) : null}
                    <div className={`w-16 h-16 rounded-full bg-[#e67814] flex items-center justify-center font-bold text-lg ${branding?.logo ? "hidden" : ""}`}>
                      {form.shortName || "JJCET"}
                    </div>
                    <div className="flex-1">
                      <h2 className="text-xl font-bold">{form.collegeName || "JJ College of Engineering & Technology"}</h2>
                      <p className="text-xs text-white/70">ESTD. {form.established || "1994"} | AUTONOMOUS</p>
                      <p className="text-xs text-[#e67814] mt-1">{form.motto || "INNOVATE • TRANSFORM • INSPIRE"}</p>
                    </div>
                    <div className="text-right text-xs text-white/60 space-y-1">
                      <div>{form.address}</div>
                      <div>{form.city}, {form.state} - {form.postalCode}</div>
                      <div>{form.email}</div>
                      <div>{form.phone}</div>
                    </div>
                  </div>
                  <div className="bg-[#f5f7fa] p-4 text-center text-sm text-muted-foreground">
                    All generated reports will use this branding automatically
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
}
