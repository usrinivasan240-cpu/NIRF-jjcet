"use client";

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { Role } from "@/types";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ClipboardCheck, CheckCircle, XCircle, Clock } from "lucide-react";

const statusMap: Record<string, { label: string; variant: string; icon: any }> = {
  pending_hod: { label: "Pending HOD", variant: "secondary", icon: Clock },
  pending_vp: { label: "Pending VP", variant: "outline", icon: Clock },
  pending_principal: { label: "Pending Principal", variant: "outline", icon: Clock },
  approved: { label: "Approved", variant: "default", icon: CheckCircle },
  rejected: { label: "Rejected", variant: "destructive", icon: XCircle },
};

export default function ReviewsPage() {
  const { user } = useAuthStore();
  const [items, setItems] = useState<any[]>([]);

  useEffect(() => {
    firestoreService.reviews.getAll().then(setItems);
  }, []);

  const filtered = items.filter((i) => {
    if (user?.role === Role.DEPARTMENT_STAFF && i.createdBy !== user?.email) return false;
    if (user?.role === Role.HOD && i.department !== user?.department) return false;
    return true;
  });

  const canApprove = user?.role === Role.HOD || user?.role === Role.VICE_PRINCIPAL || user?.role === Role.PRINCIPAL || user?.role === Role.SUPER_ADMIN;

  const handleApprove = async (id: string) => {
    const item = items.find(i => i.id === id);
    if (!item) return;
    const nextStatus = item.status === "pending_hod" ? "pending_vp" : item.status === "pending_vp" ? "pending_principal" : "approved";
    await firestoreService.reviews.update(id, { status: nextStatus });
    setItems(items.map((i) => i.id === id ? { ...i, status: nextStatus } : i));
  };

  const handleReject = async (id: string) => {
    await firestoreService.reviews.update(id, { status: "rejected" });
    setItems(items.map((i) => i.id === id ? { ...i, status: "rejected" } : i));
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div><h1 className="text-2xl font-bold">Monthly Reviews</h1><p className="text-muted-foreground">Submit and review monthly department reports</p></div>
        <div className="grid gap-4 md:grid-cols-4">
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Total</CardTitle><ClipboardCheck className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Pending</CardTitle><Clock className="h-4 w-4 text-yellow-500" /></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((i) => !i.status.startsWith("approved") && i.status !== "rejected").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Approved</CardTitle><CheckCircle className="h-4 w-4 text-green-500" /></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((i) => i.status === "approved").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Rejected</CardTitle><XCircle className="h-4 w-4 text-red-500" /></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((i) => i.status === "rejected").length}</div></CardContent></Card>
        </div>
        <div className="rounded-md border">
          <table className="w-full text-sm">
            <thead><tr className="border-b"><th className="h-12 px-4 text-left font-medium">Month</th><th className="h-12 px-4 text-left font-medium">Department</th><th className="h-12 px-4 text-left font-medium">Submitted By</th><th className="h-12 px-4 text-left font-medium">Pubs</th><th className="h-12 px-4 text-left font-medium">Patents</th><th className="h-12 px-4 text-left font-medium">Events</th><th className="h-12 px-4 text-left font-medium">Status</th>{canApprove && <th className="h-12 px-4 text-left font-medium">Actions</th>}</tr></thead>
            <tbody>{filtered.map((i) => {
              const s = statusMap[i.status] || statusMap.pending_hod;
              return (
                <tr key={i.id} className="border-b hover:bg-muted/50">
                  <td className="p-4 font-medium">{i.month}</td><td className="p-4">{i.department}</td><td className="p-4 text-muted-foreground">{i.submittedBy}</td>
                  <td className="p-4">{i.publications}</td><td className="p-4">{i.patents}</td><td className="p-4">{i.events}</td>
                  <td className="p-4"><Badge variant={s.variant as any}>{s.label}</Badge></td>
                  {canApprove && <td className="p-4">{!i.status.startsWith("approved") && i.status !== "rejected" && (
                    <div className="flex gap-1"><Button size="sm" variant="outline" onClick={() => handleApprove(i.id)}>Approve</Button><Button size="sm" variant="destructive" onClick={() => handleReject(i.id)}>Reject</Button></div>
                  )}</td>}
                </tr>
              );
            })}</tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}
