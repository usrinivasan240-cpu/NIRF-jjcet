"use client";

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { Role } from "@/types";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Edit, Trash2, Building2, Users, BookOpen } from "lucide-react";

export default function DepartmentsPage() {
  const { user } = useAuthStore();
  const isAdmin = user?.role === Role.SUPER_ADMIN;
  const isHOD = user?.role === Role.HOD;
  const isStaff = user?.role === Role.DEPARTMENT_STAFF;
  const isRestricted = isHOD || isStaff;
  const [search, setSearch] = useState("");
  const [depts, setDepts] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [editDept, setEditDept] = useState<any>(null);
  const [form, setForm] = useState({ name: "", code: "" });

  useEffect(() => {
    firestoreService.departments.getAll().then((data) => {
      if (isRestricted && user?.department) {
        setDepts(data.filter((d: any) => d.code === user.department || d.name === user.department));
      } else {
        setDepts(data);
      }
    });
  }, [isRestricted, user?.department]);

  const filtered = depts.filter((d) => d.name.toLowerCase().includes(search.toLowerCase()) || d.code.toLowerCase().includes(search.toLowerCase()));

  const handleAdd = async () => {
    if (!form.name || !form.code) return;
    const id = await firestoreService.departments.create({ ...form, facultyCount: 0, studentCount: 0, publications: 0, patents: 0, nirfScore: 0 });
    setDepts([...depts, { id, ...form, facultyCount: 0, studentCount: 0, publications: 0, patents: 0, nirfScore: 0 }]);
    setForm({ name: "", code: "" });
    setShowAdd(false);
  };

  const handleEdit = async () => {
    if (!editDept) return;
    await firestoreService.departments.update(editDept.id, form);
    setDepts(depts.map((d) => d.id === editDept.id ? { ...d, ...form } : d));
    setForm({ name: "", code: "" });
    setEditDept(null);
  };

  const handleDelete = async (id: string) => {
    await firestoreService.departments.delete(id);
    setDepts(depts.filter((d) => d.id !== id));
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold">Departments</h1><p className="text-muted-foreground">Manage all departments</p></div>
          {isAdmin && <Button onClick={() => setShowAdd(true)}><Plus className="mr-2 h-4 w-4" />Add Department</Button>}
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Total</CardTitle><Building2 className="h-4 w-4 text-muted-foreground" /></CardHeader><CardContent><div className="text-2xl font-bold">{depts.length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Faculty</CardTitle><Users className="h-4 w-4 text-muted-foreground" /></CardHeader><CardContent><div className="text-2xl font-bold">{depts.reduce((a, d) => a + d.facultyCount, 0)}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Publications</CardTitle><BookOpen className="h-4 w-4 text-muted-foreground" /></CardHeader><CardContent><div className="text-2xl font-bold">{depts.reduce((a, d) => a + d.publications, 0)}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Avg NIRF</CardTitle><Building2 className="h-4 w-4 text-muted-foreground" /></CardHeader><CardContent><div className="text-2xl font-bold">{depts.length ? (depts.reduce((a, d) => a + d.nirfScore, 0) / depts.length).toFixed(1) : "0.0"}</div></CardContent></Card>
        </div>
        <div className="relative max-w-sm"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search departments..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8" /></div>
        <div className="rounded-md border">
          <table className="w-full text-sm">
            <thead><tr className="border-b"><th className="h-12 px-4 text-left font-medium">Name</th><th className="h-12 px-4 text-left font-medium">Code</th><th className="h-12 px-4 text-left font-medium">Faculty</th><th className="h-12 px-4 text-left font-medium">Students</th><th className="h-12 px-4 text-left font-medium">Publications</th><th className="h-12 px-4 text-left font-medium">NIRF</th>{isAdmin && <th className="h-12 px-4 text-left font-medium">Actions</th>}</tr></thead>
            <tbody>
              {filtered.map((d) => (
                <tr key={d.id} className="border-b hover:bg-muted/50">
                  <td className="p-4 font-medium">{d.name}</td><td className="p-4"><Badge variant="secondary">{d.code}</Badge></td>
                  <td className="p-4">{d.facultyCount}</td><td className="p-4">{d.studentCount}</td><td className="p-4">{d.publications}</td><td className="p-4">{d.nirfScore}</td>
                  {isAdmin && <td className="p-4"><div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={() => { setEditDept(d); setForm({ name: d.name, code: d.code }); }}><Edit className="h-4 w-4" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => handleDelete(d.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </div></td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {showAdd && (
          <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
            <Card className="w-full max-w-md">
              <CardHeader><CardTitle>{editDept ? "Edit Department" : "Add Department"}</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div><label className="text-sm font-medium">Name</label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div><label className="text-sm font-medium">Code</label><Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} /></div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => { setShowAdd(false); setEditDept(null); }}>Cancel</Button>
                  <Button onClick={editDept ? handleEdit : handleAdd}>{editDept ? "Save" : "Add"}</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
