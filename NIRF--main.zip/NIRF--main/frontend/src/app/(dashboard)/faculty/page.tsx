"use client";

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { Role } from "@/types";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, Edit, Trash2, Users } from "lucide-react";

export default function FacultyPage() {
  const { user } = useAuthStore();
  const isDeptRestricted = user?.role === Role.HOD || user?.role === Role.DEPARTMENT_STAFF;
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("all");
  const [faculty, setFaculty] = useState<any[]>([]);
  const [departments, setDepartments] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [form, setForm] = useState({ name: "", email: "", designation: "", department: "", departmentId: "", qualification: "", experience: 0 });

  const deptScope = isDeptRestricted ? user?.department : null;

  useEffect(() => {
    firestoreService.faculty.getAll(deptScope).then(setFaculty);
    firestoreService.departments.getAll().then(setDepartments);
  }, []);

  const filtered = faculty.filter((f) => {
    if (isDeptRestricted && f.department !== user?.department) return false;
    const matchSearch = f.name.toLowerCase().includes(search.toLowerCase()) || f.email.toLowerCase().includes(search.toLowerCase());
    const matchDept = deptFilter === "all" || f.department === deptFilter;
    return matchSearch && matchDept;
  });

  const handleSave = async () => {
    if (editItem) {
      await firestoreService.faculty.update(editItem.id, form);
      setFaculty(faculty.map((f) => f.id === editItem.id ? { ...f, ...form } : f));
      setEditItem(null);
    } else {
      const id = await firestoreService.faculty.create(form);
      setFaculty([...faculty, { id, ...form, publications: 0 }]);
    }
    setForm({ name: "", email: "", designation: "", department: "", departmentId: "", qualification: "", experience: 0 });
    setShowAdd(false);
  };

  const handleDelete = async (id: string) => {
    await firestoreService.faculty.delete(id);
    setFaculty(faculty.filter((f) => f.id !== id));
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold">Faculty</h1><p className="text-muted-foreground">Manage faculty members</p></div>
          <Button onClick={() => setShowAdd(true)}><Plus className="mr-2 h-4 w-4" />Add Faculty</Button>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Total</CardTitle><Users className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{faculty.length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Professors</CardTitle><Users className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{faculty.filter((f) => f.designation === "Professor").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Avg Experience</CardTitle><Users className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{faculty.length ? (faculty.reduce((a, f) => a + f.experience, 0) / faculty.length).toFixed(0) : 0} yrs</div></CardContent></Card>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-sm"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search faculty..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8" /></div>
          <select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm"><option value="all">All Depts</option>{departments.map((d: any) => <option key={d.id} value={d.name}>{d.name}</option>)}</select>
        </div>
        <div className="rounded-md border">
          <table className="w-full text-sm">
            <thead><tr className="border-b"><th className="h-12 px-4 text-left font-medium">Name</th><th className="h-12 px-4 text-left font-medium">Email</th><th className="h-12 px-4 text-left font-medium">Designation</th><th className="h-12 px-4 text-left font-medium">Dept</th><th className="h-12 px-4 text-left font-medium">Exp</th><th className="h-12 px-4 text-left font-medium">Pubs</th><th className="h-12 px-4 text-left font-medium">Actions</th></tr></thead>
            <tbody>
              {filtered.map((f) => (
                <tr key={f.id} className="border-b hover:bg-muted/50">
                  <td className="p-4 font-medium">{f.name}</td><td className="p-4 text-muted-foreground">{f.email}</td><td className="p-4"><Badge variant="secondary">{f.designation}</Badge></td>
                  <td className="p-4">{f.department}</td><td className="p-4">{f.experience} yrs</td><td className="p-4">{f.publications}</td>
                  <td className="p-4"><div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={() => { setEditItem(f); setForm({ name: f.name, email: f.email, designation: f.designation, department: f.department, departmentId: f.departmentId || "", qualification: f.qualification, experience: f.experience }); setShowAdd(true); }}><Edit className="h-4 w-4" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => handleDelete(f.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {showAdd && (
          <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
            <Card className="w-full max-w-md"><CardHeader><CardTitle>{editItem ? "Edit Faculty" : "Add Faculty"}</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div><label className="text-sm font-medium">Name</label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
                <div><label className="text-sm font-medium">Email</label><Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
                <div><label className="text-sm font-medium">Designation</label><select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={form.designation} onChange={(e) => setForm({ ...form, designation: e.target.value })}><option value="">Select</option><option>Professor</option><option>Associate Professor</option><option>Assistant Professor</option></select></div>
                <div><label className="text-sm font-medium">Department</label><select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={form.departmentId} onChange={(e) => { const dept = departments.find((d: any) => d.id === e.target.value); setForm({ ...form, department: dept?.name || "", departmentId: e.target.value }); }}><option value="">Select Department</option>{departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
                <div><label className="text-sm font-medium">Qualification</label><Input value={form.qualification} onChange={(e) => setForm({ ...form, qualification: e.target.value })} /></div>
                <div><label className="text-sm font-medium">Experience (yrs)</label><Input type="number" value={form.experience} onChange={(e) => setForm({ ...form, experience: Number(e.target.value) })} /></div>
                <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => { setShowAdd(false); setEditItem(null); }}>Cancel</Button><Button onClick={handleSave}>Save</Button></div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
