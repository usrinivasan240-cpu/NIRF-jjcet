"use client";

import { DashboardLayout } from "@/components/layout/DashboardLayout";

export default function SignaturePage() {
  return (
    <DashboardLayout>
      <div className="flex flex-col items-center justify-center h-[60vh] gap-4">
        <p className="text-muted-foreground">This page has been removed.</p>
      </div>
    </DashboardLayout>
  );
}
