"use client";

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { Role } from "@/types";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, Edit, Trash2, Calendar } from "lucide-react";

export default function EventsPage() {
  const EVENT_TYPES = ["Workshop", "Conference", "FDP", "Seminar"];
  const { user } = useAuthStore();
  const isDeptRestricted = user?.role === Role.HOD || user?.role === Role.DEPARTMENT_STAFF;
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [items, setItems] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [form, setForm] = useState({ title: "", type: "Workshop", date: "", participants: 0, department: "", departmentId: "" });
  const [departments, setDepartments] = useState<any[]>([]);

  useEffect(() => {
    const dept = isDeptRestricted ? user?.department : undefined;
    firestoreService.events.getAll(dept).then(setItems);
    firestoreService.departments.getAll().then(setDepartments);
  }, []);

  const filtered = items.filter((i) => {
    if (user?.role === Role.DEPARTMENT_STAFF && i.createdBy !== user?.email) return false;
    if (user?.role === Role.HOD && i.department !== user?.department) return false;
    const matchS = i.title.toLowerCase().includes(search.toLowerCase());
    const matchT = typeFilter === "all" || i.type === typeFilter;
    return matchS && matchT;
  });

  const handleSave = async () => {
    if (editItem) {
      await firestoreService.events.update(editItem.id, form);
      setItems(items.map((i) => i.id === editItem.id ? { ...i, ...form } : i));
      setEditItem(null);
    } else {
      const data = { ...form, status: "upcoming", createdBy: user?.email || "", departmentId: user?.department || "" };
      const id = await firestoreService.events.create(data);
      setItems([...items, { id, ...data }]);
    }
    setForm({ title: "", type: "Workshop", date: "", participants: 0, department: "", departmentId: "" });
    setShowAdd(false);
  };

  const handleDelete = async (id: string) => {
    await firestoreService.events.delete(id);
    setItems(items.filter((i) => i.id !== id));
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold">Events</h1><p className="text-muted-foreground">Workshops, Conferences, FDP, Seminars</p></div>
          <Button onClick={() => setShowAdd(true)}><Plus className="mr-2 h-4 w-4" />Add Event</Button>
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Total</CardTitle><Calendar className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Completed</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((i) => i.status === "completed").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Upcoming</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{items.filter((i) => i.status === "upcoming").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Participants</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{items.reduce((a, i) => a + i.participants, 0)}</div></CardContent></Card>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-sm"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search events..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8" /></div>
          <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm"><option value="all">All Types</option>{EVENT_TYPES.map((t) => <option key={t}>{t}</option>)}</select>
        </div>
        <div className="rounded-md border">
          <table className="w-full text-sm">
            <thead><tr className="border-b"><th className="h-12 px-4 text-left font-medium">Title</th><th className="h-12 px-4 text-left font-medium">Type</th><th className="h-12 px-4 text-left font-medium">Date</th><th className="h-12 px-4 text-left font-medium">Participants</th><th className="h-12 px-4 text-left font-medium">Status</th><th className="h-12 px-4 text-left font-medium">Actions</th></tr></thead>
            <tbody>{filtered.map((i) => (
              <tr key={i.id} className="border-b hover:bg-muted/50"><td className="p-4 font-medium">{i.title}</td><td className="p-4"><Badge variant="secondary">{i.type}</Badge></td><td className="p-4">{i.date}</td><td className="p-4">{i.participants}</td>
                <td className="p-4"><Badge variant={i.status === "completed" ? "default" : "outline"}>{i.status}</Badge></td>
                <td className="p-4"><div className="flex gap-1"><Button size="sm" variant="ghost" onClick={() => { setEditItem(i); setForm({ title: i.title, type: i.type, date: i.date, participants: i.participants, department: i.department, departmentId: i.departmentId || "" }); setShowAdd(true); }}><Edit className="h-4 w-4" /></Button><Button size="sm" variant="ghost" onClick={() => handleDelete(i.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button></div></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
        {showAdd && <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center"><Card className="w-full max-w-md"><CardHeader><CardTitle>{editItem ? "Edit" : "Add"} Event</CardTitle></CardHeader><CardContent className="space-y-4">
          <div><label className="text-sm font-medium">Title</label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
          <div><label className="text-sm font-medium">Type</label><select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>{EVENT_TYPES.map((t) => <option key={t}>{t}</option>)}</select></div>
          <div><label className="text-sm font-medium">Date</label><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></div>
          <div><label className="text-sm font-medium">Department</label><select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={form.departmentId} onChange={(e) => { const dept = departments.find((d: any) => d.id === e.target.value); setForm({ ...form, department: dept?.name || "", departmentId: e.target.value }); }}><option value="">Select Department</option>{departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
          <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => { setShowAdd(false); setEditItem(null); }}>Cancel</Button><Button onClick={handleSave}>Save</Button></div>
        </CardContent></Card></div>}
      </div>
    </DashboardLayout>
  );
}
