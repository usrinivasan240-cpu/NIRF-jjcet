"use client";

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FolderOpen, Download, Clock, Trash2, Upload, Search, FileText, X, Check } from "lucide-react";

interface Doc {
  id: string;
  name: string;
  type: string;
  size: string;
  category: string;
  docStatus: string;
  fileData?: string;
  uploadedBy: string;
  uploadedByName?: string;
  uploadedAt: string;
  currentVersion: number;
  versionCount: number;
  locked?: boolean;
  archived?: boolean;
  departmentId?: string;
  departmentName?: string;
  createdBy?: string;
}

interface Version {
  id: string;
  documentId: string;
  versionNumber: number;
  fileData: string;
  fileName: string;
  fileSize: string;
  fileType: string;
  uploadedBy: string;
  uploadedByRole: string;
  uploadedAt: string;
  comment?: string;
  action: string;
  sha256Hash?: string;
}

export default function DocumentsPage() {
  const { user } = useAuthStore();
  const [documents, setDocuments] = useState<Doc[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewDoc, setViewDoc] = useState<Doc | null>(null);
  const [versions, setVersions] = useState<Version[]>([]);
  const [loadingVersions, setLoadingVersions] = useState(false);
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showUpload, setShowUpload] = useState(false);
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadName, setUploadName] = useState("");
  const [uploadCategory, setUploadCategory] = useState("general");
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchDocs();
  }, []);

  async function fetchDocs() {
    try {
      setLoading(true);
      const res = await firestoreService.documents.getAll();
      const docs = (res as any).data || res || [];
      setDocuments(docs);
    } catch (e) {
      console.error("Failed to load documents:", e);
    } finally {
      setLoading(false);
    }
  }

  async function viewVersionHistory(doc: Doc) {
    setViewDoc(doc);
    setLoadingVersions(true);
    try {
      const res = await firestoreService.documentVersions.getAll(doc.id);
      const vers = (res as any).data || res || [];
      setVersions(vers);
    } catch (e) {
      console.error("Failed to load versions:", e);
      setVersions([]);
    } finally {
      setLoadingVersions(false);
    }
  }

  function downloadFile(doc: Doc, version?: Version) {
    const data = version ? version.fileData : doc.fileData;
    if (!data) {
      alert("No file data available.");
      return;
    }
    const base64 = data.includes(",") ? data.split(",")[1] : data;
    const byteString = atob(base64);
    const mimeString = data.includes(",") ? data.split(",")[0].split(":")[1].split(";")[0] : "application/octet-stream";
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) ia[i] = byteString.charCodeAt(i);
    const blob = new Blob([ab], { type: mimeString });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = version ? `v${version.versionNumber}_${doc.name}` : doc.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  async function handleUpload() {
    if (!uploadFile || !uploadName.trim()) {
      alert("Please provide a file and document name.");
      return;
    }
    try {
      setUploading(true);
      const reader = new FileReader();
      const fileData = await new Promise<string>((resolve) => {
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(uploadFile);
      });
      await firestoreService.documents.create({
        name: uploadName.trim(),
        type: uploadFile.name.split(".").pop() || "pdf",
        size: `${(uploadFile.size / 1024).toFixed(1)} KB`,
        category: uploadCategory,
        fileData,
        uploadedBy: user?.id || "unknown",
        uploadedByName: user?.name || "Unknown",
        uploadedAt: new Date().toISOString(),
        docStatus: "DRAFT",
        currentVersion: 1,
        versionCount: 1,
        createdBy: user?.id || "unknown",
      });
      setShowUpload(false);
      setUploadFile(null);
      setUploadName("");
      setUploadCategory("general");
      await fetchDocs();
      alert("Document uploaded successfully.");
    } catch (e) {
      console.error("Upload error:", e);
      alert("Failed to upload document.");
    } finally {
      setUploading(false);
    }
  }

  async function deleteDoc(docId: string) {
    if (!confirm("Are you sure you want to delete this document?")) return;
    try {
      await firestoreService.documents.delete(docId);
      await fetchDocs();
    } catch (e) {
      alert("Failed to delete document.");
    }
  }

  function getStatusBadge(status: string) {
    const s = status?.toLowerCase() || "";
    const map: Record<string, { bg: string; text: string; label: string }> = {
      draft: { bg: "bg-gray-100", text: "text-gray-700", label: "Draft" },
      submitted: { bg: "bg-blue-100", text: "text-blue-700", label: "Submitted" },
      hod_verified: { bg: "bg-amber-100", text: "text-amber-700", label: "HOD Verified" },
      vp_verified: { bg: "bg-purple-100", text: "text-purple-700", label: "VP Verified" },
      principal_approved: { bg: "bg-emerald-100", text: "text-emerald-700", label: "Approved" },
      hod_rejected: { bg: "bg-red-100", text: "text-red-700", label: "Rejected by HOD" },
      vp_rejected: { bg: "bg-red-100", text: "text-red-700", label: "Rejected by VP" },
      principal_rejected: { bg: "bg-red-100", text: "text-red-700", label: "Rejected by Principal" },
    };
    const m = map[s] || { bg: "bg-gray-100", text: "text-gray-700", label: status?.replace(/_/g, " ") || "Unknown" };
    return <span className={`px-2 py-1 text-xs font-medium rounded-full ${m.bg} ${m.text}`}>{m.label}</span>;
  }

  function getVersionLabel(action: string) {
    const map: Record<string, { color: string; label: string }> = {
      upload: { color: "bg-slate-100 text-slate-700", label: "Original" },
      approve: { color: "bg-emerald-100 text-emerald-700", label: "Signed" },
      resubmit: { color: "bg-blue-100 text-blue-700", label: "Resubmitted" },
    };
    const m = map[action] || { color: "bg-gray-100 text-gray-700", label: action };
    return <span className={`px-2 py-0.5 text-[10px] font-medium rounded-full ${m.color}`}>{m.label}</span>;
  }

  const filteredDocs = documents.filter((d) => {
    if (filterCategory !== "all" && d.category !== filterCategory) return false;
    if (filterStatus !== "all" && d.docStatus !== filterStatus) return false;
    if (searchQuery && !d.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  const categories = [...new Set(documents.map((d) => d.category).filter(Boolean))];
  const statuses = [...new Set(documents.map((d) => d.docStatus).filter(Boolean))];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Documents</h1>
            <p className="text-sm text-muted-foreground">{documents.length} documents total</p>
          </div>
          <Button onClick={() => setShowUpload(true)} size="lg" className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Upload New Document
          </Button>
        </div>

        <div className="flex flex-wrap gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search documents..."
              className="pl-9 w-60"
            />
          </div>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-3 py-2 text-sm border rounded-md bg-background"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 text-sm border rounded-md bg-background"
          >
            <option value="all">All Statuses</option>
            {statuses.map((s) => (
              <option key={s} value={s}>{s.replace(/_/g, " ")}</option>
            ))}
          </select>
        </div>

        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading documents...</div>
        ) : filteredDocs.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <FolderOpen className="w-10 h-10 mx-auto mb-3 text-muted-foreground" />
              <p className="text-muted-foreground font-medium">No documents found</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredDocs.map((doc) => (
              <Card key={doc.id} className="hover:border-blue-300 transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <h3 className="font-semibold truncate">{doc.name}</h3>
                        {getStatusBadge(doc.docStatus)}
                        {doc.locked && (
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-700">Locked</span>
                        )}
                        {doc.archived && (
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-slate-200 text-slate-600">Archived</span>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                        <span>{doc.type}</span>
                        <span>{doc.size}</span>
                        {doc.category && <span>{doc.category}</span>}
                        <span>v{doc.currentVersion || 1}</span>
                        <span>{doc.versionCount || 1} version{(doc.versionCount || 1) !== 1 ? "s" : ""}</span>
                        {doc.uploadedByName && <span>by {doc.uploadedByName}</span>}
                        {doc.uploadedAt && (
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {new Date(doc.uploadedAt).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}
                            {" "}
                            {new Date(doc.uploadedAt).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2 ml-4 shrink-0">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => downloadFile(doc)}
                        className="flex items-center gap-1"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => viewVersionHistory(doc)}
                        className="flex items-center gap-1"
                      >
                        <Clock className="w-3.5 h-3.5" />
                        History
                      </Button>
                      {user?.role?.toLowerCase() === "super_admin" && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteDoc(doc.id)}
                          className="flex items-center gap-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {viewDoc && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl w-full max-w-2xl max-h-[85vh] overflow-y-auto shadow-xl">
            <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold">{viewDoc.name}</h2>
                <p className="text-xs text-muted-foreground">Version History — {versions.length} version{versions.length !== 1 ? "s" : ""}</p>
              </div>
              <button
                onClick={() => { setViewDoc(null); setVersions([]); }}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>
            <div className="p-6">
              {loadingVersions ? (
                <div className="text-center py-8 text-muted-foreground">Loading versions...</div>
              ) : versions.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">No versions recorded yet.</div>
              ) : (
                <div className="space-y-3">
                  {versions.map((v) => (
                    <div key={v.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <span className="text-sm font-bold bg-slate-100 px-2 py-0.5 rounded">v{v.versionNumber}</span>
                            {getVersionLabel(v.action)}
                            <span className="text-xs text-muted-foreground">{v.fileName} ({v.fileSize})</span>
                          </div>
                          <div className="text-xs text-muted-foreground space-y-0.5">
                            <div>Uploaded by: <span className="font-medium text-foreground">{v.uploadedByRole || v.uploadedBy}</span></div>
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {new Date(v.uploadedAt).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}
                              {" "}
                              {new Date(v.uploadedAt).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                            </div>
                            {v.comment && <div className="italic">&quot;{v.comment}&quot;</div>}
                            {v.sha256Hash && (
                              <div className="font-mono text-[10px] text-slate-400 truncate">SHA-256: {v.sha256Hash.substring(0, 40)}...</div>
                            )}
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => downloadFile(viewDoc, v)}
                          className="ml-3 shrink-0"
                        >
                          <Download className="w-3.5 h-3.5 mr-1" />
                          v{v.versionNumber}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {showUpload && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b">
              <div>
                <h2 className="text-lg font-bold">Upload Document</h2>
                <p className="text-xs text-muted-foreground mt-0.5">Add a new document to the system</p>
              </div>
              <button
                onClick={() => { setShowUpload(false); setUploadFile(null); setUploadName(""); setUploadCategory("general"); }}
                className="p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-5">
              {/* Step 1: Document Name */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 text-blue-700 text-xs font-bold">1</span>
                  <label className="text-sm font-semibold">Document Name</label>
                  <span className="text-xs text-red-500">*</span>
                </div>
                <Input
                  value={uploadName}
                  onChange={(e) => setUploadName(e.target.value)}
                  placeholder="e.g. NIRF Report 2025 - Chapter 3"
                  className="pl-3"
                />
                <p className="text-[11px] text-muted-foreground mt-1">Give the document a descriptive name for easy identification.</p>
              </div>

              {/* Step 2: Category */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 text-blue-700 text-xs font-bold">2</span>
                  <label className="text-sm font-semibold">Category</label>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: "general", label: "General" },
                    { value: "nirf", label: "NIRF" },
                    { value: "naac", label: "NAAC" },
                    { value: "iqac", label: "IQAC" },
                    { value: "research", label: "Research" },
                    { value: "academic", label: "Academic" },
                  ].map((cat) => (
                    <button
                      key={cat.value}
                      onClick={() => setUploadCategory(cat.value)}
                      className={`px-3 py-2 text-xs font-medium rounded-lg border-2 transition-all ${
                        uploadCategory === cat.value
                          ? "border-blue-500 bg-blue-50 text-blue-700"
                          : "border-slate-200 hover:border-slate-300 text-slate-600"
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Step 3: File Upload */}
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 text-blue-700 text-xs font-bold">3</span>
                  <label className="text-sm font-semibold">Select File</label>
                  <span className="text-xs text-red-500">*</span>
                </div>

                {!uploadFile ? (
                  <label className="flex flex-col items-center justify-center w-full h-36 border-2 border-dashed border-slate-300 rounded-xl cursor-pointer hover:border-blue-400 hover:bg-blue-50/50 transition-all group">
                    <div className="flex flex-col items-center gap-2">
                      <div className="p-3 rounded-full bg-slate-100 group-hover:bg-blue-100 transition-colors">
                        <Upload className="w-6 h-6 text-slate-400 group-hover:text-blue-500" />
                      </div>
                      <div className="text-center">
                        <p className="text-sm font-medium text-slate-600">
                          Click to browse or drag and drop
                        </p>
                        <p className="text-[11px] text-muted-foreground mt-1">
                          PDF, Word, Excel, Images — up to 10 MB
                        </p>
                      </div>
                    </div>
                    <input
                      type="file"
                      accept=".pdf,.png,.jpg,.jpeg,.doc,.docx,.xls,.xlsx"
                      onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                      className="hidden"
                    />
                  </label>
                ) : (
                  <div className="flex items-center gap-3 p-3 border-2 border-emerald-200 bg-emerald-50 rounded-xl">
                    <div className="p-2 rounded-lg bg-emerald-100">
                      <FileText className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{uploadFile.name}</p>
                      <p className="text-xs text-emerald-600">
                        {(uploadFile.size / 1024).toFixed(1)} KB — Ready to upload
                      </p>
                    </div>
                    <button
                      onClick={(e) => { e.preventDefault(); setUploadFile(null); }}
                      className="p-1.5 rounded-lg hover:bg-emerald-100 transition-colors"
                    >
                      <X className="w-4 h-4 text-emerald-600" />
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between px-6 py-4 border-t bg-slate-50">
              <p className="text-[11px] text-muted-foreground">
                {uploadName.trim() && uploadFile ? (
                  <span className="flex items-center gap-1 text-emerald-600">
                    <Check className="w-3 h-3" /> Ready to upload
                  </span>
                ) : (
                  "Fill all required fields to continue"
                )}
              </p>
              <div className="flex gap-2">
                <Button
                  variant="ghost"
                  onClick={() => { setShowUpload(false); setUploadFile(null); setUploadName(""); setUploadCategory("general"); }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleUpload}
                  disabled={!uploadFile || !uploadName.trim() || uploading}
                  className="min-w-[120px]"
                >
                  {uploading ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Uploading...
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5">
                      <Upload className="w-4 h-4" />
                      Upload
                    </span>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
