"use client";

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { Role } from "@/types";
import { firestoreService } from "@/lib/firestore";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Search, Edit, Trash2, BookOpen } from "lucide-react";

const quartileColors: Record<string, string> = { Q1: "bg-green-100 text-green-800", Q2: "bg-blue-100 text-blue-800", Q3: "bg-yellow-100 text-yellow-800", Q4: "bg-red-100 text-red-800" };

export default function PublicationsPage() {
  const { user } = useAuthStore();
  const isDeptRestricted = user?.role === Role.HOD || user?.role === Role.DEPARTMENT_STAFF;
  const [search, setSearch] = useState("");
  const [quartileFilter, setQuartileFilter] = useState("all");
  const [pubs, setPubs] = useState<any[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [editItem, setEditItem] = useState<any>(null);
  const [form, setForm] = useState({ title: "", authors: "", journal: "", quartile: "Q1", department: "", departmentId: "" });
  const [departments, setDepartments] = useState<any[]>([]);

  useEffect(() => {
    const dept = isDeptRestricted ? user?.department : undefined;
    firestoreService.publications.getAll(dept).then(setPubs);
    firestoreService.departments.getAll().then(setDepartments);
  }, []);

  const filtered = pubs.filter((p) => {
    if (user?.role === Role.DEPARTMENT_STAFF && p.createdBy !== user?.email) return false;
    if (user?.role === Role.HOD && p.department !== user?.department) return false;
    const matchSearch = p.title.toLowerCase().includes(search.toLowerCase()) || p.journal.toLowerCase().includes(search.toLowerCase());
    const matchQ = quartileFilter === "all" || p.quartile === quartileFilter;
    return matchSearch && matchQ;
  });

  const handleSave = async () => {
    if (editItem) {
      await firestoreService.publications.update(editItem.id, form);
      setPubs(pubs.map((p) => p.id === editItem.id ? { ...p, ...form, authors: form.authors.split(",") } : p));
      setEditItem(null);
    } else {
      const data = { ...form, authors: form.authors.split(","), isSCI: true, isScopus: true, citationCount: 0, status: "published", createdBy: user?.email || "", departmentId: user?.department || "" };
      const id = await firestoreService.publications.create(data);
      setPubs([...pubs, { id, ...data }]);
    }
    setForm({ title: "", authors: "", journal: "", quartile: "Q1", department: "", departmentId: "" });
    setShowAdd(false);
  };

  const handleDelete = async (id: string) => {
    await firestoreService.publications.delete(id);
    setPubs(pubs.filter((p) => p.id !== id));
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div><h1 className="text-2xl font-bold">Publications</h1><p className="text-muted-foreground">Manage research publications</p></div>
          <Button onClick={() => setShowAdd(true)}><Plus className="mr-2 h-4 w-4" />Add Publication</Button>
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Total</CardTitle><BookOpen className="h-4 w-4" /></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Q1</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((p) => p.quartile === "Q1").length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">SCI</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.filter((p) => p.isSCI).length}</div></CardContent></Card>
          <Card><CardHeader className="flex flex-row items-center justify-between pb-2"><CardTitle className="text-sm font-medium">Citations</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{filtered.reduce((a, p) => a + p.citationCount, 0)}</div></CardContent></Card>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-sm"><Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Search publications..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-8" /></div>
          <select value={quartileFilter} onChange={(e) => setQuartileFilter(e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm"><option value="all">All Quartiles</option><option>Q1</option><option>Q2</option><option>Q3</option><option>Q4</option></select>
        </div>
        <div className="rounded-md border">
          <table className="w-full text-sm">
            <thead><tr className="border-b"><th className="h-12 px-4 text-left font-medium">Title</th><th className="h-12 px-4 text-left font-medium">Authors</th><th className="h-12 px-4 text-left font-medium">Journal</th><th className="h-12 px-4 text-left font-medium">Quartile</th><th className="h-12 px-4 text-left font-medium">Citations</th><th className="h-12 px-4 text-left font-medium">Actions</th></tr></thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id} className="border-b hover:bg-muted/50">
                  <td className="p-4 font-medium max-w-xs truncate">{p.title}</td><td className="p-4 text-muted-foreground">{Array.isArray(p.authors) ? p.authors.join(", ") : (p.authors || "—")}</td>
                  <td className="p-4">{p.journal}</td><td className="p-4"><Badge className={quartileColors[p.quartile]}>{p.quartile}</Badge></td><td className="p-4">{p.citationCount}</td>
                  <td className="p-4"><div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={() => { const authorsStr = Array.isArray(p.authors) ? p.authors.join(",") : (p.authors || ""); setEditItem(p); setForm({ title: p.title, authors: authorsStr, journal: p.journal, quartile: p.quartile, department: p.department, departmentId: p.departmentId || "" }); setShowAdd(true); }}><Edit className="h-4 w-4" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => handleDelete(p.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {showAdd && (
          <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center">
            <Card className="w-full max-w-md"><CardHeader><CardTitle>{editItem ? "Edit Publication" : "Add Publication"}</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div><label className="text-sm font-medium">Title</label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
                <div><label className="text-sm font-medium">Authors (comma separated)</label><Input value={form.authors} onChange={(e) => setForm({ ...form, authors: e.target.value })} /></div>
                <div><label className="text-sm font-medium">Journal</label><Input value={form.journal} onChange={(e) => setForm({ ...form, journal: e.target.value })} /></div>
                <div><label className="text-sm font-medium">Quartile</label><select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={form.quartile} onChange={(e) => setForm({ ...form, quartile: e.target.value })}><option>Q1</option><option>Q2</option><option>Q3</option><option>Q4</option></select></div>
                <div><label className="text-sm font-medium">Department</label><select className="w-full rounded-md border bg-transparent px-3 py-2 text-sm" value={form.departmentId} onChange={(e) => { const dept = departments.find((d: any) => d.id === e.target.value); setForm({ ...form, department: dept?.name || "", departmentId: e.target.value }); }}><option value="">Select Department</option>{departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
                <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => { setShowAdd(false); setEditItem(null); }}>Cancel</Button><Button onClick={handleSave}>Save</Button></div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
