"use client";

import { useState, useEffect } from "react";
import { useAuthStore } from "@/store";
import { Role } from "@/types";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { StatsCard } from "@/components/shared/StatsCard";
import { Chart } from "@/components/shared/Chart";
import { TargetProgress } from "@/components/shared/TargetProgress";
import { RecentActivity } from "@/components/shared/RecentActivity";
import { PendingApprovals } from "@/components/shared/PendingApprovals";
import { NotificationList } from "@/components/shared/NotificationList";
import { firestoreService } from "@/lib/firestore";
import { Building2, Users, BookOpen, Lightbulb, FlaskConical, GraduationCap, Target, BarChart3, FileText, Award, Briefcase, Calendar, Trophy, Globe } from "lucide-react";

export default function DashboardPage() {
  const { user } = useAuthStore();
  const isHOD = user?.role === Role.HOD;
  const isStaff = user?.role === Role.DEPARTMENT_STAFF;
  const isRestricted = isHOD || isStaff;

  const [departments, setDepartments] = useState<any[]>([]);
  const [publications, setPublications] = useState<any[]>([]);
  const [patents, setPatents] = useState<any[]>([]);
  const [faculty, setFaculty] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [phd, setPhd] = useState<any[]>([]);
  const [events, setEvents] = useState<any[]>([]);
  const [targets, setTargets] = useState<any[]>([]);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    try {
      const [depts, pubs, pats, fac, stu, p, ev, tgt, subs, notifs] = await Promise.all([
        firestoreService.departments.getAll(),
        firestoreService.publications.getAll(),
        firestoreService.patents.getAll(),
        firestoreService.faculty.getAll(),
        firestoreService.students.getAll(),
        firestoreService.phd.getAll(),
        firestoreService.events.getAll(),
        firestoreService.targets.getAll(),
        firestoreService.submissions.getAll(),
        firestoreService.notifications.getAll(),
      ]);
      setDepartments(depts);
      setPublications(pubs);
      setPatents(pats);
      setFaculty(fac);
      setStudents(stu);
      setPhd(p);
      setEvents(ev);
      setTargets(tgt);
      setSubmissions(subs);
      setNotifications(notifs);
    } catch (err) {
      console.error("Dashboard load failed:", err);
    }
    setLoading(false);
  };

  const deptFilter = isRestricted ? user?.department : null;

  const filterByDept = (items: any[]) => {
    if (!deptFilter) return items;
    return items.filter(i => i.department === deptFilter || i.departmentId === deptFilter);
  };

  const myPubs = filterByDept(publications);
  const myPats = filterByDept(patents);
  const myFaculty = filterByDept(faculty);
  const myStudents = filterByDept(students);
  const myPhd = filterByDept(phd);
  const myEvents = filterByDept(events);
  const myTargets = filterByDept(targets);
  const mySubs = filterByDept(submissions);
  const myDepts = isRestricted ? departments.filter(d => d.code === deptFilter || d.name === deptFilter) : departments;

  const totalFaculty = isRestricted ? myFaculty.length : faculty.length;
  const totalStudents = isRestricted ? myStudents.length : students.length;
  const totalPubs = isRestricted ? myPubs.length : publications.length;
  const totalPats = isRestricted ? myPats.length : patents.length;
  const totalEvents = isRestricted ? myEvents.length : events.length;
  const totalPhdPursuing = isRestricted ? myPhd.filter(p => p.status !== "Completed").length : phd.filter(p => p.status !== "Completed").length;
  const totalPhdCompleted = isRestricted ? myPhd.filter(p => p.status === "Completed").length : phd.filter(p => p.status === "Completed").length;
  const avgNirf = myDepts.length > 0 ? (myDepts.reduce((a, d) => a + (d.nirfScore || 0), 0) / myDepts.length).toFixed(1) : "0.0";
  const pendingApprovals = mySubs.filter(s => s.status === "SUBMITTED" || s.status === "HOD_APPROVED");
  const targetAchievement = myTargets.length > 0 ? Math.round(myTargets.reduce((a, t) => a + (t.achievementPct || 0), 0) / myTargets.length) : 0;

  const hodStats = [
    { title: "Department", value: deptFilter || "N/A", icon: Building2 },
    { title: "Total Faculty", value: totalFaculty, icon: Users },
    { title: "Total Students", value: totalStudents, icon: GraduationCap },
    { title: "Publications", value: totalPubs, icon: BookOpen },
    { title: "Patents", value: totalPats, icon: Lightbulb },
    { title: "Research Projects", value: myPhd.filter(p => p.status !== "Completed").length, icon: FlaskConical },
    { title: "Events Conducted", value: totalEvents, icon: Calendar },
    { title: "PhD Pursuing", value: totalPhdPursuing, icon: GraduationCap },
    { title: "PhD Completed", value: totalPhdCompleted, icon: GraduationCap },
    { title: "NIRF Score", value: avgNirf, icon: BarChart3 },
    { title: "Target Achievement", value: `${targetAchievement}%`, icon: Target },
    { title: "Pending Approvals", value: pendingApprovals.length, icon: FileText },
  ];

  const collegeStats = [
    { title: "Total Departments", value: departments.length, icon: Building2 },
    { title: "Total Faculty", value: faculty.length, icon: Users },
    { title: "Total Students", value: students.length, icon: GraduationCap },
    { title: "Publications", value: publications.length, icon: BookOpen },
    { title: "Patents", value: patents.length, icon: Lightbulb },
    { title: "Research Projects", value: phd.filter(p => p.status !== "Completed").length, icon: FlaskConical },
    { title: "Events Conducted", value: events.length, icon: Calendar },
    { title: "NIRF Score", value: avgNirf, icon: BarChart3 },
    { title: "Target Achievement", value: `${targetAchievement}%`, icon: Target },
    { title: "Pending Approvals", value: pendingApprovals.length, icon: FileText },
  ];

  const stats = isRestricted ? hodStats : collegeStats;

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const pubByMonth = monthNames.map((m, i) => ({
    name: m,
    value: filterByDept(publications).filter(p => {
      const d = new Date(p.date || p.createdAt);
      return d.getMonth() === i;
    }).length,
  }));
  const patByMonth = monthNames.map((m, i) => ({
    name: m,
    value: filterByDept(patents).filter(p => {
      const d = new Date(p.filingDate || p.createdAt);
      return d.getMonth() === i;
    }).length,
  }));

  const deptOverview = isRestricted
    ? [
        { name: "Faculty", value: totalFaculty },
        { name: "Students", value: totalStudents },
        { name: "Publications", value: totalPubs },
        { name: "Patents", value: totalPats },
        { name: "Events", value: totalEvents },
      ]
    : departments.map(d => ({ name: d.code || d.name, value: d.nirfScore || 0 }));

  const trendData = monthNames.map((m, i) => ({
    name: m,
    publications: filterByDept(publications).filter(p => new Date(p.date || p.createdAt).getMonth() === i).length,
    patents: filterByDept(patents).filter(p => new Date(p.filingDate || p.createdAt).getMonth() === i).length,
  }));

  const targetList = myTargets.slice(0, 8).map(t => ({
    category: t.category || t.metric || "Target",
    target: t.yearlyTarget || t.target || 0,
    achieved: t.achieved || 0,
    percentage: t.achievementPct || 0,
  }));

  const activities = mySubs.slice(0, 5).map(s => ({
    id: s.id,
    user: { name: s.submittedByName || "User" },
    action: `submitted ${s.reportName || "report"} for`,
    entity: `${s.month} ${s.year}`,
    timestamp: s.submittedAt,
  }));

  const approvalList = pendingApprovals.slice(0, 5).map(s => ({
    id: s.id,
    type: "report",
    title: s.reportName || "Report",
    submittedBy: s.submittedByName || "User",
    submittedAt: s.submittedAt?.split("T")[0] || "",
    status: "pending",
    currentLevel: s.status === "SUBMITTED" ? "HOD" : "VP",
  }));

  const notifList = notifications.slice(0, 5).map(n => ({
    id: n.id,
    title: n.title || "Notification",
    message: n.message || "",
    type: n.type || "info",
    isRead: n.isRead || false,
    createdAt: n.createdAt,
  }));

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Welcome back, {user?.name || "User"}</h1>
          <p className="text-muted-foreground">
            {isRestricted ? `Department: ${deptFilter || "Your Department"} — Showing only your department data` : "Here's an overview of your institution's performance"}
          </p>
        </div>

        {loading ? (
          <div className="text-center py-12 text-muted-foreground">Loading dashboard data...</div>
        ) : (
          <>
            <div className={`grid gap-4 md:grid-cols-2 ${isRestricted ? "lg:grid-cols-4 xl:grid-cols-5" : "lg:grid-cols-4"}`}>
              {stats.map((s) => (<StatsCard key={s.title} {...s} />))}
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <Chart title="Monthly Publications" data={pubByMonth} type="bar" />
              <Chart title={isRestricted ? "Department Overview" : "Department Performance"} data={deptOverview} type="pie" />
            </div>
            <Chart title="Publication & Patent Trends" data={trendData} type="line" />
            {targetList.length > 0 && <TargetProgress targets={targetList} />}
            <div className="grid gap-4 md:grid-cols-2">
              <RecentActivity activities={activities} />
              <PendingApprovals approvals={approvalList} onApprove={(id) => console.log("Approve:", id)} onReject={(id) => console.log("Reject:", id)} />
            </div>
            {notifList.length > 0 && <NotificationList notifications={notifList} />}
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
