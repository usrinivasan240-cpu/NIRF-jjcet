"use client";

import { useState } from "react";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, TrendingUp, Target, Users, BookOpen, Lightbulb, FlaskConical, GraduationCap, Award, Briefcase } from "lucide-react";

const DEPARTMENTS: { id: string; name: string; fullName: string }[] = [];

interface DeptData {
  id: string;
  name: string;
  fullName: string;
  faculty: number;
  students: number;
  publications: { target: number; achieved: number };
  patents: { target: number; achieved: number };
  research: { target: number; achieved: number };
  placements: { target: number; achieved: number };
  events: { target: number; achieved: number };
  higherStudies: { target: number; achieved: number };
  fdp: { target: number; achieved: number };
  nirfScore: number;
}

const deptData: DeptData[] = [];

const YEARS = ["2025-2026", "2024-2025", "2023-2024"];

const metrics = [
  { key: "publications" as const, label: "Publications", icon: BookOpen, color: "#3b82f6" },
  { key: "patents" as const, label: "Patents", icon: Lightbulb, color: "#f59e0b" },
  { key: "research" as const, label: "Research Projects", icon: FlaskConical, color: "#10b981" },
  { key: "placements" as const, label: "Placements", icon: Briefcase, color: "#8b5cf6" },
  { key: "events" as const, label: "Events", icon: Award, color: "#ec4899" },
  { key: "higherStudies" as const, label: "Higher Studies", icon: GraduationCap, color: "#06b6d4" },
  { key: "fdp" as const, label: "FDP/Workshops", icon: Users, color: "#f97316" },
];

export default function DepartmentAnalysisPage() {
  const [selectedYear, setSelectedYear] = useState("2024-2025");
  const [selectedDept, setSelectedDept] = useState<string | null>(null);

  const getDeptOverall = (d: DeptData) => {
    const totalTarget = d.publications.target + d.patents.target + d.research.target + d.placements.target + d.events.target + d.higherStudies.target + d.fdp.target;
    const totalAchieved = d.publications.achieved + d.patents.achieved + d.research.achieved + d.placements.achieved + d.events.achieved + d.higherStudies.achieved + d.fdp.achieved;
    return totalTarget > 0 ? Math.round((totalAchieved / totalTarget) * 100) : 0;
  };

  const sorted = [...deptData].sort((a, b) => getDeptOverall(b) - getDeptOverall(a));
  const focused = selectedDept ? deptData.filter(d => d.id === selectedDept) : sorted;

  const totalFaculty = deptData.reduce((s, d) => s + d.faculty, 0);
  const totalStudents = deptData.reduce((s, d) => s + d.students, 0);
  const avgNirf = Math.round(deptData.reduce((s, d) => s + d.nirfScore, 0) / deptData.length);
  const overallPct = (() => {
    let tt = 0, ta = 0;
    deptData.forEach(d => { tt += d.publications.target + d.patents.target + d.research.target + d.placements.target + d.events.target + d.higherStudies.target + d.fdp.target; ta += d.publications.achieved + d.patents.achieved + d.research.achieved + d.placements.achieved + d.events.achieved + d.higherStudies.achieved + d.fdp.achieved; });
    return tt > 0 ? Math.round((ta / tt) * 100) : 0;
  })();

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Department Analysis & Comparison</h1>
            <p className="text-muted-foreground">Compare all departments performance, targets, and progress at a glance</p>
          </div>
          <div className="flex items-center gap-3">
            <select value={selectedYear} onChange={e => setSelectedYear(e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm">
              {YEARS.map(y => <option key={y} value={y}>{y}</option>)}
            </select>
            <select value={selectedDept || "All"} onChange={e => setSelectedDept(e.target.value === "All" ? null : e.target.value)} className="h-9 rounded-md border bg-transparent px-3 text-sm">
              <option value="All">All Departments</option>
              {DEPARTMENTS.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Card><CardContent className="p-4"><div className="text-sm text-muted-foreground">Total Departments</div><div className="text-2xl font-bold">{deptData.length}</div></CardContent></Card>
          <Card><CardContent className="p-4"><div className="text-sm text-muted-foreground">Total Faculty</div><div className="text-2xl font-bold">{totalFaculty}</div></CardContent></Card>
          <Card><CardContent className="p-4"><div className="text-sm text-muted-foreground">Avg NIRF Score</div><div className="text-2xl font-bold text-[#0B2E6B]">{avgNirf}</div></CardContent></Card>
          <Card><CardContent className="p-4"><div className="text-sm text-muted-foreground">Overall Achievement</div><div className="text-2xl font-bold text-green-600">{overallPct}%</div></CardContent></Card>
        </div>

        <Card>
          <CardHeader><CardTitle className="text-base">Department Ranking (by Overall Achievement)</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-3">
              {sorted.map((d, idx) => {
                const pct = getDeptOverall(d);
                return (
                  <div key={d.id} className="flex items-center gap-4 cursor-pointer hover:bg-muted/50 p-2 rounded-lg" onClick={() => setSelectedDept(selectedDept === d.id ? null : d.id)}>
                    <div className="w-8 h-8 rounded-full bg-[#0B2E6B] text-white flex items-center justify-center text-sm font-bold">{idx + 1}</div>
                    <div className="w-12 text-sm font-bold text-[#0B2E6B]">{d.name}</div>
                    <div className="flex-1">
                      <div className="h-4 rounded-full bg-muted overflow-hidden">
                        <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, backgroundColor: pct >= 70 ? "#22c55e" : pct >= 50 ? "#f59e0b" : "#ef4444" }} />
                      </div>
                    </div>
                    <div className="w-16 text-right text-sm font-bold">{pct}%</div>
                    <div className="w-20 text-right text-xs text-muted-foreground">{d.faculty} Fac</div>
                    <div className="w-20 text-right text-xs text-muted-foreground">{d.students} Stu</div>
                    <div className="w-16 text-right text-xs font-semibold text-[#0B2E6B]">NIRF: {d.nirfScore}</div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {focused.map(d => {
          const overall = getDeptOverall(d);
          return (
            <Card key={d.id}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">{d.name} - {d.fullName}</CardTitle>
                    <p className="text-xs text-muted-foreground mt-0.5">{d.faculty} Faculty | {d.students} Students | NIRF Score: {d.nirfScore}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold" style={{ color: overall >= 70 ? "#22c55e" : overall >= 50 ? "#f59e0b" : "#ef4444" }}>{overall}%</div>
                    <div className="text-xs text-muted-foreground">Overall</div>
                  </div>
                </div>
                <div className="h-3 rounded-full bg-muted overflow-hidden mt-3">
                  <div className="h-full rounded-full transition-all" style={{ width: `${overall}%`, backgroundColor: overall >= 70 ? "#22c55e" : overall >= 50 ? "#f59e0b" : "#ef4444" }} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {metrics.map(m => {
                    const data = d[m.key];
                    const pct = data.target > 0 ? Math.round((data.achieved / data.target) * 100) : 0;
                    const pending = data.target - data.achieved;
                    return (
                      <div key={m.key} className="border rounded-lg p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <m.icon className="h-4 w-4" style={{ color: m.color }} />
                          <span className="text-xs font-semibold">{m.label}</span>
                        </div>
                        <div className="flex items-baseline gap-1 mb-1">
                          <span className="text-lg font-bold">{data.achieved}</span>
                          <span className="text-xs text-muted-foreground">/ {data.target}</span>
                        </div>
                        <div className="h-2 rounded-full bg-muted overflow-hidden mb-2">
                          <div className="h-full rounded-full transition-all" style={{ width: `${Math.min(pct, 100)}%`, backgroundColor: pct >= 70 ? "#22c55e" : pct >= 40 ? "#f59e0b" : "#ef4444" }} />
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-green-600 font-semibold">{pct}% done</span>
                          <span className="text-red-500">{pending > 0 ? `${pending} pending` : "Complete"}</span>
                        </div>
                        <div className="mt-1">
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${pct >= 70 ? "bg-green-100 text-green-700" : pct >= 40 ? "bg-yellow-100 text-yellow-700" : "bg-red-100 text-red-700"}`}>
                            {pct >= 70 ? "ON TRACK" : pct >= 40 ? "NEEDS FOCUS" : "BEHIND"}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          );
        })}

        <Card>
          <CardHeader><CardTitle className="text-base">Cross-Department Comparison</CardTitle></CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b bg-[#0B2E6B] text-white">
                    <th className="px-3 py-2 text-left">Dept</th>
                    {metrics.map(m => <th key={m.key} className="px-3 py-2 text-center text-xs">{m.label}</th>)}
                    <th className="px-3 py-2 text-center">Overall</th>
                    <th className="px-3 py-2 text-center">NIRF</th>
                  </tr>
                </thead>
                <tbody>
                  {focused.map(d => {
                    const overall = getDeptOverall(d);
                    return (
                      <tr key={d.id} className="border-b last:border-0 hover:bg-muted/50">
                        <td className="px-3 py-2 font-bold text-[#0B2E6B]">{d.name}</td>
                        {metrics.map(m => {
                          const data = d[m.key];
                          const pct = data.target > 0 ? Math.round((data.achieved / data.target) * 100) : 0;
                          return (
                            <td key={m.key} className="px-3 py-2 text-center">
                              <div className="text-xs">{data.achieved}/{data.target}</div>
                              <div className={`text-[10px] font-bold ${pct >= 70 ? "text-green-600" : pct >= 40 ? "text-yellow-600" : "text-red-600"}`}>{pct}%</div>
                            </td>
                          );
                        })}
                        <td className="px-3 py-2 text-center">
                          <span className={`text-sm font-bold ${overall >= 70 ? "text-green-600" : overall >= 50 ? "text-yellow-600" : "text-red-600"}`}>{overall}%</span>
                        </td>
                        <td className="px-3 py-2 text-center font-semibold text-[#0B2E6B]">{d.nirfScore}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
