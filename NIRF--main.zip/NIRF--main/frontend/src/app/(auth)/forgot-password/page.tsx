"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary/5 via-background to-primary/10 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-primary text-primary-foreground font-bold text-lg">N</div>
          <CardTitle className="text-2xl font-bold">Forgot Password</CardTitle>
          <CardDescription>Enter your email to receive a reset link</CardDescription>
        </CardHeader>
        <CardContent>
          {sent ? (
            <div className="rounded-md bg-green-50 p-3 text-sm text-green-800 text-center">Password reset email sent. Check your inbox.</div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2"><Label>Email</Label><Input type="email" placeholder="your@email.com" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex flex-col gap-3">
          {!sent && <Button className="w-full" onClick={() => setSent(true)}>Send Reset Link</Button>}
          <Link href="/login" className="text-sm text-primary hover:underline">Back to Sign in</Link>
        </CardFooter>
      </Card>
    </div>
  );
}
