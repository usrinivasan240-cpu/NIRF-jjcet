export enum Role {
  SUPER_ADMIN = "SUPER_ADMIN",
  PRINCIPAL = "PRINCIPAL",
  VICE_PRINCIPAL = "VICE_PRINCIPAL",
  HOD = "HOD",
  DEPARTMENT_STAFF = "DEPARTMENT_STAFF",
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: Role;
  departmentId?: string;
  department?: string;
  avatar?: string;
  phone?: string;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  description?: string;
  established?: number;
  facultyCount?: number;
  studentCount?: number;
  publications?: number;
  patents?: number;
  researchProjects?: number;
  grants?: number;
  nirfScore?: number;
}

export interface Faculty {
  id: string;
  name: string;
  email: string;
  designation: string;
  departmentId: string;
  department?: string;
  qualification: string;
  experience: number;
  googleScholarId?: string;
  scopusId?: string;
  orcidId?: string;
  researchInterests?: string[];
  publications?: number;
  patents?: number;
}

export interface Publication {
  id: string;
  title: string;
  authors: string[];
  facultyId: string;
  departmentId: string;
  journal: string;
  publisher?: string;
  quartile?: string;
  isSCI: boolean;
  isSCIE: boolean;
  isScopus: boolean;
  isUGC: boolean;
  issn?: string;
  doi?: string;
  publicationDate: string;
  citationCount: number;
  status: string;
  proofUrl?: string;
}

export interface Patent {
  id: string;
  title: string;
  patentNumber?: string;
  facultyId: string;
  departmentId: string;
  country?: string;
  isPublished: boolean;
  isGranted: boolean;
  filedDate?: string;
  grantedDate?: string;
  status: string;
  proofUrl?: string;
}

export interface Target {
  id: string;
  departmentId: string;
  category: string;
  target: number;
  achieved: number;
  remaining: number;
  completionPercentage: number;
  year: number;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data?: T;
  error?: string;
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export interface DashboardStats {
  totalDepartments: number;
  totalFaculty: number;
  totalPublications: number;
  totalPatents: number;
  totalResearchProjects: number;
  totalGrants: number;
  totalStudents: number;
  nirfScore: number;
  targetAchievement: number;
}
