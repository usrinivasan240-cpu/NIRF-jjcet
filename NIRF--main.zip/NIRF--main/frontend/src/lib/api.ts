const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";

class ApiClient {
  private token: string | null = null;

  setToken(token: string | null) {
    this.token = token;
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      ...((options.headers as Record<string, string>) || {}),
    };
    if (this.token) headers["Authorization"] = `Bearer ${this.token}`;

    const res = await fetch(`${API_BASE}${endpoint}`, { ...options, headers });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "API Error");
    return data;
  }

  get<T>(endpoint: string) { return this.request<T>(endpoint); }
  post<T>(endpoint: string, body: any) { return this.request<T>(endpoint, { method: "POST", body: JSON.stringify(body) }); }
  put<T>(endpoint: string, body: any) { return this.request<T>(endpoint, { method: "PUT", body: JSON.stringify(body) }); }
  delete<T>(endpoint: string) { return this.request<T>(endpoint, { method: "DELETE" }); }

  // Auth
  login(email: string, password: string) { return this.post<{ token: string; user: any }>("/auth/login", { email, password }); }
  register(data: any) { return this.post("/auth/register", data); }
  getProfile() { return this.get("/auth/profile"); }

  // Departments
  getDepartments() { return this.get("/departments"); }
  getDepartment(id: string) { return this.get(`/departments/${id}`); }
  createDepartment(data: any) { return this.post("/departments", data); }
  updateDepartment(id: string, data: any) { return this.put(`/departments/${id}`, data); }
  deleteDepartment(id: string) { return this.delete(`/departments/${id}`); }

  // Faculty
  getFaculty() { return this.get("/faculty"); }
  createFaculty(data: any) { return this.post("/faculty", data); }
  updateFaculty(id: string, data: any) { return this.put(`/faculty/${id}`, data); }
  deleteFaculty(id: string) { return this.delete(`/faculty/${id}`); }

  // Publications
  getPublications() { return this.get("/publications"); }
  createPublication(data: any) { return this.post("/publications", data); }
  updatePublication(id: string, data: any) { return this.put(`/publications/${id}`, data); }
  deletePublication(id: string) { return this.delete(`/publications/${id}`); }

  // Patents
  getPatents() { return this.get("/patents"); }
  createPatent(data: any) { return this.post("/patents", data); }
  updatePatent(id: string, data: any) { return this.put(`/patents/${id}`, data); }
  deletePatent(id: string) { return this.delete(`/patents/${id}`); }

  // Research
  getResearch() { return this.get("/research"); }
  createResearch(data: any) { return this.post("/research", data); }
  updateResearch(id: string, data: any) { return this.put(`/research/${id}`, data); }
  deleteResearch(id: string) { return this.delete(`/research/${id}`); }

  // PhD
  getPhd() { return this.get("/phd"); }
  createPhd(data: any) { return this.post("/phd", data); }
  updatePhd(id: string, data: any) { return this.put(`/phd/${id}`, data); }
  deletePhd(id: string) { return this.delete(`/phd/${id}`); }

  // Students
  getStudents() { return this.get("/students"); }
  createStudent(data: any) { return this.post("/students", data); }
  updateStudent(id: string, data: any) { return this.put(`/students/${id}`, data); }
  deleteStudent(id: string) { return this.delete(`/students/${id}`); }

  // Events
  getEvents() { return this.get("/events"); }
  createEvent(data: any) { return this.post("/events", data); }
  updateEvent(id: string, data: any) { return this.put(`/events/${id}`, data); }
  deleteEvent(id: string) { return this.delete(`/events/${id}`); }

  // Reviews
  getReviews() { return this.get("/reviews"); }
  submitReview(data: any) { return this.post("/reviews", data); }

  // Targets
  getTargets() { return this.get("/targets"); }
  createTarget(data: any) { return this.post("/targets", data); }
  updateTarget(id: string, data: any) { return this.put(`/targets/${id}`, data); }

  // Approvals
  getApprovals() { return this.get("/approvals"); }
  approveItem(id: string) { return this.put(`/approvals/${id}/approve`, {}); }
  rejectItem(id: string) { return this.put(`/approvals/${id}/reject`, {}); }

  // Documents
  getDocuments() { return this.get("/documents"); }
  uploadDocument(data: any) { return this.post("/documents", data); }
  deleteDocument(id: string) { return this.delete(`/documents/${id}`); }

  // Reports
  getReports() { return this.get("/reports"); }
  generateReport(data: any) { return this.post("/reports/generate", data); }

  // Analytics
  getAnalytics() { return this.get("/analytics"); }

  // AI
  getAiInsights() { return this.get("/ai"); }

  // Notifications
  getNotifications() { return this.get("/notifications"); }
  markNotificationRead(id: string) { return this.put(`/notifications/${id}/read`, {}); }

  // Users
  getUsers() { return this.get("/users"); }
  createUser(data: any) { return this.post("/users", data); }
  updateUser(id: string, data: any) { return this.put(`/users/${id}`, data); }
  deleteUser(id: string) { return this.delete(`/users/${id}`); }

  // Settings
  getSettings() { return this.get("/settings"); }
  updateSettings(data: any) { return this.put("/settings", data); }
}

export const api = new ApiClient();
