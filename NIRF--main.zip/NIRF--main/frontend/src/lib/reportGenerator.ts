import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

export interface BrandingData {
  collegeName: string;
  shortName: string;
  logo: string | null;
  headerBanner: string | null;
  logoBase64?: string | null;
  bannerBase64?: string | null;
  address: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  website: string;
  email: string;
  phone: string;
  motto: string;
  principalName: string;
  established: string;
}

export interface TargetRow {
  sno: number;
  metric: string;
  yearlyTarget: number;
  targetTillMonth: number;
  achieved: number;
  pending: number;
  achievementPct: string;
  status: "ON TRACK" | "BEHIND";
}

export interface DetailedSummary {
  publications: { label: string; value: number }[];
  patents: { label: string; value: number }[];
  research: { label: string; value: number }[];
  studentActivities: { label: string; value: number }[];
}

export interface MonthWiseRow {
  metric: string;
  months: (number | "-")[];
}

export interface ReportData {
  header: {
    reportId: string;
    reportType: string;
    academicYear: string;
    generatedOn: string;
    generatedBy: string;
  };
  departmentInfo: {
    deptName: string;
    month: string;
    totalFaculty: number;
    totalStudents: number;
    hodName: string;
    contact: string;
    reportStatus: string;
    submittedDate: string;
  };
  targetVsAchievement: TargetRow[];
  detailedSummary: DetailedSummary;
  monthWise: MonthWiseRow[];
  remarks: string;
  signatures: {
    hod: { name: string; designation: string; date: string; userId?: string; enabled?: boolean };
    vp: { name: string; designation: string; date: string; userId?: string; enabled?: boolean };
    principal: { name: string; designation: string; date: string; userId?: string; enabled?: boolean };
  };
}

// ═══════════════════════════════════════════════════════════════════
// BRANDING
// ═══════════════════════════════════════════════════════════════════

const DEFAULT_BRANDING: BrandingData = {
  collegeName: "JJ College of Engineering & Technology",
  shortName: "JJCET",
  logo: null,
  headerBanner: null,
  address: "NH-544, Trichy - Thanjavur Road, Pichanur",
  city: "Trichy",
  state: "Tamil Nadu",
  country: "India",
  postalCode: "620 105",
  website: "https://www.jjcet.edu.in",
  email: "info@jjcet.edu.in",
  phone: "+91 431 245 0001",
  motto: "INNOVATE \u2022 TRANSFORM \u2022 INSPIRE",
  principalName: "Dr. Rajesh Kumar",
  established: "1994",
};

let _cachedBranding: BrandingData | null = null;
let _brandingFetchPromise: Promise<BrandingData> | null = null;
let _cachedCompressedLogo: string | null = null;
export async function fetchAllSignatures(): Promise<Record<string, string>> {
  return {};
}

function compressImageForPDF(dataURL: string, maxWidth: number = 600, quality: number = 0.85): Promise<string> {
  return new Promise((resolve) => {
    try {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const ratio = Math.min(maxWidth / img.width, 1);
        canvas.width = img.width * ratio;
        canvas.height = img.height * ratio;
        const ctx = canvas.getContext("2d");
        if (!ctx) { resolve(dataURL); return; }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = () => resolve(dataURL);
      img.src = dataURL;
    } catch { resolve(dataURL); }
  });
}

async function fetchCompressedLogo(): Promise<string | null> {
  if (_cachedCompressedLogo) return _cachedCompressedLogo;
  try {
    const res = await fetch("/logo.png");
    if (!res.ok) return null;
    const blob = await res.blob();
    const dataURL = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.readAsDataURL(blob);
    });
    _cachedCompressedLogo = await compressImageForPDF(dataURL, 600, 0.85);
    return _cachedCompressedLogo;
  } catch { return null; }
}

export async function fetchBranding(): Promise<BrandingData> {
  if (_cachedBranding) return _cachedBranding;
  if (_brandingFetchPromise) return _brandingFetchPromise;

  _brandingFetchPromise = (async () => {
    try {
      const API = typeof window !== "undefined"
        ? (process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000")
        : "http://localhost:5000";
      const token = typeof window !== "undefined" ? localStorage.getItem("token") : null;
      const headers: Record<string, string> = {};
      if (token) headers.Authorization = `Bearer ${token}`;
      const res = await fetch(`${API}/api/branding/active-with-images`, { headers });
      const json = await res.json();
      if (json.success && json.data) {
        _cachedBranding = json.data as BrandingData;
        return _cachedBranding!;
      }
    } catch (err) {
      console.warn("[Branding] Failed to load branding from API, using defaults");
    }
    _cachedBranding = DEFAULT_BRANDING;
    return _cachedBranding!;
  })();
  return _brandingFetchPromise;
}

export function clearBrandingCache(): void {
  _cachedBranding = null;
  _brandingFetchPromise = null;
  _cachedCompressedLogo = null;
}

function formatDate(d: Date = new Date()): string {
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "2-digit", year: "numeric" });
}

function formatTime(d: Date = new Date()): string {
  return d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function generateReportId(): string {
  const d = new Date();
  const yy = String(d.getFullYear()).slice(-2);
  const yy2 = String(d.getFullYear() + 1).slice(-2);
  return `JJCE/REP/${d.getFullYear()}-${yy2}/${String(Math.floor(Math.random() * 9000) + 1000).padStart(4, "0")}`;
}

// ═══════════════════════════════════════════════════════════════════
// COLORS
// ═══════════════════════════════════════════════════════════════════

const C = {
  navy: [11, 46, 107] as [number, number, number],
  navyDark: [8, 30, 75] as [number, number, number],
  navyLight: [200, 215, 235] as [number, number, number],
  orange: [230, 126, 34] as [number, number, number],
  red: [220, 53, 69] as [number, number, number],
  green: [40, 167, 69] as [number, number, number],
  white: [255, 255, 255] as [number, number, number],
  gray: [108, 117, 125] as [number, number, number],
  grayLight: [248, 249, 250] as [number, number, number],
  grayMed: [222, 226, 230] as [number, number, number],
  black: [33, 37, 41] as [number, number, number],
};

// ═══════════════════════════════════════════════════════════════════
// PDF GENERATION
// ═══════════════════════════════════════════════════════════════════

export async function generatePDF(data: ReportData, filename?: string, branding?: BrandingData, signatureImages?: Record<string, string>, options?: { includeDetailedSummary?: boolean }): Promise<void> {
  const b = branding || _cachedBranding || DEFAULT_BRANDING;
  const includeDS = options?.includeDetailedSummary !== false;
  const doc = new jsPDF("p", "mm", "a4");
  const W = 210, H = 297, ML = 8, MR = 8, CW = W - ML - MR;
  let y = 0;

  const logoImg = await fetchCompressedLogo();

  // ════════════════════════════════════════
  // HEADER (compact)
  // ════════════════════════════════════════
  doc.setFillColor(...C.navy);
  doc.rect(0, 0, W, 22, "F");
  doc.setFillColor(...C.orange);
  doc.rect(0, 22, W, 0.8, "F");

  if (logoImg) {
    try { doc.addImage(logoImg, "JPEG", ML, 0.5, 42, 21); } catch { /* skip */ }
  } else {
    doc.setFillColor(...C.orange); doc.circle(ML + 21, 11, 9, "F");
    doc.setFillColor(...C.white); doc.circle(ML + 21, 11, 7, "F");
    doc.setFillColor(...C.navy); doc.circle(ML + 21, 11, 5, "F");
    doc.setFillColor(...C.orange); doc.circle(ML + 21, 11, 3.5, "F");
    doc.setTextColor(...C.white); doc.setFontSize(3.5); doc.setFont("helvetica", "bold");
    doc.text("JJCET", ML + 21, 12, { align: "center" });
  }

  const boxW = 52, boxX = W - MR - boxW, boxY = 1;
  doc.setFillColor(...C.white); doc.roundedRect(boxX, boxY, boxW, 20, 1, 1, "F");
  doc.setDrawColor(...C.navyLight); doc.setLineWidth(0.2); doc.roundedRect(boxX, boxY, boxW, 20, 1, 1, "S");
  const meta = [
    ["REPORT ID", data.header.reportId], ["REPORT TYPE", data.header.reportType],
    ["ACADEMIC YEAR", data.header.academicYear], ["GENERATED ON", data.header.generatedOn],
    ["GENERATED BY", data.header.generatedBy],
  ];
  meta.forEach((m, i) => {
    const my = boxY + 3 + i * 3.6;
    doc.setFontSize(4.5); doc.setFont("helvetica", "bold"); doc.setTextColor(...C.navy);
    doc.text(m[0], boxX + 1.5, my);
    doc.setFont("helvetica", "normal"); doc.setTextColor(...C.black);
    doc.text(`: ${m[1]}`, boxX + 18, my);
  });

  y = 25;

  // ════════════════════════════════════════
  // TITLE BAR (compact)
  // ════════════════════════════════════════
  doc.setFillColor(...C.navy); doc.roundedRect(ML, y, CW, 6, 0.5, 0.5, "F");
  doc.setTextColor(...C.white); doc.setFontSize(7); doc.setFont("helvetica", "bold");
  doc.text("DEPARTMENT MONTHLY PERFORMANCE REPORT", W / 2, y + 4, { align: "center" });
  y += 8;

  // ════════════════════════════════════════
  // DEPARTMENT INFO (compact)
  // ════════════════════════════════════════
  const di = data.departmentInfo;
  doc.setDrawColor(...C.navyLight); doc.setLineWidth(0.2); doc.roundedRect(ML, y, CW, 14, 0.5, 0.5, "S");
  doc.setFillColor(...C.navy); doc.rect(ML, y, 1, 14, "F");
  const infoL = ML + 4, infoR = W / 2 + 4;
  let iy = y + 3; doc.setFontSize(5);
  [["Department Name", di.deptName], ["Month", di.month], ["Total Faculty", String(di.totalFaculty)], ["Total Students", String(di.totalStudents)]].forEach(p => {
    doc.setFont("helvetica", "bold"); doc.setTextColor(...C.black); doc.text(p[0], infoL, iy);
    doc.setFont("helvetica", "normal"); doc.setTextColor(...C.gray); doc.text(`: ${p[1]}`, infoL + 26, iy);
    iy += 2.6;
  });
  iy = y + 3;
  [["HOD Name", di.hodName], ["Contact", di.contact], ["Report Status", di.reportStatus], ["Submitted Date", di.submittedDate]].forEach(p => {
    doc.setFont("helvetica", "bold"); doc.setTextColor(...C.black); doc.text(p[0], infoR, iy);
    doc.setFont("helvetica", "normal"); doc.setTextColor(...C.gray); doc.text(`: ${p[1]}`, infoR + 22, iy);
    iy += 2.6;
  });
  y += 17;

  // ════════════════════════════════════════
  // SECTION 1: TARGET vs ACHIEVEMENT (compact table)
  // ════════════════════════════════════════
  doc.setFillColor(...C.navy); doc.roundedRect(ML, y, 55, 4.5, 0.5, 0.5, "F");
  doc.setTextColor(...C.white); doc.setFontSize(5); doc.setFont("helvetica", "bold");
  doc.text("1. TARGET vs ACHIEVEMENT SUMMARY", ML + 1.5, y + 3.2);
  y += 5.5;

  const targets = data.targetVsAchievement;
  const head = [["S.No.", "Performance Metric", "Yearly\nTarget", "Target\n(Till Month)", "Achieved", "Pending", "Achievement\n%"]];
  const body = targets.map((r) => [
    String(r.sno), r.metric, String(r.yearlyTarget), String(r.targetTillMonth),
    String(r.achieved), String(r.pending), r.achievementPct,
  ]);

  autoTable(doc, {
    startY: y, head, body,
    styles: { fontSize: 4.5, cellPadding: 1.2, overflow: "linebreak", font: "helvetica", halign: "center", valign: "middle", lineColor: [...C.navyLight], lineWidth: 0.15 },
    headStyles: { fillColor: C.navy, textColor: C.white, fontStyle: "bold", fontSize: 4, cellPadding: 1, lineColor: C.navy, lineWidth: 0.2 },
    columnStyles: { 0: { cellWidth: 8, halign: "center" }, 1: { cellWidth: 48, halign: "left" }, 2: { cellWidth: 18 }, 3: { cellWidth: 20 }, 4: { cellWidth: 18 }, 5: { cellWidth: 18 }, 6: { cellWidth: 20 } },
    alternateRowStyles: { fillColor: C.grayLight },
    margin: { left: ML, right: MR },
    didParseCell: (hookData) => {
      if (hookData.section === "body" && hookData.column.index === 6) {
        const val = String(hookData.cell.raw).replace("%", "");
        if (Number(val) >= 60) { hookData.cell.styles.textColor = C.green; hookData.cell.styles.fontStyle = "bold"; }
        else { hookData.cell.styles.textColor = C.red; hookData.cell.styles.fontStyle = "bold"; }
      }
    },
  });

  y = (doc as any).lastAutoTable.finalY + 2;

  // ════════════════════════════════════════
  // SECTION 2: DETAILED SUMMARY (optional)
  // ════════════════════════════════════════
  if (includeDS) {
    doc.setFillColor(...C.navy); doc.roundedRect(ML, y, 45, 4.5, 0.5, 0.5, "F");
    doc.setTextColor(...C.white); doc.setFontSize(5); doc.setFont("helvetica", "bold");
    doc.text("2. DETAILED SUMMARY", ML + 1.5, y + 3.2);
    y += 5.5;

    const ds = data.detailedSummary;
    const cardW = CW / 4;
    const cardH = 20;
    const drawCard = (x: number, cy: number, title: string, items: { label: string; value: number }[], totalLabel: string) => {
      doc.setDrawColor(...C.navyLight); doc.setLineWidth(0.15); doc.roundedRect(x, cy, cardW - 1.5, cardH, 0.3, 0.3, "S");
      doc.setFillColor(...C.navy); doc.rect(x, cy, cardW - 1.5, 4, "F");
      doc.setTextColor(...C.white); doc.setFontSize(4); doc.setFont("helvetica", "bold");
      doc.text(title, x + (cardW - 1.5) / 2, cy + 2.8, { align: "center" });
      let ty = cy + 7;
      items.forEach((item) => {
        doc.setFontSize(4); doc.setFont("helvetica", "normal"); doc.setTextColor(...C.black);
        doc.text(item.label, x + 1.5, ty); doc.text(String(item.value), x + cardW - 5, ty, { align: "right" }); ty += 2.5;
      });
      const totalVal = items.reduce((a, it) => a + it.value, 0);
      doc.setDrawColor(...C.navyLight); doc.setLineWidth(0.1); doc.line(x + 1.5, ty - 0.5, x + cardW - 3, ty - 0.5);
      doc.setFont("helvetica", "bold"); doc.setFontSize(4.5); doc.setTextColor(...C.navy);
      doc.text(totalLabel, x + 1.5, ty + 1.5); doc.text(String(totalVal), x + cardW - 5, ty + 1.5, { align: "right" });
    };
    drawCard(ML, y, "PUBLICATIONS", ds.publications, "Total Publications");
    drawCard(ML + cardW, y, "PATENTS", ds.patents, "Total Patents");
    drawCard(ML + cardW * 2, y, "RESEARCH & PROJECTS", ds.research, "Total Projects");
    drawCard(ML + cardW * 3, y, "STUDENT ACTIVITIES", ds.studentActivities, "");
    y += cardH + 3;
  }

  // ════════════════════════════════════════
  // SECTION 3: MONTH-WISE PROGRESS (compact)
  // ════════════════════════════════════════
  const secNum = includeDS ? "3" : "2";
  doc.setFillColor(...C.navy); doc.roundedRect(ML, y, 55, 4.5, 0.5, 0.5, "F");
  doc.setTextColor(...C.white); doc.setFontSize(5); doc.setFont("helvetica", "bold");
  doc.text(`${secNum}. MONTH-WISE PROGRESS OVERVIEW`, ML + 1.5, y + 3.2);
  y += 5.5;

  const months = ["Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May"];
  const mwHead = [["Metric", ...months]];
  const mwBody = data.monthWise.map((r) => [r.metric, ...r.months.map((v) => String(v))]);

  autoTable(doc, {
    startY: y, head: mwHead, body: mwBody,
    styles: { fontSize: 4, cellPadding: 1, overflow: "linebreak", font: "helvetica", halign: "center", valign: "middle", lineColor: [...C.navyLight], lineWidth: 0.1 },
    headStyles: { fillColor: C.navy, textColor: C.white, fontStyle: "bold", fontSize: 3.8, cellPadding: 0.8, lineColor: C.navy, lineWidth: 0.15 },
    columnStyles: { 0: { cellWidth: 24, halign: "left" } },
    alternateRowStyles: { fillColor: C.grayLight },
    margin: { left: ML, right: MR },
  });

  y = (doc as any).lastAutoTable.finalY + 1.5;
  doc.setFontSize(3.5); doc.setFont("helvetica", "italic"); doc.setTextColor(...C.gray);
  doc.text("Note: April & May are non-working months (Examinations / Vacation).", ML, y + 1);
  y += 4;

  // ════════════════════════════════════════
  // SECTION 4: REMARKS (compact)
  // ════════════════════════════════════════
  const remNum = includeDS ? "4" : "3";
  doc.setFillColor(...C.navy); doc.roundedRect(ML, y, 40, 4.5, 0.5, 0.5, "F");
  doc.setTextColor(...C.white); doc.setFontSize(5); doc.setFont("helvetica", "bold");
  doc.text(`${remNum}. REMARKS BY HOD`, ML + 1.5, y + 3.2);
  y += 5.5;

  doc.setDrawColor(...C.navyLight); doc.setLineWidth(0.2); doc.roundedRect(ML, y, CW, 8, 0.5, 0.5, "S");
  if (data.remarks) {
    doc.setFont("helvetica", "normal"); doc.setFontSize(4.5); doc.setTextColor(...C.black);
    const lines = doc.splitTextToSize(data.remarks, CW - 4);
    doc.text(lines.slice(0, 2), ML + 2, y + 3);
  }
  y += 10;

  // ════════════════════════════════════════
  // SIGNATURES (at the very end, formal layout)
  // ════════════════════════════════════════
  const sigW = CW / 3;
  const sigH = 18;
  const sigs = [
    { title: "HOD REMARKS", name: data.signatures.hod.name || b.principalName, sub: "Head of the Department", date: data.signatures.hod.date, userId: data.signatures.hod.userId, role: "HOD", enabled: data.signatures.hod.enabled !== false },
    { title: "VICE PRINCIPAL SIGNATURE", name: data.signatures.vp.name || "Dr. S. Velmurgan", sub: "Vice Principal", date: data.signatures.vp.date, userId: data.signatures.vp.userId, role: "VICE_PRINCIPAL", enabled: data.signatures.vp.enabled !== false },
    { title: "HEAD MASTER SIGNATURE", name: data.signatures.principal.name || "Dr. P. Selvakumar", sub: "Principal", date: data.signatures.principal.date, userId: data.signatures.principal.userId, role: "PRINCIPAL", enabled: data.signatures.principal.enabled !== false },
  ];

  sigs.forEach((s, i) => {
    const sx = ML + i * sigW;
    doc.setDrawColor(...C.navyLight); doc.setLineWidth(0.2); doc.roundedRect(sx + 0.5, y, sigW - 1, sigH, 0.5, 0.5, "S");
    doc.setFontSize(4.5); doc.setFont("helvetica", "bold"); doc.setTextColor(...C.navy);
    doc.text(s.title, sx + sigW / 2, y + 3, { align: "center" });

    doc.setDrawColor(...C.gray); doc.setLineWidth(0.2);
    doc.line(sx + 8, y + 10, sx + sigW - 8, y + 10);
    doc.setFontSize(4); doc.setFont("helvetica", "bold"); doc.setTextColor(...C.black);
    doc.text(s.name, sx + sigW / 2, y + 13, { align: "center" });
    doc.setFont("helvetica", "normal"); doc.setTextColor(...C.gray);
    doc.text(s.sub, sx + sigW / 2, y + 15.5, { align: "center" });
    doc.setFontSize(3.5);
    doc.text(`Date: ${s.date}`, sx + sigW / 2, y + 17.5, { align: "center" });
  });

  y += sigH + 3;

  // ════════════════════════════════════════
  // FOOTER (clean, no QR code)
  // ════════════════════════════════════════
  const fY = H - 10;
  doc.setDrawColor(...C.navy); doc.setLineWidth(0.3); doc.line(ML, fY, W - MR, fY);
  doc.setFontSize(4.5); doc.setFont("helvetica", "bold"); doc.setTextColor(...C.navy);
  doc.text(b.collegeName.toUpperCase(), W / 2, fY + 3, { align: "center" });
  doc.setFontSize(3.5); doc.setFont("helvetica", "normal"); doc.setTextColor(...C.gray);
  doc.text(`${b.address}, ${b.city} - ${b.postalCode}, ${b.state}`, W / 2, fY + 6, { align: "center" });
  doc.text(`${b.phone} | ${b.email} | ${b.website}`, W / 2, fY + 8.5, { align: "center" });

  const name = filename || `Monthly_Report_${data.header.reportId.replace(/\//g, "-")}`;
  doc.save(`${name}.pdf`);
}

// ═══════════════════════════════════════════════════════════════════
// EXCEL EXPORT
// ═══════════════════════════════════════════════════════════════════

export function generateExcel(data: ReportData, filename?: string, branding?: BrandingData): void {
  const b = branding || _cachedBranding || DEFAULT_BRANDING;
  const wb = XLSX.utils.book_new();

  const rows: (string | number)[][] = [
    [b.collegeName],
    ["Department Monthly Performance Report"],
    [""],
    [`Report ID: ${data.header.reportId}`],
    [`Academic Year: ${data.header.academicYear}`],
    [`Generated: ${data.header.generatedOn}`],
    [""],
    ["TARGET vs ACHIEVEMENT SUMMARY"],
    ["S.No.", "Performance Metric", "Yearly Target", "Target (Till Month)", "Achieved", "Pending", "Achievement %"],
  ];
  data.targetVsAchievement.forEach((r) => {
    rows.push([r.sno, r.metric, r.yearlyTarget, r.targetTillMonth, r.achieved, r.pending, r.achievementPct]);
  });
  rows.push([""]);
  rows.push(["MONTH-WISE PROGRESS"]);
  rows.push(["Metric", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May"]);
  data.monthWise.forEach((r) => {
    rows.push([r.metric, ...r.months]);
  });

  const ws = XLSX.utils.aoa_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, "Report");
  const name = filename || `Monthly_Report_${data.header.reportId.replace(/\//g, "-")}`;
  XLSX.writeFile(wb, `${name}.xlsx`);
}

// ═══════════════════════════════════════════════════════════════════
// CSV EXPORT
// ═══════════════════════════════════════════════════════════════════

export function generateCSV(data: ReportData, filename?: string, branding?: BrandingData): void {
  const lines: string[] = [
    '"S.No.","Performance Metric","Yearly Target","Target (Till Month)","Achieved","Pending","Achievement %","Status"',
  ];
  data.targetVsAchievement.forEach((r) => {
    lines.push(`"${r.sno}","${r.metric}","${r.yearlyTarget}","${r.targetTillMonth}","${r.achieved}","${r.pending}","${r.achievementPct}","${r.status}"`);
  });
  const csv = lines.join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  const name = filename || `Monthly_Report_${data.header.reportId.replace(/\//g, "-")}`;
  a.download = `${name}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ═══════════════════════════════════════════════════════════════════
// PRINT REPORT — HTML A4
// ═══════════════════════════════════════════════════════════════════

export function printReport(data: ReportData, branding?: BrandingData, signatureImages?: Record<string, string>): void {
  const b = branding || _cachedBranding || DEFAULT_BRANDING;
  const win = window.open("", "_blank");
  if (!win) return;

  const di = data.departmentInfo;
  const targets = data.targetVsAchievement;
  const ds = data.detailedSummary;
  const mw = data.monthWise;
  const months = ["Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May"];

  const targetRows = targets.map((r) =>
    `<tr>
      <td style="text-align:center;color:#0B2E6B;font-weight:600">${r.sno}</td>
      <td style="text-align:left;padding-left:8px;font-weight:500">${r.metric}</td>
      <td style="text-align:center">${r.yearlyTarget}</td>
      <td style="text-align:center">${r.targetTillMonth}</td>
      <td style="text-align:center;font-weight:600;color:#28a745">${r.achieved}</td>
      <td style="text-align:center;color:${r.pending > 0 ? '#dc3545' : '#28a745'}">${r.pending}</td>
      <td style="text-align:center;font-weight:600">${r.achievementPct}</td>
      <td style="text-align:center;font-weight:700;${r.status === 'ON TRACK' ? 'color:#28a745' : 'color:#dc3545'}">${r.status}</td>
    </tr>`
  ).join("");

  const mwRows = mw.map((r) =>
    `<tr><td style="text-align:left;padding-left:8px;font-weight:500">${r.metric}</td>${r.months.map((v) => `<td style="text-align:center">${v}</td>`).join("")}</tr>`
  ).join("");

  const drawCardHtml = (title: string, items: { label: string; value: number }[], totalLabel: string) => {
    const total = items.reduce((a, it) => a + it.value, 0);
    return `<div class="summary-card">
      <div class="card-header">${title}</div>
      <div class="card-body">
        ${items.map((it) => `<div class="card-row"><span>${it.label}</span><span>${it.value}</span></div>`).join("")}
        ${totalLabel ? `<div class="card-row card-total"><span>${totalLabel}</span><span>${total}</span></div>` : ""}
      </div>
    </div>`;
  };

  win.document.write(`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Monthly Department Performance Report</title>
<style>
  @page{size:A4 portrait;margin:8mm}
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:'Segoe UI',Arial,sans-serif;color:#212529;font-size:9px;background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact;padding:8mm}

  .header{background:#0B2E6B;color:white;padding:8px 15px;border-radius:4px;display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
  .header .logo{width:320px;max-height:110px;object-fit:contain;flex-shrink:0;background:white;border-radius:4px;padding:4px}
  .meta-box{background:white;border-radius:4px;padding:10px 12px;min-width:200px;border:1px solid #c8d7eb}
  .meta-box div{padding:2px 0;font-size:8px;display:flex;gap:4px}
  .meta-box .lbl{font-weight:700;color:#0B2E6B;min-width:90px}
  .meta-box .val{color:#333}

  .title-bar{background:#0B2E6B;color:white;text-align:center;padding:6px;font-weight:700;font-size:10px;border-radius:3px;margin:8px 0;letter-spacing:0.5px}

  .info-box{border:1px solid #c8d7eb;border-left:3px solid #0B2E6B;display:grid;grid-template-columns:1fr 1fr;gap:0;padding:8px 12px;border-radius:3px;margin:6px 0;background:#f8f9fc;font-size:8px}
  .info-box .row{display:flex;padding:2px 0}
  .info-box .lbl{font-weight:700;color:#212529;width:110px;flex-shrink:0}
  .info-box .val{color:#666}

  .sec-label{background:#0B2E6B;color:white;display:inline-block;padding:3px 10px;font-weight:700;font-size:8px;border-radius:3px;margin:8px 0 4px;letter-spacing:0.3px}

  table{width:100%;border-collapse:collapse;font-size:8px;margin:4px 0}
  th{background:#0B2E6B;color:white;padding:5px 6px;text-align:center;font-size:7.5px;font-weight:600;border:1px solid #0B2E6B}
  td{padding:4px 6px;border:1px solid #dee2e6;text-align:center}
  tr:nth-child(even){background:#f8f9fc}
  .on-track{color:#28a745;font-weight:700}
  .behind{color:#dc3545;font-weight:700}

  .summary-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:6px 0}
  .summary-card{border:1px solid #c8d7eb;border-radius:3px;overflow:hidden}
  .card-header{background:#0B2E6B;color:white;padding:4px 8px;font-size:8px;font-weight:700;text-align:center}
  .card-body{padding:6px 8px;font-size:8px}
  .card-row{display:flex;justify-content:space-between;padding:2px 0;border-bottom:1px solid #f0f0f0}
  .card-row:last-child{border-bottom:none}
  .card-total{font-weight:700;color:#0B2E6B;border-top:1px solid #c8d7eb;margin-top:2px;padding-top:4px}

  .note{font-size:7px;color:#6c757d;font-style:italic;margin:4px 0}

  .remarks-box{border:1px solid #c8d7eb;border-left:3px solid #0B2E6B;border-radius:3px;padding:8px 12px;margin:6px 0;background:#f8f9fc;min-height:40px;font-size:8px}

  .sig-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:8px 0}
  .sig-block{border:1px solid #c8d7eb;border-radius:3px;text-align:center;padding:10px}
  .sig-block .sig-title{font-weight:700;color:#0B2E6B;font-size:8px;margin-bottom:12px}
  .sig-block .sig-line{border-bottom:1px solid #666;margin:0 15px 6px}
  .sig-block .sig-name{font-weight:700;font-size:8px;color:#212529}
  .sig-block .sig-role{font-size:7px;color:#6c757d}
  .sig-block .sig-date{font-size:7px;color:#6c757d;margin-top:4px}

  .footer{border-top:2px solid #0B2E6B;margin-top:10px;padding-top:6px;display:flex;justify-content:center;align-items:center;font-size:7px;color:#6c757d;flex-direction:column;text-align:center}
  .footer .center{text-align:center;color:#0B2E6B}
  .footer .center .fname{font-weight:700;font-size:9px}
  .footer .motto{font-weight:700;font-size:8px}
  .footer .motto span{display:block}

  @media print{body{padding:6mm}.no-print{display:none !important}}
</style>
</head>
<body>

<div class="no-print" style="text-align:center;padding:8px;background:#0B2E6B;color:white;margin-bottom:8px;border-radius:4px">
  <span style="font-size:12px;font-weight:700">Monthly Department Performance Report</span>
  <button onclick="window.print()" style="margin-left:15px;padding:6px 20px;background:#E67E22;color:white;border:none;border-radius:3px;cursor:pointer;font-weight:700">Print / Save as PDF</button>
  <button onclick="window.close()" style="margin-left:8px;padding:6px 15px;background:#555;color:white;border:none;border-radius:3px;cursor:pointer">Close</button>
</div>

<!-- HEADER -->
<div class="header">
  <img src="/logo.png" class="logo" onerror="this.style.display='none'" />
  <div class="meta-box">
    <div><span class="lbl">REPORT ID</span><span class="val">: ${data.header.reportId}</span></div>
    <div><span class="lbl">REPORT TYPE</span><span class="val">: ${data.header.reportType}</span></div>
    <div><span class="lbl">ACADEMIC YEAR</span><span class="val">: ${data.header.academicYear}</span></div>
    <div><span class="lbl">GENERATED ON</span><span class="val">: ${data.header.generatedOn}</span></div>
    <div><span class="lbl">GENERATED BY</span><span class="val">: ${data.header.generatedBy}</span></div>
  </div>
</div>

<!-- TITLE -->
<div class="title-bar">DEPARTMENT MONTHLY PERFORMANCE REPORT</div>

<!-- INFO -->
<div class="info-box">
  <div><div class="row"><span class="lbl">Department Name</span><span class="val">: ${di.deptName}</span></div>
  <div class="row"><span class="lbl">Month</span><span class="val">: ${di.month}</span></div>
  <div class="row"><span class="lbl">Total Faculty</span><span class="val">: ${di.totalFaculty}</span></div>
  <div class="row"><span class="lbl">Total Students</span><span class="val">: ${di.totalStudents}</span></div></div>
  <div><div class="row"><span class="lbl">HOD Name</span><span class="val">: ${di.hodName}</span></div>
  <div class="row"><span class="lbl">Contact</span><span class="val">: ${di.contact}</span></div>
  <div class="row"><span class="lbl">Report Status</span><span class="val">: ${di.reportStatus}</span></div>
  <div class="row"><span class="lbl">Submitted Date</span><span class="val">: ${di.submittedDate}</span></div></div>
</div>

<!-- 1. TARGET vs ACHIEVEMENT -->
<div class="sec-label">1. TARGET vs ACHIEVEMENT SUMMARY</div>
<table>
  <thead><tr><th>S.No.</th><th>Performance Metric</th><th>Yearly Target</th><th>Target (Till This Month)</th><th>Achieved (Till This Month)</th><th>Pending (Till This Month)</th><th>Achievement %</th><th>Status</th></tr></thead>
  <tbody>${targetRows}</tbody>
</table>

<!-- 2. DETAILED SUMMARY -->
<div class="sec-label">2. DETAILED SUMMARY</div>
<div class="summary-grid">
  ${drawCardHtml("PUBLICATIONS", ds.publications, "Total Publications")}
  ${drawCardHtml("PATENTS", ds.patents, "Total Patents")}
  ${drawCardHtml("RESEARCH & PROJECTS", ds.research, "Total Projects")}
  ${drawCardHtml("STUDENT ACTIVITIES", ds.studentActivities, "")}
</div>

<!-- 3. MONTH-WISE PROGRESS -->
<div class="sec-label">3. MONTH-WISE PROGRESS OVERVIEW</div>
<table>
  <thead><tr><th>Metric</th>${months.map((m) => `<th>${m}</th>`).join("")}</tr></thead>
  <tbody>${mwRows}</tbody>
</table>
<div class="note">Note: April & May are non-working months (Examinations / Vacation).</div>

<!-- 4. REMARKS -->
<div class="sec-label">4. REMARKS BY HOD</div>
<div class="remarks-box">${data.remarks || ""}</div>

<!-- SIGNATURES -->
<div class="sig-grid">
  <div class="sig-block"><div class="sig-title">HOD REMARKS</div><div class="sig-line"></div><div class="sig-name">${data.signatures.hod.name || b.principalName}</div><div class="sig-role">Head of the Department</div><div class="sig-date">Date: ${data.signatures.hod.date}</div></div>
  <div class="sig-block"><div class="sig-title">VICE PRINCIPAL SIGNATURE</div><div class="sig-line"></div><div class="sig-name">${data.signatures.vp.name || "Dr. S. Velmurgan"}</div><div class="sig-role">Vice Principal</div><div class="sig-date">Date: ${data.signatures.vp.date}</div></div>
  <div class="sig-block"><div class="sig-title">HEAD MASTER SIGNATURE</div><div class="sig-line"></div><div class="sig-name">${data.signatures.principal.name || "Dr. P. Selvakumar"}</div><div class="sig-role">Principal</div><div class="sig-date">Date: ${data.signatures.principal.date}</div></div>
</div>

<!-- FOOTER -->
<div class="footer">
  <div class="center"><div class="fname">${b.collegeName.toUpperCase()}</div><div>${b.address}, ${b.city} - ${b.postalCode}, ${b.state}, ${b.country}</div><div>Phone: ${b.phone} | Email: ${b.email} | Web: ${b.website}</div></div>
  <div class="motto">${(b.motto || "INNOVATE \u2022 TRANSFORM \u2022 INSPIRE").split(/\u2022|\./).filter(Boolean).map((p, i) => { const c = ["#E67E22","#0B2E6B","#28a745"]; return `<span style="color:${c[i%3]}">${p.trim()}</span>`; }).join("")}</div>
</div>

</body></html>`);
  win.document.close();
}

export { generateReportId, formatDate, formatTime };
