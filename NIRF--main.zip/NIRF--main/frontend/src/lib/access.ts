import { Role } from "@/types";

export type AccessLevel = "full" | "view" | "self" | "own" | "assigned" | "submit" | "upload" | "verify" | "review" | "final" | "approve" | "department" | "none";

export interface ModuleAccess {
  dashboard: AccessLevel;
  departments: AccessLevel;
  faculty: AccessLevel;
  publications: AccessLevel;
  patents: AccessLevel;
  research: AccessLevel;
  phd: AccessLevel;
  researchProposals: AccessLevel;
  students: AccessLevel;
  events: AccessLevel;
  reviews: AccessLevel;
  targets: AccessLevel;
  vpTargets: AccessLevel;
  deptAnalysis: AccessLevel;
  approvals: AccessLevel;
  documents: AccessLevel;
  reports: AccessLevel;
  analytics: AccessLevel;
  ai: AccessLevel;
  notifications: AccessLevel;
  settings: AccessLevel;
  audit: AccessLevel;
  userManagement: AccessLevel;
  branding: AccessLevel;
  pageControl: AccessLevel;
}

export const ROLE_ACCESS: Record<Role, ModuleAccess> = {
  [Role.SUPER_ADMIN]: {
    dashboard: "full", departments: "full", faculty: "full", publications: "full",
    patents: "full", research: "full", phd: "full", researchProposals: "full",
    students: "full", events: "full", reviews: "full", targets: "full",
    vpTargets: "full", deptAnalysis: "full",
    approvals: "full", documents: "full", reports: "full", analytics: "full",
    ai: "full", notifications: "full", settings: "full", audit: "full",
    userManagement: "full", branding: "full", pageControl: "full",
  },
  [Role.PRINCIPAL]: {
    dashboard: "full", departments: "view", faculty: "view", publications: "view",
    patents: "view", research: "view", phd: "view", researchProposals: "view",
    students: "view", events: "view", reviews: "view", targets: "view",
    vpTargets: "view", deptAnalysis: "full",
    approvals: "final", documents: "view", reports: "full", analytics: "full",
    ai: "view", notifications: "full", settings: "none", audit: "none",
    userManagement: "none", branding: "none", pageControl: "none",
  },
  [Role.VICE_PRINCIPAL]: {
    dashboard: "full", departments: "view", faculty: "full", publications: "full",
    patents: "full", research: "full", phd: "full", researchProposals: "full",
    students: "full", events: "full", reviews: "full", targets: "full",
    vpTargets: "full", deptAnalysis: "full",
    approvals: "verify", documents: "full", reports: "full", analytics: "full",
    ai: "full", notifications: "full", settings: "none", audit: "none",
    userManagement: "full", branding: "none", pageControl: "none",
  },
  [Role.HOD]: {
    dashboard: "full", departments: "none", faculty: "full", publications: "full",
    patents: "full", research: "full", phd: "full", researchProposals: "full",
    students: "full", events: "full", reviews: "full", targets: "view",
    vpTargets: "none", deptAnalysis: "none",
    approvals: "approve", documents: "full", reports: "department", analytics: "own",
    ai: "none", notifications: "view", settings: "none", audit: "none",
    userManagement: "none", branding: "none", pageControl: "none",
  },
  [Role.DEPARTMENT_STAFF]: {
    dashboard: "full", departments: "none", faculty: "none", publications: "full",
    patents: "full", research: "full", phd: "full", researchProposals: "full",
    students: "full", events: "full", reviews: "submit", targets: "none",
    vpTargets: "none", deptAnalysis: "none",
    approvals: "submit", documents: "upload", reports: "department", analytics: "none",
    ai: "none", notifications: "full", settings: "none", audit: "none",
    userManagement: "none", branding: "none", pageControl: "none",
  },
};

export function getRoleAccess(role: Role): ModuleAccess {
  return ROLE_ACCESS[role] || ROLE_ACCESS[Role.DEPARTMENT_STAFF];
}

export function hasAccess(role: Role, module: keyof ModuleAccess): boolean {
  const access = getRoleAccess(role);
  return access[module] !== "none";
}

export function canView(role: Role, module: keyof ModuleAccess): boolean {
  return hasAccess(role, module);
}

export function canEdit(role: Role, module: keyof ModuleAccess): boolean {
  const access = getRoleAccess(role);
  return ["full", "own", "self", "assigned", "upload", "submit", "verify", "review", "approve"].includes(access[module]);
}

export function canApprove(role: Role): boolean {
  return [Role.SUPER_ADMIN, Role.PRINCIPAL, Role.VICE_PRINCIPAL, Role.HOD].includes(role);
}

export function canApproveLevel(role: Role): "final" | "verify" | "approve" | null {
  switch (role) {
    case Role.SUPER_ADMIN: return "final";
    case Role.PRINCIPAL: return "final";
    case Role.VICE_PRINCIPAL: return "verify";
    case Role.HOD: return "approve";
    default: return null;
  }
}

export function canAccessDepartment(role: Role, userDepartmentId: string | null, targetDepartmentId: string): boolean {
  if (role === Role.SUPER_ADMIN) return true;
  if (role === Role.PRINCIPAL) return true;
  if (role === Role.VICE_PRINCIPAL) return true;
  return userDepartmentId === targetDepartmentId;
}

export function getDepartmentFilter(role: Role, userDepartmentId: string | null): string | null {
  if (role === Role.SUPER_ADMIN || role === Role.PRINCIPAL || role === Role.VICE_PRINCIPAL) {
    return null;
  }
  return userDepartmentId;
}
