const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api";

export interface FirestoreItem {
  id: string;
  [key: string]: any;
}

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("token");
}

async function apiRequest<T = any>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...((options.headers as Record<string, string>) || {}),
  };
  const token = getToken();
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(`${API_BASE}${endpoint}`, { ...options, headers });
  const json = await res.json();
  if (!res.ok) throw new Error(json.message || "API Error");
  return json;
}

// ─── localStorage fallback ───
function lsGetAll(key: string): FirestoreItem[] {
  if (typeof window === "undefined") return [];
  try { return JSON.parse(localStorage.getItem(`fs_${key}`) || "[]"); } catch { return []; }
}
function lsSave(key: string, items: FirestoreItem[]) {
  if (typeof window === "undefined") return;
  localStorage.setItem(`fs_${key}`, JSON.stringify(items));
}
function lsCreate(key: string, data: Record<string, any>): string {
  const items = lsGetAll(key);
  const id = `local_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  items.unshift({ id, ...data });
  lsSave(key, items);
  return id;
}
function lsUpdate(key: string, id: string, data: Record<string, any>) {
  const items = lsGetAll(key);
  const idx = items.findIndex(i => i.id === id);
  if (idx >= 0) { items[idx] = { ...items[idx], ...data }; lsSave(key, items); }
}
function lsRemove(key: string, id: string) {
  lsSave(key, lsGetAll(key).filter(i => i.id !== id));
}

// ─── Core CRUD: try backend API, fallback to localStorage ───
async function getAll(endpoint: string, collectionKey: string, deptScope?: string | null): Promise<FirestoreItem[]> {
  try {
    const res = await apiRequest(endpoint);
    let data: FirestoreItem[] = res.data || res || [];
    if (deptScope) data = data.filter((i: any) => i.departmentId === deptScope || i.department === deptScope);
    return data;
  } catch (err: any) {
    console.warn(`[API] ${endpoint} failed, using localStorage:`, err.message);
    const items = lsGetAll(collectionKey);
    if (deptScope) return items.filter(i => i.departmentId === deptScope || i.department === deptScope);
    return items;
  }
}

async function create(endpoint: string, collectionKey: string, data: Record<string, any>): Promise<string> {
  try {
    const res = await apiRequest(endpoint, { method: "POST", body: JSON.stringify(data) });
    return res.data?.id || res.id || `api_${Date.now()}`;
  } catch (err: any) {
    console.warn(`[API] POST ${endpoint} failed, using localStorage:`, err.message);
    return lsCreate(collectionKey, data);
  }
}

async function update(endpoint: string, collectionKey: string, id: string, data: Record<string, any>): Promise<void> {
  try {
    await apiRequest(`${endpoint}/${id}`, { method: "PUT", body: JSON.stringify(data) });
  } catch (err: any) {
    console.warn(`[API] PUT ${endpoint}/${id} failed, using localStorage:`, err.message);
    lsUpdate(collectionKey, id, data);
  }
}

async function remove(endpoint: string, collectionKey: string, id: string): Promise<void> {
  try {
    await apiRequest(`${endpoint}/${id}`, { method: "DELETE" });
  } catch (err: any) {
    console.warn(`[API] DELETE ${endpoint}/${id} failed, using localStorage:`, err.message);
    lsRemove(collectionKey, id);
  }
}

export const firestoreService = {
  publications: {
    getAll: (dept?: string | null) => getAll("/publications", "publications", dept),
    create: (data: any) => create("/publications", "publications", data),
    update: (id: string, data: any) => update("/publications", "publications", id, data),
    delete: (id: string) => remove("/publications", "publications", id),
  },
  patents: {
    getAll: (dept?: string | null) => getAll("/patents", "patents", dept),
    create: (data: any) => create("/patents", "patents", data),
    update: (id: string, data: any) => update("/patents", "patents", id, data),
    delete: (id: string) => remove("/patents", "patents", id),
  },
  events: {
    getAll: (dept?: string | null) => getAll("/events", "events", dept),
    create: (data: any) => create("/events", "events", data),
    update: (id: string, data: any) => update("/events", "events", id, data),
    delete: (id: string) => remove("/events", "events", id),
  },
  research: {
    getAll: (dept?: string | null) => getAll("/research", "research", dept),
    create: (data: any) => create("/research", "research", data),
    update: (id: string, data: any) => update("/research", "research", id, data),
    delete: (id: string) => remove("/research", "research", id),
  },
  faculty: {
    getAll: (dept?: string | null) => getAll("/faculty", "faculty", dept),
    create: (data: any) => create("/faculty", "faculty", data),
    update: (id: string, data: any) => update("/faculty", "faculty", id, data),
    delete: (id: string) => remove("/faculty", "faculty", id),
  },
  students: {
    getAll: (dept?: string | null) => getAll("/students", "students", dept),
    create: (data: any) => create("/students", "students", data),
    update: (id: string, data: any) => update("/students", "students", id, data),
    delete: (id: string) => remove("/students", "students", id),
  },
  phd: {
    getAll: (dept?: string | null) => getAll("/phd", "phd", dept),
    create: (data: any) => create("/phd", "phd", data),
    update: (id: string, data: any) => update("/phd", "phd", id, data),
    delete: (id: string) => remove("/phd", "phd", id),
  },
  departments: {
    getAll: () => getAll("/departments", "departments"),
    create: (data: any) => create("/departments", "departments", data),
    update: (id: string, data: any) => update("/departments", "departments", id, data),
    delete: (id: string) => remove("/departments", "departments", id),
  },
  users: {
    getAll: () => getAll("/users", "users"),
    create: (data: any) => create("/users", "users", data),
    update: (id: string, data: any) => update("/users", "users", id, data),
    delete: (id: string) => remove("/users", "users", id),
  },
  targets: {
    getAll: (dept?: string | null) => getAll("/targets", "targets", dept),
    create: (data: any) => create("/targets", "targets", data),
    update: (id: string, data: any) => update("/targets", "targets", id, data),
    delete: (id: string) => remove("/targets", "targets", id),
  },
  vpTargets: {
    getAll: () => getAll("/targets", "vpTargets"),
    create: (data: any) => create("/targets", "vpTargets", data),
    update: (id: string, data: any) => update("/targets", "vpTargets", id, data),
    delete: (id: string) => remove("/targets", "vpTargets", id),
  },
  reviews: {
    getAll: (dept?: string | null) => getAll("/reviews", "reviews", dept),
    create: (data: any) => create("/reviews", "reviews", data),
    update: (id: string, data: any) => update("/reviews", "reviews", id, data),
    delete: (id: string) => remove("/reviews", "reviews", id),
  },
  approvals: {
    getAll: (dept?: string | null) => getAll("/approvals", "approvals", dept),
    create: (data: any) => create("/approvals", "approvals", data),
    update: (id: string, data: any) => update("/approvals", "approvals", id, data),
    delete: (id: string) => remove("/approvals", "approvals", id),
  },
  documents: {
    getAll: (dept?: string | null) => getAll("/documents", "documents", dept),
    create: (data: any) => create("/documents", "documents", data),
    update: (id: string, data: any) => update("/documents", "documents", id, data),
    delete: (id: string) => remove("/documents", "documents", id),
  },
  documentVersions: {
    getAll: (documentId: string) => apiRequest(`/document-versions/${documentId}/versions`),
    getOne: (documentId: string, versionNumber: number) => apiRequest(`/document-versions/${documentId}/versions/${versionNumber}`),
    create: (documentId: string, data: any) => apiRequest(`/document-versions/${documentId}/versions`, { method: "POST", body: JSON.stringify(data) }),
  },
  notifications: {
    getAll: () => getAll("/notifications", "notifications"),
    create: (data: any) => create("/notifications", "notifications", data),
    update: (id: string, data: any) => update("/notifications", "notifications", id, data),
    markRead: (id: string) => update("/notifications", "notifications", id, { isRead: true }),
    delete: (id: string) => remove("/notifications", "notifications", id),
  },
  submissions: {
    getAll: () => getAll("/reviews", "submissions"),
    create: (data: any) => create("/reviews", "submissions", data),
    update: (id: string, data: any) => update("/reviews", "submissions", id, data),
    delete: (id: string) => remove("/reviews", "submissions", id),
  },
  pageControl: {
    getAll: () => Promise.resolve(lsGetAll("pageControl")),
    create: (data: any) => Promise.resolve(lsCreate("pageControl", data)),
    update: (id: string, data: any) => Promise.resolve(lsUpdate("pageControl", id, data)),
    delete: (id: string) => Promise.resolve(lsRemove("pageControl", id)),
  },
};
