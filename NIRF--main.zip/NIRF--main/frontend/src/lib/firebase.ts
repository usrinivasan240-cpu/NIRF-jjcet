import { initializeApp, getApps } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyD0C_yMh65mdf83x4w0VSF1niuSIPH1Rks",
  authDomain: "jjcet-nirf.firebaseapp.com",
  projectId: "jjcet-nirf",
  storageBucket: "jjcet-nirf.firebasestorage.app",
  messagingSenderId: "826599931401",
  appId: "1:826599931401:web:9d0e2b8f565e5d64dd02d8",
  measurementId: "G-V4FYVBVF6E",
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
const db = getFirestore(app);

export { auth, googleProvider, db };
