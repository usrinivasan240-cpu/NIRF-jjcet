import { Request, Response, NextFunction } from "express";

export const errorHandler = (err: any, req: Request, res: Response, next: NextFunction) => {
  console.error(err.stack);
  res.status(err.status || 500).json({ success: false, message: err.message || "Internal Server Error" });
};

export const notFound = (req: Request, res: Response) => {
  res.status(404).json({ success: false, message: "Route not found" });
};
