import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const router = Router();
const prisma = new PrismaClient();

const SELECT_SAFE: any = { id: true, email: true, name: true, role: true, departmentId: true, phone: true, avatar: true, isActive: true, createdAt: true, updatedAt: true };

router.get("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const where: any = {};
    if (departmentScope) where.departmentId = departmentScope;
    const data = await prisma.user.findMany({ where, select: SELECT_SAFE, orderBy: { createdAt: "desc" } });
    res.json({ success: true, data });
  } catch (error) {
    console.error("Error fetching users:", error);
    res.status(500).json({ success: false, message: "Failed to fetch users" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.user.findUnique({ where: { id }, select: SELECT_SAFE });
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch user" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const { password, ...rest } = req.body;
    const data: any = { ...rest };
    if (departmentScope && !data.departmentId) data.departmentId = departmentScope;
    if (password) data.password = await bcrypt.hash(password, 10);
    const item = await prisma.user.create({ data, select: SELECT_SAFE });
    res.status(201).json({ success: true, data: item, message: "User created" });
  } catch (error) {
    console.error("Error creating user:", error);
    res.status(500).json({ success: false, message: "Failed to create user" });
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const { password, ...rest } = req.body;
    const data: any = { ...rest };
    if (password) data.password = await bcrypt.hash(password, 10);
    const item = await prisma.user.update({ where: { id }, data, select: SELECT_SAFE });
    res.json({ success: true, data: item, message: "User updated" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update user" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    await prisma.user.delete({ where: { id } });
    res.json({ success: true, message: "User deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete user" });
  }
});

export default router;
