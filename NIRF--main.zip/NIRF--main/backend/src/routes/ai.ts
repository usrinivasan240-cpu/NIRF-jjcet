import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

router.get("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const deptFilter: any = departmentScope ? { departmentId: departmentScope } : {};

    const [totalPublications, sciCount, scopusCount, totalPatents, grantedPatents, totalFaculty, totalStudents] = await Promise.all([
      prisma.publication.count({ where: deptFilter }),
      prisma.publication.count({ where: { ...deptFilter, isSCI: true } }),
      prisma.publication.count({ where: { ...deptFilter, isScopus: true } }),
      prisma.patent.count({ where: deptFilter }),
      prisma.patent.count({ where: { ...deptFilter, isGranted: true } }),
      prisma.faculty.count({ where: deptFilter }),
      prisma.student.count({ where: deptFilter }),
    ]);

    const insights = {
      generatedAt: new Date().toISOString(),
      summary: `The institution has ${totalPublications} publications, ${totalPatents} patents, ${totalFaculty} faculty members, and ${totalStudents} students.`,
      metrics: {
        publicationToFacultyRatio: totalFaculty > 0 ? (totalPublications / totalFaculty).toFixed(1) : "0",
        sciRatio: totalPublications > 0 ? ((sciCount / totalPublications) * 100).toFixed(1) + "%" : "0%",
        scopusRatio: totalPublications > 0 ? ((scopusCount / totalPublications) * 100).toFixed(1) + "%" : "0%",
        patentGrantRate: totalPatents > 0 ? ((grantedPatents / totalPatents) * 100).toFixed(1) + "%" : "0%",
      },
      recommendations: [
        sciCount < totalPublications * 0.3 ? "Increase SCI-indexed publications to improve NIRF ranking." : "Good progress on SCI publications.",
        grantedPatents < totalPatents * 0.5 ? "Focus on converting filed patents to granted patents." : "Strong patent grant rate.",
        "Encourage interdisciplinary research collaborations.",
        "Increase industry-sponsored research projects.",
      ],
      trendAnalysis: {
        publications: "Steady growth expected based on current faculty strength.",
        patents: "Patent filings are increasing. Focus on grant conversion.",
        research: "More funded projects recommended to boost research output.",
      },
    };

    res.json({ success: true, data: insights });
  } catch (error) {
    console.error("Error generating AI insights:", error);
    res.status(500).json({ success: false, message: "Failed to generate AI insights" });
  }
});

router.post("/predict", async (req: Request, res: Response) => {
  try {
    const { category, currentValue, target } = req.body;
    const gap = (target || 0) - (currentValue || 0);
    const prediction = {
      category,
      currentValue: currentValue || 0,
      target: target || 0,
      gap,
      recommendation: gap > 0 ? `Need ${gap} more ${category} to reach target.` : `Target achieved for ${category}.`,
      confidence: 0.85,
    };
    res.json({ success: true, data: prediction });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to generate prediction" });
  }
});

export default router;
