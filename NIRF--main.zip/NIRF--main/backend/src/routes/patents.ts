import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

router.get("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const where: any = {};
    if (departmentScope) where.departmentId = departmentScope;
    const data = await prisma.patent.findMany({ where, include: { faculty: true, department: true }, orderBy: { createdAt: "desc" } });
    res.json({ success: true, data });
  } catch (error) {
    console.error("Error fetching patents:", error);
    res.status(500).json({ success: false, message: "Failed to fetch patents" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.patent.findUnique({ where: { id }, include: { faculty: true, department: true } });
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch patent" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const data = { ...req.body };
    if (departmentScope && !data.departmentId) data.departmentId = departmentScope;
    const item = await prisma.patent.create({ data, include: { faculty: true, department: true } });
    res.status(201).json({ success: true, data: item, message: "Patent created" });
  } catch (error) {
    console.error("Error creating patent:", error);
    res.status(500).json({ success: false, message: "Failed to create patent" });
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.patent.update({ where: { id }, data: req.body, include: { faculty: true, department: true } });
    res.json({ success: true, data: item, message: "Patent updated" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update patent" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    await prisma.patent.delete({ where: { id } });
    res.json({ success: true, message: "Patent deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete patent" });
  }
});

export default router;
