import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

router.get("/", async (req: Request, res: Response) => {
  try {
    const data = await prisma.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 100 });
    res.json({ success: true, data });
  } catch (error) {
    console.error("Error fetching audit logs:", error);
    res.status(500).json({ success: false, message: "Failed to fetch audit logs" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.auditLog.findUnique({ where: { id } });
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch audit log" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const data = { ...req.body };
    if (user && !data.userId) data.userId = user.userId || user.email || "system";
    const item = await prisma.auditLog.create({ data });
    res.status(201).json({ success: true, data: item, message: "Audit log created" });
  } catch (error) {
    console.error("Error creating audit log:", error);
    res.status(500).json({ success: false, message: "Failed to create audit log" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    await prisma.auditLog.delete({ where: { id } });
    res.json({ success: true, message: "Audit log deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete audit log" });
  }
});

export default router;
