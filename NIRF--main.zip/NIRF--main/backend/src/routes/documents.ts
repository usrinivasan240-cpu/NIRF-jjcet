import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

function flattenDoc(doc: any) {
  if (!doc) return doc;
  const { department, ...rest } = doc;
  return { ...rest, department: department?.code || department?.name || department || null };
}

async function resolveDepartmentId(deptInput: string | null | undefined): Promise<string | null> {
  if (!deptInput) return null;
  if (deptInput.includes("-")) return deptInput;
  const dept = await prisma.department.findFirst({ where: { OR: [{ code: deptInput }, { name: deptInput }] } });
  return dept?.id || null;
}

router.get("/", async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const departmentScope = (req as any).departmentScope as string | null;
    const where: any = {};

    const role = user?.role;
    const userId = user?.id;

    if (role === "SUPER_ADMIN") {
      // sees everything
    } else if (role === "PRINCIPAL") {
      where.OR = [
        { docStatus: "VP_VERIFIED" },
        { docStatus: "PRINCIPAL_APPROVED" },
        { docStatus: "PRINCIPAL_REJECTED" },
        { createdBy: userId },
        { principalApprovedBy: userId },
        { principalRejectedBy: userId },
      ];
    } else if (role === "VICE_PRINCIPAL") {
      where.OR = [
        { docStatus: "HOD_VERIFIED" },
        { docStatus: "VP_VERIFIED" },
        { docStatus: "VP_REJECTED" },
        { createdBy: userId },
        { vpVerifiedBy: userId },
        { vpRejectedBy: userId },
      ];
    } else if (role === "HOD") {
      if (departmentScope) {
        const deptId = await resolveDepartmentId(departmentScope);
        if (deptId) where.departmentId = deptId;
      }
      where.OR = [
        { docStatus: "SUBMITTED" },
        { docStatus: "DRAFT" },
        { docStatus: "HOD_VERIFIED" },
        { docStatus: "HOD_REJECTED" },
        { createdBy: userId },
        { hodVerifiedBy: userId },
        { hodRejectedBy: userId },
      ];
    } else {
      // DEPARTMENT_STAFF and others — only own documents
      where.createdBy = userId;
    }

    const data = await prisma.document.findMany({ where, include: { department: true }, orderBy: { createdAt: "desc" } });
    res.json({ success: true, data: data.map(flattenDoc) });
  } catch (error) {
    console.error("Error fetching documents:", error);
    res.status(500).json({ success: false, message: "Failed to fetch documents" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.document.findUnique({ where: { id }, include: { department: true } });
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: flattenDoc(item) });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch document" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const body: any = { ...req.body };
    delete body.department;
    delete body.id;

    const deptId = await resolveDepartmentId(body.departmentId || departmentScope);
    if (deptId) body.departmentId = deptId;
    else delete body.departmentId;

    const item = await prisma.document.create({ data: body, include: { department: true } });
    res.status(201).json({ success: true, data: flattenDoc(item), message: "Document created" });
  } catch (error: any) {
    console.error("Error creating document:", error);
    res.status(500).json({ success: false, message: error.message || "Failed to create document" });
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const updateData: any = { ...req.body };
    delete updateData.department;
    delete updateData.id;

    if (updateData.departmentId) {
      const deptId = await resolveDepartmentId(updateData.departmentId);
      if (deptId) updateData.departmentId = deptId;
      else delete updateData.departmentId;
    }

    const item = await prisma.document.update({ where: { id }, data: updateData, include: { department: true } });
    res.json({ success: true, data: flattenDoc(item), message: "Document updated" });
  } catch (error: any) {
    console.error("Error updating document:", error);
    res.status(500).json({ success: false, message: error.message || "Failed to update document" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    await prisma.document.delete({ where: { id } });
    res.json({ success: true, message: "Document deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete document" });
  }
});

export default router;
