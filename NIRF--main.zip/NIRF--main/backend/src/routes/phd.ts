import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

router.get("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const where: any = {};
    if (departmentScope) where.departmentId = departmentScope;
    const data = await prisma.phdScholar.findMany({ where, include: { department: true }, orderBy: { createdAt: "desc" } });
    res.json({ success: true, data });
  } catch (error) {
    console.error("Error fetching PhD scholars:", error);
    res.status(500).json({ success: false, message: "Failed to fetch PhD scholars" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.phdScholar.findUnique({ where: { id }, include: { department: true } });
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch PhD scholar" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const data = { ...req.body };
    if (departmentScope && !data.departmentId) data.departmentId = departmentScope;
    const item = await prisma.phdScholar.create({ data, include: { department: true } });
    res.status(201).json({ success: true, data: item, message: "PhD scholar created" });
  } catch (error) {
    console.error("Error creating PhD scholar:", error);
    res.status(500).json({ success: false, message: "Failed to create PhD scholar" });
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.phdScholar.update({ where: { id }, data: req.body, include: { department: true } });
    res.json({ success: true, data: item, message: "PhD scholar updated" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update PhD scholar" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    await prisma.phdScholar.delete({ where: { id } });
    res.json({ success: true, message: "PhD scholar deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete PhD scholar" });
  }
});

export default router;
