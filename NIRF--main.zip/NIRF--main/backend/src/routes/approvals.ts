import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

const STATUS_FLOW: Record<string, string> = {
  pending_hod: "pending_vp",
  pending_vp: "pending_principal",
  pending_principal: "approved",
};

router.get("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const where: any = {};
    if (departmentScope) where.departmentId = departmentScope;
    const data = await prisma.monthlyReview.findMany({ where, include: { department: true }, orderBy: { createdAt: "desc" } });
    res.json({ success: true, data });
  } catch (error) {
    console.error("Error fetching approvals:", error);
    res.status(500).json({ success: false, message: "Failed to fetch approvals" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.monthlyReview.findUnique({ where: { id }, include: { department: true } });
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch approval" });
  }
});

router.put("/:id/approve", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const current = await prisma.monthlyReview.findUnique({ where: { id } });
    if (!current) return res.status(404).json({ success: false, message: "Not found" });
    const nextStatus = STATUS_FLOW[current.status];
    if (!nextStatus) return res.status(400).json({ success: false, message: `Cannot advance from status: ${current.status}` });
    const item = await prisma.monthlyReview.update({ where: { id }, data: { status: nextStatus }, include: { department: true } });
    res.json({ success: true, data: item, message: `Review advanced to ${nextStatus}` });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to approve" });
  }
});

router.put("/:id/reject", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.monthlyReview.update({ where: { id }, data: { status: "rejected" }, include: { department: true } });
    res.json({ success: true, data: item, message: "Review rejected" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to reject" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const data = { ...req.body };
    if (departmentScope && !data.departmentId) data.departmentId = departmentScope;
    const item = await prisma.monthlyReview.create({ data, include: { department: true } });
    res.status(201).json({ success: true, data: item, message: "Approval request created" });
  } catch (error) {
    console.error("Error creating approval:", error);
    res.status(500).json({ success: false, message: "Failed to create approval" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    await prisma.monthlyReview.delete({ where: { id } });
    res.json({ success: true, message: "Approval deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete approval" });
  }
});

export default router;
