import { Router, Request, Response } from "express";
import { generateToken } from "../middleware/auth";
import { Role } from "../types";

const router = Router();

const mockUsers: Record<string, { password: string; name: string; role: Role; departmentId?: string }> = {
  "admin@jjcet.edu": { password: "admin123", name: "Super Admin", role: Role.SUPER_ADMIN },
  "principal@jjcet.edu": { password: "principal123", name: "Dr. Rajesh Kumar", role: Role.PRINCIPAL },
  "vp@jjcet.edu": { password: "vp123", name: "Dr. Lakshmi Devi", role: Role.VICE_PRINCIPAL },
  "hod@jjcet.edu": { password: "hod123", name: "Vanitha Madam", role: Role.HOD, departmentId: "IT" },
  "staff@jjcet.edu": { password: "staff123", name: "Ramesh Kumar", role: Role.DEPARTMENT_STAFF, departmentId: "IT" },
};

router.post("/login", (req: Request, res: Response) => {
  const { email, password } = req.body;
  const user = mockUsers[email];
  if (!user || user.password !== password) {
    return res.status(401).json({ success: false, message: "Invalid credentials" });
  }
  const token = generateToken({ userId: email, email, role: user.role, departmentId: user.departmentId });
  res.json({ success: true, message: "Login successful", data: { token, user: { email, name: user.name, role: user.role, departmentId: user.departmentId } } });
});

router.get("/profile", (req: Request, res: Response) => {
  res.json({ success: true, message: "Profile retrieved", data: { name: "Demo User", role: "HOD" } });
});

export default router;
