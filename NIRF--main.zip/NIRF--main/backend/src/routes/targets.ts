import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

router.get("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const where: any = {};
    if (departmentScope) where.departmentId = departmentScope;
    const data = await prisma.target.findMany({ where, include: { department: true }, orderBy: { createdAt: "desc" } });
    res.json({ success: true, data });
  } catch (error) {
    console.error("Error fetching targets:", error);
    res.status(500).json({ success: false, message: "Failed to fetch targets" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.target.findUnique({ where: { id }, include: { department: true } });
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch target" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const data = { ...req.body };
    if (departmentScope && !data.departmentId) data.departmentId = departmentScope;
    const item = await prisma.target.create({ data, include: { department: true } });
    res.status(201).json({ success: true, data: item, message: "Target created" });
  } catch (error) {
    console.error("Error creating target:", error);
    res.status(500).json({ success: false, message: "Failed to create target" });
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.target.update({ where: { id }, data: req.body, include: { department: true } });
    res.json({ success: true, data: item, message: "Target updated" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update target" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    await prisma.target.delete({ where: { id } });
    res.json({ success: true, message: "Target deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete target" });
  }
});

export default router;
