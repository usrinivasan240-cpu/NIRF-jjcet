import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

router.get("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const where: any = {};
    if (departmentScope) where.departmentId = departmentScope;
    const data = await prisma.publication.findMany({ where, include: { faculty: true, department: true }, orderBy: { createdAt: "desc" } });
    res.json({ success: true, data });
  } catch (error) {
    console.error("Error fetching publications:", error);
    res.status(500).json({ success: false, message: "Failed to fetch publications" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.publication.findUnique({ where: { id }, include: { faculty: true, department: true } });
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch publication" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const data = { ...req.body };
    if (departmentScope && !data.departmentId) data.departmentId = departmentScope;
    const item = await prisma.publication.create({ data, include: { faculty: true, department: true } });
    res.status(201).json({ success: true, data: item, message: "Publication created" });
  } catch (error) {
    console.error("Error creating publication:", error);
    res.status(500).json({ success: false, message: "Failed to create publication" });
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.publication.update({ where: { id }, data: req.body, include: { faculty: true, department: true } });
    res.json({ success: true, data: item, message: "Publication updated" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update publication" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    await prisma.publication.delete({ where: { id } });
    res.json({ success: true, message: "Publication deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete publication" });
  }
});

export default router;
