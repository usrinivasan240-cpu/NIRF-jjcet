import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

router.get("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const where: any = {};
    if (departmentScope) where.departmentId = departmentScope;
    const data = await prisma.faculty.findMany({ where, include: { department: true }, orderBy: { createdAt: "desc" } });
    res.json({ success: true, data });
  } catch (error) {
    console.error("Error fetching faculty:", error);
    res.status(500).json({ success: false, message: "Failed to fetch faculty" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.faculty.findUnique({ where: { id }, include: { department: true, publications: true, patents: true } });
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch faculty" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const data = { ...req.body };
    if (departmentScope && !data.departmentId) data.departmentId = departmentScope;
    const item = await prisma.faculty.create({ data, include: { department: true } });
    res.status(201).json({ success: true, data: item, message: "Faculty created" });
  } catch (error) {
    console.error("Error creating faculty:", error);
    res.status(500).json({ success: false, message: "Failed to create faculty" });
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.faculty.update({ where: { id }, data: req.body, include: { department: true } });
    res.json({ success: true, data: item, message: "Faculty updated" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update faculty" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    await prisma.faculty.delete({ where: { id } });
    res.json({ success: true, message: "Faculty deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete faculty" });
  }
});

export default router;
