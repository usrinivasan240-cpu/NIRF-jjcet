import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

router.get("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const deptFilter: any = departmentScope ? { departmentId: departmentScope } : {};

    const [pubs, patents, research, events] = await Promise.all([
      prisma.publication.findMany({ where: deptFilter, include: { department: true, faculty: true } }),
      prisma.patent.findMany({ where: deptFilter, include: { department: true, faculty: true } }),
      prisma.research.findMany({ where: deptFilter, include: { department: true } }),
      prisma.event.findMany({ where: deptFilter, include: { department: true } }),
    ]);

    const report = {
      generatedAt: new Date().toISOString(),
      summary: {
        totalPublications: pubs.length,
        sciPublications: pubs.filter((p) => p.isSCI).length,
        scopusPublications: pubs.filter((p) => p.isScopus).length,
        totalPatents: patents.length,
        grantedPatents: patents.filter((p) => p.isGranted).length,
        totalResearch: research.length,
        totalEvents: events.length,
      },
      publications: pubs,
      patents,
      research,
      events,
    };

    res.json({ success: true, data: report });
  } catch (error) {
    console.error("Error generating report:", error);
    res.status(500).json({ success: false, message: "Failed to generate report" });
  }
});

router.get("/publications", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const where: any = {};
    if (departmentScope) where.departmentId = departmentScope;
    const data = await prisma.publication.findMany({ where, include: { faculty: true, department: true } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to generate publications report" });
  }
});

router.get("/patents", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const where: any = {};
    if (departmentScope) where.departmentId = departmentScope;
    const data = await prisma.patent.findMany({ where, include: { faculty: true, department: true } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to generate patents report" });
  }
});

router.get("/faculty", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const where: any = {};
    if (departmentScope) where.departmentId = departmentScope;
    const data = await prisma.faculty.findMany({ where, include: { department: true, publications: true, patents: true } });
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to generate faculty report" });
  }
});

export default router;
