import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

router.get("/", async (_req: Request, res: Response) => {
  try {
    const data = await prisma.notification.findMany({ orderBy: { createdAt: "desc" } });
    res.json({ success: true, data });
  } catch (error) {
    console.error("Error fetching notifications:", error);
    res.status(500).json({ success: false, message: "Failed to fetch notifications" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.notification.findUnique({ where: { id } });
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch notification" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const item = await prisma.notification.create({ data: req.body });
    res.status(201).json({ success: true, data: item, message: "Notification created" });
  } catch (error) {
    console.error("Error creating notification:", error);
    res.status(500).json({ success: false, message: "Failed to create notification" });
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.notification.update({ where: { id }, data: req.body });
    res.json({ success: true, data: item, message: "Notification updated" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update notification" });
  }
});

router.put("/:id/read", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.notification.update({ where: { id }, data: { isRead: true } });
    res.json({ success: true, data: item, message: "Notification marked as read" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to mark notification as read" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    await prisma.notification.delete({ where: { id } });
    res.json({ success: true, message: "Notification deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete notification" });
  }
});

export default router;
