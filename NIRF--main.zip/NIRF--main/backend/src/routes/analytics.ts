import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

router.get("/", async (req: Request, res: Response) => {
  try {
    const departmentScope = (req as any).departmentScope as string | null;
    const deptFilter: any = departmentScope ? { departmentId: departmentScope } : {};

    const [totalPublications, totalPatents, totalFaculty, totalStudents, totalEvents, totalResearch, totalPhdScholars] = await Promise.all([
      prisma.publication.count({ where: deptFilter }),
      prisma.patent.count({ where: deptFilter }),
      prisma.faculty.count({ where: deptFilter }),
      prisma.student.count({ where: deptFilter }),
      prisma.event.count({ where: deptFilter }),
      prisma.research.count({ where: deptFilter }),
      prisma.phdScholar.count({ where: deptFilter }),
    ]);

    const sciCount = await prisma.publication.count({ where: { ...deptFilter, isSCI: true } });
    const scopusCount = await prisma.publication.count({ where: { ...deptFilter, isScopus: true } });
    const grantedPatents = await prisma.patent.count({ where: { ...deptFilter, isGranted: true } });

    const departments = await prisma.department.findMany({
      select: {
        id: true,
        name: true,
        code: true,
        _count: { select: { publications: true, patents: true, faculties: true, students: true, events: true } },
      },
    });

    const recentPublications = await prisma.publication.findMany({ where: deptFilter, include: { faculty: true }, orderBy: { createdAt: "desc" }, take: 5 });
    const recentPatents = await prisma.patent.findMany({ where: deptFilter, include: { faculty: true }, orderBy: { createdAt: "desc" }, take: 5 });

    res.json({
      success: true,
      data: {
        overview: {
          totalPublications,
          totalPatents,
          totalFaculty,
          totalStudents,
          totalEvents,
          totalResearch,
          totalPhdScholars,
          sciCount,
          scopusCount,
          grantedPatents,
        },
        departmentBreakdown: departments,
        recentPublications,
        recentPatents,
      },
    });
  } catch (error) {
    console.error("Error fetching analytics:", error);
    res.status(500).json({ success: false, message: "Failed to fetch analytics" });
  }
});

router.get("/department/:departmentId", async (req: Request, res: Response) => {
  try {
    const departmentId = req.params.departmentId as string;
    const dept = await prisma.department.findUnique({ where: { id: departmentId } });
    if (!dept) return res.status(404).json({ success: false, message: "Department not found" });

    const [publications, patents, faculty, students, events, research, phdScholars] = await Promise.all([
      prisma.publication.count({ where: { departmentId } }),
      prisma.patent.count({ where: { departmentId } }),
      prisma.faculty.count({ where: { departmentId } }),
      prisma.student.count({ where: { departmentId } }),
      prisma.event.count({ where: { departmentId } }),
      prisma.research.count({ where: { departmentId } }),
      prisma.phdScholar.count({ where: { departmentId } }),
    ]);

    res.json({
      success: true,
      data: { department: dept, publications, patents, faculty, students, events, research, phdScholars },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch department analytics" });
  }
});

export default router;
