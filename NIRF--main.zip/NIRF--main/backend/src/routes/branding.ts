import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";
import { authorize } from "../middleware/auth";
import { Role } from "../types";
import multer from "multer";
import path from "path";
import fs from "fs";

const router = Router();
const prisma = new PrismaClient();

const uploadsDir = path.join(process.cwd(), "uploads", "branding");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `branding-${Date.now()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp|svg/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype);
    if (ext && mime) cb(null, true);
    else cb(new Error("Only image files are allowed"));
  },
});

router.get("/active", async (_req, res) => {
  try {
    let branding = await prisma.collegeBranding.findFirst({ where: { isActive: true } });
    if (!branding) {
      branding = await prisma.collegeBranding.create({
        data: {
          collegeName: "JJ College of Engineering & Technology",
          shortName: "JJCET",
        },
      });
    }
    res.json({ success: true, data: branding });
  } catch (error) {
    console.error("Error fetching branding:", error);
    res.status(500).json({ success: false, message: "Failed to fetch branding" });
  }
});

router.get("/active-with-images", async (_req, res) => {
  try {
    let branding = await prisma.collegeBranding.findFirst({ where: { isActive: true } });
    if (!branding) {
      branding = await prisma.collegeBranding.create({
        data: {
          collegeName: "JJ College of Engineering & Technology",
          shortName: "JJCET",
        },
      });
    }

    const result: any = { ...branding };

    if (branding.logo) {
      const logoPath = path.join(process.cwd(), branding.logo);
      if (fs.existsSync(logoPath)) {
        const ext = path.extname(branding.logo).toLowerCase();
        const mime = ext === ".png" ? "image/png" : ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : ext === ".svg" ? "image/svg+xml" : "image/png";
        const data = fs.readFileSync(logoPath);
        result.logoBase64 = `data:${mime};base64,${data.toString("base64")}`;
      }
    }

    if (branding.headerBanner) {
      const bannerPath = path.join(process.cwd(), branding.headerBanner);
      if (fs.existsSync(bannerPath)) {
        const ext = path.extname(branding.headerBanner).toLowerCase();
        const mime = ext === ".png" ? "image/png" : ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : ext === ".svg" ? "image/svg+xml" : "image/png";
        const data = fs.readFileSync(bannerPath);
        result.bannerBase64 = `data:${mime};base64,${data.toString("base64")}`;
      }
    }

    res.json({ success: true, data: result });
  } catch (error) {
    console.error("Error fetching branding with images:", error);
    res.status(500).json({ success: false, message: "Failed to fetch branding" });
  }
});

router.get("/", authorize(Role.SUPER_ADMIN), async (_req, res) => {
  try {
    const brandings = await prisma.collegeBranding.findMany({ orderBy: { updatedAt: "desc" } });
    res.json({ success: true, data: brandings });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch branding records" });
  }
});

router.get("/:id", authorize(Role.SUPER_ADMIN), async (req, res) => {
  try {
    const id = req.params.id as string;
    const branding = await prisma.collegeBranding.findUnique({ where: { id } });
    if (!branding) return res.status(404).json({ success: false, message: "Branding not found" });
    res.json({ success: true, data: branding });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch branding" });
  }
});

router.post("/", authorize(Role.SUPER_ADMIN), async (req, res) => {
  try {
    const branding = await prisma.collegeBranding.create({ data: req.body });
    res.status(201).json({ success: true, data: branding, message: "Branding created" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to create branding" });
  }
});

router.put("/:id", authorize(Role.SUPER_ADMIN), async (req, res) => {
  try {
    const id = req.params.id as string;
    const branding = await prisma.collegeBranding.update({ where: { id }, data: req.body });
    res.json({ success: true, data: branding, message: "Branding updated" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update branding" });
  }
});

router.post("/:id/logo", authorize(Role.SUPER_ADMIN), upload.single("logo"), async (req, res) => {
  try {
    const id = req.params.id as string;
    if (!req.file) return res.status(400).json({ success: false, message: "No file uploaded" });
    const logoUrl = `/uploads/branding/${req.file.filename}`;
    const branding = await prisma.collegeBranding.update({ where: { id }, data: { logo: logoUrl } });
    res.json({ success: true, data: branding, message: "Logo uploaded successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to upload logo" });
  }
});

router.post("/:id/banner", authorize(Role.SUPER_ADMIN), upload.single("banner"), async (req, res) => {
  try {
    const id = req.params.id as string;
    if (!req.file) return res.status(400).json({ success: false, message: "No file uploaded" });
    const bannerUrl = `/uploads/branding/${req.file.filename}`;
    const branding = await prisma.collegeBranding.update({ where: { id }, data: { headerBanner: bannerUrl } });
    res.json({ success: true, data: branding, message: "Banner uploaded successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to upload banner" });
  }
});

router.delete("/:id", authorize(Role.SUPER_ADMIN), async (req, res) => {
  try {
    const id = req.params.id as string;
    await prisma.collegeBranding.update({ where: { id }, data: { isActive: false } });
    res.json({ success: true, message: "Branding deactivated" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to deactivate branding" });
  }
});

export default router;
