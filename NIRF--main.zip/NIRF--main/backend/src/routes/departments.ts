import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";

const router = Router();
const prisma = new PrismaClient();

router.get("/", async (_req: Request, res: Response) => {
  try {
    const data = await prisma.department.findMany({ orderBy: { name: "asc" } });
    res.json({ success: true, data });
  } catch (error) {
    console.error("Error fetching departments:", error);
    res.status(500).json({ success: false, message: "Failed to fetch departments" });
  }
});

router.get("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.department.findUnique({ where: { id } });
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch department" });
  }
});

router.post("/", async (req: Request, res: Response) => {
  try {
    const item = await prisma.department.create({ data: req.body });
    res.status(201).json({ success: true, data: item, message: "Department created" });
  } catch (error) {
    console.error("Error creating department:", error);
    res.status(500).json({ success: false, message: "Failed to create department" });
  }
});

router.put("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    const item = await prisma.department.update({ where: { id }, data: req.body });
    res.json({ success: true, data: item, message: "Department updated" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update department" });
  }
});

router.delete("/:id", async (req: Request, res: Response) => {
  try {
    const id = req.params.id as string;
    await prisma.department.delete({ where: { id } });
    res.json({ success: true, message: "Department deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to delete department" });
  }
});

export default router;
