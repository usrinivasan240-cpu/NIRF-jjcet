import { Router, Request, Response } from "express";

const router = Router();

const defaultConfig = {
  collegeName: "JJ College of Engineering & Technology",
  shortName: "JJCET",
  academicYear: "2025-2026",
  nirfCategory: "Engineering",
  maxUploadSize: "10MB",
  allowedFileTypes: ["pdf", "doc", "docx", "jpg", "jpeg", "png"],
  features: {
    aiInsights: true,
    autoSave: true,
    emailNotifications: true,
    darkMode: true,
  },
};

router.get("/", (_req: Request, res: Response) => {
  try {
    res.json({ success: true, data: defaultConfig });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch settings" });
  }
});

router.put("/", (req: Request, res: Response) => {
  try {
    const updated = { ...defaultConfig, ...req.body };
    res.json({ success: true, data: updated, message: "Settings updated" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to update settings" });
  }
});

export default router;
