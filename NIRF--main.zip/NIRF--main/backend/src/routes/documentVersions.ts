import { Router, Request, Response } from "express";
import { PrismaClient } from "@prisma/client";
import crypto from "crypto";

const router = Router();
const prisma = new PrismaClient();

function computeHash(data: string): string {
  return crypto.createHash("sha256").update(data).digest("hex");
}

router.get("/:documentId/versions", async (req: Request, res: Response) => {
  try {
    const documentId = req.params.documentId as string;
    const versions = await prisma.documentVersion.findMany({
      where: { documentId },
      orderBy: { versionNumber: "asc" },
    });
    res.json({ success: true, data: versions });
  } catch (error) {
    console.error("Error fetching versions:", error);
    res.status(500).json({ success: false, message: "Failed to fetch versions" });
  }
});

router.get("/:documentId/versions/:versionNumber", async (req: Request, res: Response) => {
  try {
    const documentId = req.params.documentId as string;
    const versionNumber = parseInt(req.params.versionNumber as string, 10);
    const version = await prisma.documentVersion.findFirst({
      where: { documentId, versionNumber },
    });
    if (!version) return res.status(404).json({ success: false, message: "Version not found" });
    res.json({ success: true, data: version });
  } catch (error) {
    res.status(500).json({ success: false, message: "Failed to fetch version" });
  }
});

router.post("/:documentId/versions", async (req: Request, res: Response) => {
  try {
    const documentId = req.params.documentId as string;
    const { fileData, fileName, fileSize, fileType, uploadedBy, uploadedByRole, comment, action } = req.body;

    const doc = await prisma.document.findUnique({ where: { id: documentId } });
    if (!doc) return res.status(404).json({ success: false, message: "Document not found" });
    if (doc.locked) return res.status(400).json({ success: false, message: "Document is locked" });

    const versionNumber = doc.currentVersion + 1;
    const sha256Hash = fileData ? computeHash(fileData.substring(0, 1000)) : null;

    const version = await prisma.documentVersion.create({
      data: {
        documentId,
        versionNumber,
        fileData,
        fileName: fileName || doc.name,
        fileSize: fileSize || doc.size,
        fileType: fileType || doc.type,
        uploadedBy: uploadedBy || doc.uploadedBy,
        uploadedByRole: uploadedByRole || "",
        comment: comment || null,
        action: action || "upload",
        sha256Hash,
      },
    });

    await prisma.document.update({
      where: { id: documentId },
      data: {
        currentVersion: versionNumber,
        versionCount: versionNumber,
        fileData,
        name: fileName || doc.name,
        size: fileSize || doc.size,
      },
    });

    await prisma.auditLog.create({
      data: {
        userId: uploadedBy || "system",
        action: `version_${action}`,
        entity: "Document",
        entityId: documentId,
        details: JSON.stringify({ versionNumber, fileName, action, uploadedByRole }),
      },
    });

    res.status(201).json({ success: true, data: version, message: `Version ${versionNumber} uploaded` });
  } catch (error: any) {
    console.error("Error creating version:", error);
    res.status(500).json({ success: false, message: error.message || "Failed to create version" });
  }
});

export default router;
