import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import path from "path";
import { config } from "./config";
import { errorHandler, notFound } from "./middleware/errorHandler";
import { authenticate, enforceDepartmentScope } from "./middleware/auth";

import authRoutes from "./routes/auth";
import departmentRoutes from "./routes/departments";
import facultyRoutes from "./routes/faculty";
import publicationRoutes from "./routes/publications";
import patentRoutes from "./routes/patents";
import researchRoutes from "./routes/research";
import studentRoutes from "./routes/students";
import eventRoutes from "./routes/events";
import reviewRoutes from "./routes/reviews";
import targetRoutes from "./routes/targets";
import approvalRoutes from "./routes/approvals";
import documentRoutes from "./routes/documents";
import reportRoutes from "./routes/reports";
import analyticsRoutes from "./routes/analytics";
import notificationRoutes from "./routes/notifications";
import settingsRoutes from "./routes/settings";
import auditRoutes from "./routes/audit";
import aiRoutes from "./routes/ai";
import userRoutes from "./routes/users";
import phdRoutes from "./routes/phd";
import brandingRoutes from "./routes/branding";
import documentVersionRoutes from "./routes/documentVersions";

const app = express();

app.use(helmet());
app.use(cors({ origin: config.cors.origin, credentials: true }));
app.use(morgan("dev"));
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

// Serve uploaded files
app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

app.get("/api/health", (req, res) => { res.json({ status: "ok", timestamp: new Date().toISOString() }); });

// Branding — public /active route, rest requires auth
app.use("/api/branding", brandingRoutes);

app.use("/api/auth", authRoutes);
app.use("/api/departments", authenticate, enforceDepartmentScope, departmentRoutes);
app.use("/api/faculty", authenticate, enforceDepartmentScope, facultyRoutes);
app.use("/api/publications", authenticate, enforceDepartmentScope, publicationRoutes);
app.use("/api/patents", authenticate, enforceDepartmentScope, patentRoutes);
app.use("/api/research", authenticate, enforceDepartmentScope, researchRoutes);
app.use("/api/phd", authenticate, enforceDepartmentScope, phdRoutes);
app.use("/api/students", authenticate, enforceDepartmentScope, studentRoutes);
app.use("/api/events", authenticate, enforceDepartmentScope, eventRoutes);
app.use("/api/reviews", authenticate, enforceDepartmentScope, reviewRoutes);
app.use("/api/targets", authenticate, enforceDepartmentScope, targetRoutes);
app.use("/api/approvals", authenticate, enforceDepartmentScope, approvalRoutes);
app.use("/api/documents", authenticate, enforceDepartmentScope, documentRoutes);
app.use("/api/document-versions", authenticate, documentVersionRoutes);
app.use("/api/reports", authenticate, enforceDepartmentScope, reportRoutes);
app.use("/api/analytics", authenticate, enforceDepartmentScope, analyticsRoutes);
app.use("/api/notifications", authenticate, enforceDepartmentScope, notificationRoutes);
app.use("/api/settings", authenticate, enforceDepartmentScope, settingsRoutes);
app.use("/api/audit", authenticate, enforceDepartmentScope, auditRoutes);
app.use("/api/ai", authenticate, enforceDepartmentScope, aiRoutes);
app.use("/api/users", authenticate, enforceDepartmentScope, userRoutes);

app.use(notFound);
app.use(errorHandler);

app.listen(config.port, () => {
  console.log(`NIRF ERP Pro API running on port ${config.port}`);
  console.log(`Environment: ${config.nodeEnv}`);
});

export default app;
