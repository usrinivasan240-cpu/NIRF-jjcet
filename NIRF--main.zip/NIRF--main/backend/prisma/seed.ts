import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding database...");

  await prisma.auditLog.deleteMany();
  await prisma.notification.deleteMany();
  await prisma.document.deleteMany();
  await prisma.monthlyReview.deleteMany();
  await prisma.target.deleteMany();
  await prisma.student.deleteMany();
  await prisma.phdScholar.deleteMany();
  await prisma.research.deleteMany();
  await prisma.patent.deleteMany();
  await prisma.publication.deleteMany();
  await prisma.event.deleteMany();
  await prisma.faculty.deleteMany();
  await prisma.user.deleteMany();
  await prisma.department.deleteMany();

  const deptIT = await prisma.department.create({ data: { name: "Information Technology", code: "IT", description: "Department of Information Technology" } });
  const deptCSE = await prisma.department.create({ data: { name: "Computer Science & Engineering", code: "CSE", description: "Department of Computer Science & Engineering" } });
  const deptECE = await prisma.department.create({ data: { name: "Electronics & Communication Engineering", code: "ECE", description: "Department of Electronics & Communication Engineering" } });

  console.log("Departments created.");

  const hashedAdminPass = await bcrypt.hash("admin123", 10);
  const hashedStaffPass = await bcrypt.hash("staff123", 10);

  const admin = await prisma.user.create({ data: { email: "admin@jjcet.edu", password: hashedAdminPass, name: "Super Admin", role: "SUPER_ADMIN", isActive: true } });
  const principal = await prisma.user.create({ data: { email: "principal@jjcet.edu", password: hashedStaffPass, name: "Dr. Rajesh Kumar", role: "PRINCIPAL", isActive: true } });
  const vp = await prisma.user.create({ data: { email: "vp@jjcet.edu", password: hashedStaffPass, name: "Dr. Lakshmi Devi", role: "VICE_PRINCIPAL", isActive: true } });
  const hodIT = await prisma.user.create({ data: { email: "hod.it@jjcet.edu", password: hashedStaffPass, name: "Vanitha K", role: "HOD", departmentId: deptIT.id, isActive: true } });
  const hodCSE = await prisma.user.create({ data: { email: "hod.cse@jjcet.edu", password: hashedStaffPass, name: "Murugan S", role: "HOD", departmentId: deptCSE.id, isActive: true } });
  const staffIT = await prisma.user.create({ data: { email: "staff.it@jjcet.edu", password: hashedStaffPass, name: "Ramesh Kumar", role: "DEPARTMENT_STAFF", departmentId: deptIT.id, isActive: true } });

  console.log("Users created.");

  const f1 = await prisma.faculty.create({ data: { name: "Dr. Anitha R", email: "anitha@jjcet.edu", designation: "Professor", departmentId: deptIT.id, qualification: "Ph.D", experience: 15, googleScholarId: "abc123", scopusId: "scopus1" } });
  const f2 = await prisma.faculty.create({ data: { name: "Dr. Bharathi M", email: "bharathi@jjcet.edu", designation: "Associate Professor", departmentId: deptIT.id, qualification: "Ph.D", experience: 10, orcidId: "orcid1" } });
  const f3 = await prisma.faculty.create({ data: { name: "Dr. Karthik P", email: "karthik@jjcet.edu", designation: "Professor", departmentId: deptCSE.id, qualification: "Ph.D", experience: 18, googleScholarId: "def456" } });
  const f4 = await prisma.faculty.create({ data: { name: "Dr. Deepa S", email: "deepa@jjcet.edu", designation: "Assistant Professor", departmentId: deptECE.id, qualification: "Ph.D", experience: 7 } });

  console.log("Faculty created.");

  await prisma.publication.create({ data: { title: "Machine Learning in Healthcare", authors: "Anitha R, Bharathi M", facultyId: f1.id, departmentId: deptIT.id, journal: "IEEE Transactions", publisher: "IEEE", quartile: "Q1", isSCI: true, isSCIE: true, isScopus: true, isUGC: true, issn: "1234-5678", doi: "10.1234/example", publicationDate: "2025-06-15", citationCount: 25, status: "published" } });
  await prisma.publication.create({ data: { title: "IoT-based Smart Agriculture", authors: "Bharathi M, Karthik P", facultyId: f2.id, departmentId: deptIT.id, journal: "Elsevier", publisher: "Elsevier", quartile: "Q2", isSCI: false, isSCIE: true, isScopus: true, isUGC: true, publicationDate: "2025-03-20", citationCount: 12, status: "published" } });
  await prisma.publication.create({ data: { title: "Deep Learning for NLP", authors: "Karthik P", facultyId: f3.id, departmentId: deptCSE.id, journal: "Springer", publisher: "Springer", quartile: "Q1", isSCI: true, isScopus: true, citationCount: 30, status: "published" } });
  await prisma.publication.create({ data: { title: "VLSI Design Optimization", authors: "Deepa S", facultyId: f4.id, departmentId: deptECE.id, journal: "Wiley", quartile: "Q3", isScopus: true, citationCount: 5, status: "published" } });

  console.log("Publications created.");

  await prisma.patent.create({ data: { title: "Smart Water Purification System", patentNumber: "IN202511001", facultyId: f1.id, departmentId: deptIT.id, country: "India", isPublished: true, isGranted: true, filedDate: "2024-01-15", grantedDate: "2025-06-01", status: "granted" } });
  await prisma.patent.create({ data: { title: "AI-based Crop Monitor", facultyId: f3.id, departmentId: deptCSE.id, country: "India", isPublished: false, isGranted: false, filedDate: "2025-03-10", status: "filed" } });
  await prisma.patent.create({ data: { title: "Low Power RF Transceiver", patentNumber: "IN202511003", facultyId: f4.id, departmentId: deptECE.id, country: "India", isPublished: true, isGranted: true, filedDate: "2023-06-20", grantedDate: "2025-02-15", status: "granted" } });

  console.log("Patents created.");

  await prisma.event.create({ data: { title: "National Conference on AI", type: "conference", date: "2025-09-15", participants: 200, status: "completed", departmentId: deptIT.id } });
  await prisma.event.create({ data: { title: "Workshop on Cloud Computing", type: "workshop", date: "2025-11-20", participants: 80, status: "upcoming", departmentId: deptCSE.id } });
  await prisma.event.create({ data: { title: "Tech Fest Innovision", type: "fest", date: "2025-12-05", participants: 500, status: "upcoming", departmentId: deptIT.id } });

  console.log("Events created.");

  await prisma.research.create({ data: { title: "AI for Sustainable Farming", pi: "Dr. Anitha R", fundingAgency: "DST", amount: "2500000", departmentId: deptIT.id, status: "ongoing", startDate: "2024-04-01" } });
  await prisma.research.create({ data: { title: "5G Network Optimization", pi: "Dr. Karthik P", fundingAgency: "AICTE", amount: "1800000", departmentId: deptCSE.id, status: "ongoing", startDate: "2025-01-15" } });
  await prisma.research.create({ data: { title: "IoT Sensor Networks", pi: "Dr. Deepa S", fundingAgency: "UGC", amount: "1200000", departmentId: deptECE.id, status: "completed", startDate: "2023-06-01", endDate: "2025-05-30" } });

  console.log("Research projects created.");

  await prisma.phdScholar.create({ data: { name: "Ravi Kumar", topic: "ML in Medical Imaging", supervisor: "Dr. Anitha R", departmentId: deptIT.id, status: "pursuing", enrollmentYear: 2022 } });
  await prisma.phdScholar.create({ data: { name: "Priya S", topic: "Cloud Security", supervisor: "Dr. Bharathi M", departmentId: deptIT.id, status: "pursuing", enrollmentYear: 2023 } });
  await prisma.phdScholar.create({ data: { name: "Arjun V", topic: "NLP Applications", supervisor: "Dr. Karthik P", departmentId: deptCSE.id, status: "completed", enrollmentYear: 2020, completionYear: 2025 } });

  console.log("PhD scholars created.");

  await prisma.student.create({ data: { name: "Arun P", category: "B.Tech", title: "Final Year Project", year: 2025, departmentId: deptIT.id } });
  await prisma.student.create({ data: { name: "Kavitha R", category: "M.Tech", title: "Thesis - Deep Learning", year: 2025, departmentId: deptIT.id } });
  await prisma.student.create({ data: { name: "Mohan S", category: "B.Tech", title: "Mini Project", year: 2026, departmentId: deptCSE.id } });
  await prisma.student.create({ data: { name: "Lakshmi N", category: "B.Tech", title: "Final Year Project", year: 2025, departmentId: deptECE.id } });

  console.log("Students created.");

  await prisma.target.create({ data: { category: "Publications", yearly: 20, achieved: 12, departmentId: deptIT.id, year: 2025 } });
  await prisma.target.create({ data: { category: "Patents", yearly: 5, achieved: 2, departmentId: deptIT.id, year: 2025 } });
  await prisma.target.create({ data: { category: "Publications", yearly: 25, achieved: 15, departmentId: deptCSE.id, year: 2025 } });
  await prisma.target.create({ data: { category: "Events", yearly: 10, achieved: 6, departmentId: deptECE.id, year: 2025 } });

  console.log("Targets created.");

  await prisma.monthlyReview.create({ data: { month: "2025-06", departmentId: deptIT.id, submittedBy: hodIT.email, submittedAt: "2025-06-25", status: "pending_vp", publications: 3, patents: 1, events: 2, students: 5 } });
  await prisma.monthlyReview.create({ data: { month: "2025-05", departmentId: deptCSE.id, submittedBy: hodCSE.email, submittedAt: "2025-05-28", status: "approved", publications: 4, patents: 0, events: 1, students: 8 } });

  console.log("Reviews created.");

  await prisma.document.create({ data: { name: "NIRF Report 2025.pdf", type: "pdf", size: "2.5MB", uploadedBy: admin.email, uploadedAt: "2025-06-20", departmentId: deptIT.id } });
  await prisma.document.create({ data: { name: "Faculty List.xlsx", type: "xlsx", size: "150KB", uploadedBy: hodIT.email, uploadedAt: "2025-06-22", departmentId: deptIT.id } });

  console.log("Documents created.");

  await prisma.notification.create({ data: { title: "Welcome to NIRF ERP", message: "Your account has been created successfully.", type: "info", isRead: false } });
  await prisma.notification.create({ data: { title: "Monthly Review Pending", message: "Please submit the monthly review for June 2025.", type: "warning", isRead: false } });
  await prisma.notification.create({ data: { title: "New Publication Added", message: "A new publication has been added to your department.", type: "success", isRead: true } });

  console.log("Notifications created.");
  console.log("Seeding completed successfully!");
}

main()
  .catch((e) => {
    console.error("Seeding failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
