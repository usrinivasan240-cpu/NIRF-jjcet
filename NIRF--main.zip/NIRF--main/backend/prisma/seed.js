const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcryptjs");
const prisma = new PrismaClient();

async function main() {
  // Departments
  const it = await prisma.department.create({ data: { name: "Information Technology", code: "IT", description: "IT Department" } });
  const cse = await prisma.department.create({ data: { name: "Computer Science & Engineering", code: "CSE", description: "CSE Department" } });
  const ece = await prisma.department.create({ data: { name: "Electronics & Communication", code: "ECE", description: "ECE Department" } });
  const me = await prisma.department.create({ data: { name: "Mechanical Engineering", code: "ME", description: "ME Department" } });
  const ce = await prisma.department.create({ data: { name: "Civil Engineering", code: "CE", description: "CE Department" } });
  const eee = await prisma.department.create({ data: { name: "Electrical & Electronics", code: "EEE", description: "EEE Department" } });

  // Users
  const hash = await bcrypt.hash("admin123", 10);
  await prisma.user.create({ data: { email: "admin@jjcet.edu", password: hash, name: "Super Admin", role: "SUPER_ADMIN" } });
  await prisma.user.create({ data: { email: "principal@jjcet.edu", password: hash, name: "Dr. Rajesh Kumar", role: "PRINCIPAL" } });
  await prisma.user.create({ data: { email: "vp@jjcet.edu", password: hash, name: "Dr. Lakshmi Devi", role: "VICE_PRINCIPAL" } });
  await prisma.user.create({ data: { email: "hod@jjcet.edu", password: hash, name: "Vanitha Madam", role: "HOD", departmentId: it.id } });
  await prisma.user.create({ data: { email: "staff@jjcet.edu", password: hash, name: "Ramesh Kumar", role: "DEPARTMENT_STAFF", departmentId: it.id } });

  // Faculty - IT
  const f1 = await prisma.faculty.create({ data: { name: "Dr. Meena Devi", email: "meena@jjcet.edu", designation: "Professor", departmentId: it.id, qualification: "Ph.D", experience: 15 } });
  const f2 = await prisma.faculty.create({ data: { name: "Dr. Suresh Babu", email: "suresh@jjcet.edu", designation: "Associate Professor", departmentId: it.id, qualification: "Ph.D", experience: 10 } });
  const f3 = await prisma.faculty.create({ data: { name: "Dr. Anitha Reddy", email: "anitha@jjcet.edu", designation: "Assistant Professor", departmentId: it.id, qualification: "M.Tech", experience: 3 } });
  // Faculty - CSE
  await prisma.faculty.create({ data: { name: "Dr. Priya Sharma", email: "priya@jjcet.edu", designation: "Professor", departmentId: cse.id, qualification: "Ph.D", experience: 12 } });
  // Faculty - ECE
  await prisma.faculty.create({ data: { name: "Prof. Ramesh Kumar", email: "ramesh_ece@jjcet.edu", designation: "Professor", departmentId: ece.id, qualification: "Ph.D", experience: 20 } });

  // Publications - IT
  await prisma.publication.create({ data: { title: "AI-Based Traffic Management", authors: "Dr. Meena, Dr. Suresh", facultyId: f1.id, departmentId: it.id, journal: "IEEE Trans", quartile: "Q1", isSCI: true, isScopus: true, citationCount: 45, status: "published" } });
  await prisma.publication.create({ data: { title: "IoT Energy Monitoring", authors: "Dr. Suresh", facultyId: f2.id, departmentId: it.id, journal: "Elsevier Energy", quartile: "Q2", isScopus: true, citationCount: 18, status: "published" } });
  await prisma.publication.create({ data: { title: "ML for Healthcare", authors: "Dr. Anitha", facultyId: f3.id, departmentId: it.id, journal: "Springer Nature", quartile: "Q2", isScopus: true, citationCount: 12, status: "under_review" } });
  await prisma.publication.create({ data: { title: "Blockchain Security", authors: "Dr. Meena, Dr. Anitha", facultyId: f1.id, departmentId: it.id, journal: "IEEE Access", quartile: "Q1", isSCI: true, isScopus: true, citationCount: 28, status: "published" } });
  // Publications - CSE
  await prisma.publication.create({ data: { title: "Smart Grid Optimization", authors: "Dr. Priya", departmentId: cse.id, journal: "ACM Computing Surveys", quartile: "Q1", isSCI: true, isScopus: true, citationCount: 32, status: "published" } });
  // Publications - ECE
  await prisma.publication.create({ data: { title: "Wireless Sensor Networks", authors: "Prof. Ramesh", departmentId: ece.id, journal: "IEEE Communications", quartile: "Q2", isScopus: true, citationCount: 15, status: "published" } });

  // Patents - IT
  await prisma.patent.create({ data: { title: "Smart Irrigation System", patentNumber: "IN202411001", facultyId: f1.id, departmentId: it.id, country: "India", isPublished: true, isGranted: true, filedDate: "2023-06-15", grantedDate: "2024-03-20", status: "granted" } });
  await prisma.patent.create({ data: { title: "IoT Air Quality Monitor", facultyId: f2.id, departmentId: it.id, country: "India", isPublished: true, filedDate: "2023-09-10", status: "published" } });
  // Patents - CSE
  await prisma.patent.create({ data: { title: "AI Fraud Detection", patentNumber: "IN202411045", departmentId: cse.id, country: "India", isPublished: true, isGranted: true, filedDate: "2023-03-05", grantedDate: "2024-06-12", status: "granted" } });

  // Research - IT
  await prisma.research.create({ data: { title: "AI-Based Traffic Management", pi: "Dr. Meena", fundingAgency: "DST", amount: "1200000", departmentId: it.id, status: "ongoing", startDate: "2023-06-01" } });
  await prisma.research.create({ data: { title: "Smart Grid Optimization", pi: "Dr. Suresh", fundingAgency: "AICTE", amount: "800000", departmentId: it.id, status: "completed", startDate: "2022-01-15" } });

  // PhD - IT
  await prisma.phdScholar.create({ data: { name: "Arun Kumar", topic: "AI in Healthcare", supervisor: "Dr. Meena", departmentId: it.id, status: "pursuing", enrollmentYear: 2021 } });
  await prisma.phdScholar.create({ data: { name: "Sneha Reddy", topic: "IoT Security", supervisor: "Dr. Suresh", departmentId: it.id, status: "completed", enrollmentYear: 2019, completionYear: 2024 } });

  // Students - IT
  await prisma.student.create({ data: { name: "Arun Kumar", category: "Hackathon", title: "Smart India Hackathon Winner", year: 2024, departmentId: it.id } });
  await prisma.student.create({ data: { name: "Sneha Reddy", category: "Placement", title: "Placed at TCS", year: 2024, departmentId: it.id } });
  await prisma.student.create({ data: { name: "Priya Nair", category: "Higher Studies", title: "MS at Stanford University", year: 2024, departmentId: it.id } });

  // Events - IT
  await prisma.event.create({ data: { title: "Workshop on AI/ML", type: "Workshop", date: "2024-01-15", participants: 60, status: "completed", departmentId: it.id } });
  await prisma.event.create({ data: { title: "FDP on Cloud Computing", type: "FDP", date: "2024-03-10", participants: 40, status: "completed", departmentId: it.id } });

  // Targets - IT
  await prisma.target.create({ data: { category: "Publications", yearly: 50, achieved: 42, departmentId: it.id, year: 2024 } });
  await prisma.target.create({ data: { category: "Patents", yearly: 10, achieved: 6, departmentId: it.id, year: 2024 } });
  await prisma.target.create({ data: { category: "Research Projects", yearly: 15, achieved: 9, departmentId: it.id, year: 2024 } });
  await prisma.target.create({ data: { category: "Events", yearly: 20, achieved: 12, departmentId: it.id, year: 2024 } });

  // Monthly Reviews - IT
  await prisma.monthlyReview.create({ data: { month: "January 2024", departmentId: it.id, submittedBy: "Ramesh Kumar", submittedAt: "2024-01-31", status: "pending_hod", publications: 5, patents: 1, events: 2, students: 15 } });
  await prisma.monthlyReview.create({ data: { month: "December 2023", departmentId: it.id, submittedBy: "Ramesh Kumar", submittedAt: "2023-12-31", status: "approved", publications: 4, patents: 0, events: 1, students: 12 } });

  // Documents - IT
  await prisma.document.create({ data: { name: "NIRF Report 2024.pdf", type: "pdf", size: "2.4 MB", uploadedBy: "Ramesh Kumar", uploadedAt: "2024-01-15", departmentId: it.id } });
  await prisma.document.create({ data: { name: "January Attendance.xlsx", type: "excel", size: "156 KB", uploadedBy: "Ramesh Kumar", uploadedAt: "2024-01-31", departmentId: it.id } });

  // Notifications
  await prisma.notification.create({ data: { title: "Monthly submission reminder", message: "Please submit your monthly data by Jan 31st", type: "reminder" } });
  await prisma.notification.create({ data: { title: "Target achieved", message: "CSE department has achieved 90% of publication target", type: "success" } });

  // College Branding
  await prisma.collegeBranding.create({
    data: {
      collegeName: "JJ College of Engineering & Technology",
      shortName: "JJCET",
      address: "NH-544, Trichy - Thanjavur Road, Pichanur",
      city: "Trichy",
      state: "Tamil Nadu",
      country: "India",
      postalCode: "620 105",
      website: "https://www.jjcet.edu.in",
      email: "info@jjcet.edu.in",
      phone: "+91 431 245 0001",
      motto: "INNOVATE \u2022 TRANSFORM \u2022 INSPIRE",
      principalName: "Dr. Rajesh Kumar",
      established: "1994",
    },
  });

  console.log("Database seeded successfully!");
}

main().catch(console.error).finally(() => prisma.$disconnect());
