cd "D:\sri new\clg NIRF\backend"
npx ts-node-dev --respawn --transpile-only src/index.ts
